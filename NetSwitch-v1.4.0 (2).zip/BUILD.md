# AI2ORBIT NetSwitch - Build Instructions

## Requirements
- Windows 10/11
- Visual Studio 2019/2022 with C++ Desktop Development workload
- CMake 3.14+

## Build with Visual Studio

1. Open "x64 Native Tools Command Prompt for VS 2022"
2. Navigate to the project directory
3. Run:

```
mkdir build
cd build
cmake .. -G "Visual Studio 17 2022" -A x64
cmake --build . --config Release
```

The executable will be at: `build\Release\NetSwitch.exe`

## Build with CMake + Ninja (faster)

```
mkdir build
cd build
cmake .. -G Ninja -DCMAKE_BUILD_TYPE=Release
ninja
```

## Running

NetSwitch requires Administrator privileges for:
- Network interface configuration
- TIME_WAIT socket cleanup
- WinSock reset

### GUI Mode (Windows)
Double-click NetSwitch.exe (will prompt for elevation)

### CLI Mode
```
NetSwitch.exe <host> switch <from_port> <to_port>
NetSwitch.exe <host> connect <port>
NetSwitch.exe <host> ftp-to-ssh
NetSwitch.exe <host> ssh-to-ftp
NetSwitch.exe <host> tunnel ikev2|ssh|gru [port]
NetSwitch.exe cleanup <port>
NetSwitch.exe interfaces
NetSwitch.exe test
```

## Architecture

- WinsockEngine: Core WinSock2 socket management
- PortSwitcher: Clean port 21/22 switching without jamming
- TunnelManager: IKEv2, SSH, GRU tunnel support
- NetworkConfig: IP/DHCP/DNS/routing configuration via netsh + Win32 API
- SecurityManager: Okta SSO, Zscaler ZTNA, PCI DSS audit, AES-256, PKCS12

## Copyright
AI2ORBIT Co. 2026. All rights reserved.

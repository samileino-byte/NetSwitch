#pragma once
#include "netswitch.h"
#include "logger.h"

namespace netswitch {

struct X509CertInfo {
    std::string subject;
    std::string issuer;
    std::string serial_number;
    std::string not_before;
    std::string not_after;
    std::string signature_algorithm;
    int key_bits;
    std::string key_type;
    std::string thumbprint_sha256;
    std::vector<std::string> san_dns;
    std::vector<std::string> san_ip;
    bool is_ca;
    int path_length;
    std::vector<std::string> key_usage;
    std::vector<std::string> ext_key_usage;
    bool is_self_signed;
    bool is_expired;
    int days_until_expiry;
};

struct CertChainResult {
    bool valid;
    std::string error;
    std::vector<X509CertInfo> chain;
    int chain_length;
    bool root_trusted;
    bool all_dates_valid;
    bool signature_chain_valid;
    bool has_certificate_transparency;
    std::string ct_log_id;
};

class CertValidator {
public:
    explicit CertValidator(Logger& logger);

    CertChainResult validate_chain(const std::string& host, uint16_t port = 443);
    CertChainResult validate_pem_chain(const std::string& pem_data);
    X509CertInfo parse_certificate(const std::vector<uint8_t>& der_data);

    bool add_trusted_root(const std::string& pem_path);
    bool add_trusted_root_der(const std::vector<uint8_t>& der_data);
    int load_system_roots();

    bool check_hostname(const X509CertInfo& cert, const std::string& hostname);
    bool check_expiry(const X509CertInfo& cert, int warn_days = 30);

    bool verify_ct_sct(const std::vector<uint8_t>& sct_data);

    struct ValidationPolicy {
        bool require_ct = true;
        bool require_ocsp_stapling = false;
        int min_key_bits_rsa = 2048;
        int min_key_bits_ec = 256;
        int max_chain_length = 5;
        bool allow_sha1 = false;
        bool allow_expired = false;
        int expiry_warning_days = 30;
        std::vector<std::string> allowed_root_cas;
    };

    void set_policy(const ValidationPolicy& policy) { policy_ = policy; }
    ValidationPolicy get_policy() const { return policy_; }

private:
    Logger& logger_;
    ValidationPolicy policy_;
    std::vector<std::vector<uint8_t>> trusted_roots_;

    struct ASN1Tag {
        uint8_t tag_class;
        bool constructed;
        uint32_t tag_number;
        size_t length;
        size_t header_len;
    };

    ASN1Tag parse_asn1_tag(const uint8_t* data, size_t len);
    std::string parse_asn1_oid(const uint8_t* data, size_t len);
    std::string parse_asn1_string(const uint8_t* data, size_t len, uint8_t tag);
    std::string parse_asn1_time(const uint8_t* data, size_t len, uint8_t tag);
    std::string parse_asn1_integer_hex(const uint8_t* data, size_t len);

    std::string oid_to_name(const std::string& oid);
    std::string compute_sha256(const uint8_t* data, size_t len);
    bool wildcard_match(const std::string& pattern, const std::string& hostname);

#ifdef _WIN32
    CertChainResult validate_with_schannel(const std::string& host, uint16_t port);
#endif
};

} // namespace netswitch

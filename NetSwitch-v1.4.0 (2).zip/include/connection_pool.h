#pragma once
#include "netswitch.h"
#include "winsock_engine.h"
#include "logger.h"

namespace netswitch {

class ConnectionPool {
public:
    ConnectionPool(WinsockEngine& engine, Logger& logger, int max_connections = 64);
    ~ConnectionPool();

    struct PoolEntry {
        SOCKET socket;
        std::string host;
        uint16_t port;
        ConnectionState state;
        std::chrono::steady_clock::time_point created_at;
        std::chrono::steady_clock::time_point last_used;
        uint64_t use_count;
        bool in_use;
    };

    SOCKET acquire(const std::string& host, uint16_t port, int timeout_ms = 5000);
    void release(SOCKET sock);
    void discard(SOCKET sock);

    void set_max_idle_time(int seconds) { max_idle_sec_ = seconds; }
    void set_max_lifetime(int seconds) { max_lifetime_sec_ = seconds; }
    void set_health_check_interval(int seconds) { health_check_sec_ = seconds; }

    int active_count() const;
    int idle_count() const;
    int total_count() const;

    void evict_idle();
    void evict_expired();
    void drain();

    std::vector<PoolEntry> get_entries() const;

    struct PoolStats {
        uint64_t total_acquired;
        uint64_t total_released;
        uint64_t total_created;
        uint64_t total_evicted;
        uint64_t cache_hits;
        uint64_t cache_misses;
        double hit_rate;
    };
    PoolStats get_stats() const { return stats_; }

private:
    WinsockEngine& engine_;
    Logger& logger_;
    int max_connections_;
    int max_idle_sec_ = 300;
    int max_lifetime_sec_ = 3600;
    int health_check_sec_ = 60;
    mutable std::mutex mutex_;
    std::vector<PoolEntry> pool_;
    PoolStats stats_ = {};

    std::string make_key(const std::string& host, uint16_t port);
    bool is_healthy(SOCKET sock);
    void remove_entry(SOCKET sock);
};

class ConnectionPoolManager {
public:
    ConnectionPoolManager(WinsockEngine& engine, Logger& logger);

    ConnectionPool& get_pool(const std::string& name, int max_connections = 32);
    void remove_pool(const std::string& name);
    std::vector<std::string> list_pools() const;

    void evict_all_idle();
    void drain_all();

private:
    WinsockEngine& engine_;
    Logger& logger_;
    std::map<std::string, std::unique_ptr<ConnectionPool>> pools_;
    mutable std::mutex mutex_;
};

} // namespace netswitch

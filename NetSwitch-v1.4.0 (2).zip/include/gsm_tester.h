#pragma once
#include "netswitch.h"
#include "winsock_engine.h"
#include "logger.h"

namespace netswitch {

enum class CellularTech { GSM_2G, UMTS_3G, LTE_4G, NR_5G };

enum class SignalBand {
    N8_925,    N9_1749,   N10_2110,  N11_1475,
    N15_NONE,  N28_758,   N77_3750,  N78_3500,  N79_4700,
    GSM_900,   GSM_1800,  UMTS_2100, LTE_B1,    LTE_B3,
    LTE_B7,    LTE_B20,   LTE_B28,   LTE_B38,   LTE_B40
};

struct SignalMetrics {
    double rssi_dbm;
    double rsrp_dbm;
    double rsrq_db;
    double sinr_db;
    double snr_db;
    double ber;
    double fer;
    double noise_floor_dbm;
    CellularTech technology;
    SignalBand band;
    double frequency_mhz;
    std::string quality;
};

struct EchoResult {
    double rtt_ms;
    double jitter_ms;
    double packet_loss_pct;
    int packets_sent;
    int packets_received;
    double throughput_kbps;
    double echo_log_sin;
    SignalMetrics signal;
    bool passed;
    std::string notes;
};

struct GsmTestResult {
    std::string test_name;
    CellularTech technology;
    SignalBand band;
    SignalMetrics signal;
    EchoResult echo;
    bool passed;
    std::string notes;
    double duration_ms;
};

struct GsmTestSuite {
    std::vector<GsmTestResult> results;
    int total;
    int passed;
    int failed;
    double total_duration_sec;
    SignalMetrics best_signal;
    SignalMetrics worst_signal;
};

struct SignalLogEntry {
    std::chrono::system_clock::time_point timestamp;
    SignalMetrics metrics;
    double echo_rtt_ms;
    double echo_log_sin_ab;
};

class GsmTester {
public:
    GsmTester(WinsockEngine& engine, Logger& logger);

    GsmTestSuite run_full_suite();

    EchoResult echo_test(CellularTech tech, SignalBand band, int packets = 100, int payload_bytes = 64);
    SignalMetrics measure_signal(CellularTech tech, SignalBand band);

    GsmTestResult test_gsm_echo(SignalBand band = SignalBand::GSM_900);
    GsmTestResult test_umts_echo(SignalBand band = SignalBand::UMTS_2100);
    GsmTestResult test_lte_echo(SignalBand band = SignalBand::LTE_B1);
    GsmTestResult test_nr_echo(SignalBand band = SignalBand::N78_3500);
    GsmTestResult test_snr_logging(CellularTech tech, SignalBand band);
    GsmTestResult test_band_sweep(CellularTech tech);

    std::vector<SignalLogEntry> get_signal_log() const;
    void clear_signal_log();

    static double echo_log_sin(double a, double b);
    static double compute_snr(double signal_dbm, double noise_dbm);
    static std::string tech_name(CellularTech t);
    static std::string band_name(SignalBand b);
    static double band_frequency(SignalBand b);
    static std::string signal_quality(double sinr_db);
    static std::string format_report(const GsmTestSuite& suite);

private:
    WinsockEngine& engine_;
    Logger& logger_;
    std::vector<SignalLogEntry> signal_log_;
    std::mt19937 rng_;
    std::mutex log_mutex_;

    SignalMetrics simulate_signal(CellularTech tech, SignalBand band);
    EchoResult simulate_echo(CellularTech tech, SignalBand band, int packets, int payload_bytes);
    void log_signal(const SignalMetrics& metrics, double echo_rtt, double echo_log_sin_ab);
};

} // namespace netswitch

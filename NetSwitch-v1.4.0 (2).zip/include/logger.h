#pragma once
#include "netswitch.h"

namespace netswitch {

class Logger {
public:
    Logger();
    ~Logger();

    bool open_file(const std::string& path);
    void close_file();

    void set_level(LogLevel level) { min_level_ = level; }
    LogLevel get_level() const { return min_level_; }

    void log(LogLevel level, const std::string& source, const std::string& message,
             const std::string& details = "");

    void trace(const std::string& source, const std::string& msg)   { log(LogLevel::TRACE, source, msg); }
    void debug(const std::string& source, const std::string& msg)   { log(LogLevel::DEBUG, source, msg); }
    void info(const std::string& source, const std::string& msg)    { log(LogLevel::INFO, source, msg); }
    void warning(const std::string& source, const std::string& msg) { log(LogLevel::WARNING, source, msg); }
    void error(const std::string& source, const std::string& msg)   { log(LogLevel::ERROR_LEVEL, source, msg); }
    void critical(const std::string& source, const std::string& msg){ log(LogLevel::CRITICAL, source, msg); }

    void on_log(LogCallback cb) { callback_ = cb; }

    std::vector<LogEntry> get_entries(int max_count = 500, LogLevel min_level = LogLevel::TRACE) const;
    void clear();

    size_t entry_count() const { std::lock_guard<std::mutex> lk(mutex_); return entries_.size(); }

    static std::string level_string(LogLevel level);
    static std::string timestamp_string(std::chrono::system_clock::time_point tp);

private:
    LogLevel min_level_ = LogLevel::INFO;
    mutable std::mutex mutex_;
    std::vector<LogEntry> entries_;
    std::ofstream file_;
    LogCallback callback_;
    size_t max_entries_ = 10000;
};

} // namespace netswitch

#pragma once
#include "netswitch.h"
#include "winsock_engine.h"
#include "logger.h"

namespace netswitch {

enum class OsstmmChannel {
    HUMAN,
    PHYSICAL,
    WIRELESS,
    TELECOMMUNICATIONS,
    DATA_NETWORKS
};

enum class OsstmmTestType {
    VISIBILITY,
    ACCESS,
    TRUST,
    AUTHENTICATION,
    NON_REPUDIATION,
    CONFIDENTIALITY,
    PRIVACY,
    AUTHORIZATION,
    INTEGRITY,
    ALARM,
    CONTINUITY,
    RESILIENCE
};

enum class RavSeverity { INFO = 0, LOW = 1, MEDIUM = 2, HIGH = 3, CRITICAL = 4 };

struct OsstmmTestResult {
    OsstmmTestType type;
    OsstmmChannel channel;
    std::string test_name;
    std::string isecom_ref;
    bool passed;
    std::string details;
    std::string recommendation;
    RavSeverity severity;
    double duration_ms;
    double rav_score;
};

struct BoxCallResult {
    bool responding;
    double response_time_ms;
    int port;
    std::string protocol;
    bool authorized_caller;
    bool unauthorized_detected;
    std::string caller_identity;
    std::string flaw_description;
};

struct RavScore {
    double operational_security;
    double loss_controls;
    double limitations;
    double attack_surface;
    double trust_score;
    double overall;
    std::string grade;
};

struct OsstmmReport {
    std::vector<OsstmmTestResult> results;
    std::vector<BoxCallResult> box_calls;
    RavScore rav;
    int total;
    int passed;
    int failed;
    int critical_findings;
    double score_pct;
    double total_duration_sec;
};

class OsstmmTester {
public:
    OsstmmTester(WinsockEngine& engine, Logger& logger);

    OsstmmReport run_full_audit();

    // OSSTMM v3 Section E: Data Networks
    OsstmmTestResult test_visibility(const std::string& host, int port);
    OsstmmTestResult test_access_control(const std::string& host, int port);
    OsstmmTestResult test_trust_verification(const std::string& host, int port);
    OsstmmTestResult test_authentication(const std::string& host, int port);
    OsstmmTestResult test_non_repudiation();
    OsstmmTestResult test_confidentiality(const std::string& host, int port);
    OsstmmTestResult test_privacy();
    OsstmmTestResult test_authorization();
    OsstmmTestResult test_integrity(const void* data, size_t len);
    OsstmmTestResult test_alarm();
    OsstmmTestResult test_continuity(const std::string& host, int port, int attempts);
    OsstmmTestResult test_resilience(const std::string& host, int port);

    // Box Call Testing (OSSTMM core concept)
    BoxCallResult call_box(const std::string& host, int port, const std::string& caller_id);
    BoxCallResult call_box_unauthorized(const std::string& host, int port);
    std::vector<BoxCallResult> box_call_sweep(const std::string& host,
                                               const std::vector<int>& ports,
                                               const std::string& caller_id);

    // OSSTMM v3 Section D: Telecommunications
    OsstmmTestResult test_telecom_visibility();
    OsstmmTestResult test_telecom_access();
    OsstmmTestResult test_telecom_trust();
    OsstmmTestResult test_telecom_continuity();

    // RAV (Risk Assessment Values) calculation
    RavScore calculate_rav(const std::vector<OsstmmTestResult>& results);
    static std::string rav_grade(double score);

    // Interaction testing
    OsstmmTestResult test_enumeration(const std::string& host);
    OsstmmTestResult test_verification(const std::string& host, int port);
    OsstmmTestResult test_process_verification();

    static std::string channel_name(OsstmmChannel ch);
    static std::string test_type_name(OsstmmTestType t);
    static std::string severity_name(RavSeverity s);
    static std::string format_report(const OsstmmReport& report);

private:
    WinsockEngine& engine_;
    Logger& logger_;
    std::mt19937 rng_;

    bool probe_port(const std::string& host, int port, int timeout_ms);
    std::string grab_banner(const std::string& host, int port, int timeout_ms);
    double measure_response_time(const std::string& host, int port);
    uint32_t compute_integrity_hash(const void* data, size_t len);
    bool verify_tls_available(const std::string& host, int port);
};

} // namespace netswitch

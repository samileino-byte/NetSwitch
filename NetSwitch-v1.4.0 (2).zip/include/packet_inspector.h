#pragma once
#include "netswitch.h"
#include "logger.h"

namespace netswitch {

struct EthernetFrame {
    uint8_t dest_mac[6];
    uint8_t src_mac[6];
    uint16_t ethertype;
    bool has_vlan;
    uint16_t vlan_id;
    uint16_t vlan_priority;
};

struct IPv4Header {
    uint8_t version;
    uint8_t ihl;
    uint8_t dscp;
    uint8_t ecn;
    uint16_t total_length;
    uint16_t identification;
    bool dont_fragment;
    bool more_fragments;
    uint16_t fragment_offset;
    uint8_t ttl;
    uint8_t protocol;
    uint16_t checksum;
    uint32_t src_addr;
    uint32_t dst_addr;
    bool checksum_valid;
};

struct IPv6Header {
    uint8_t version;
    uint8_t traffic_class;
    uint32_t flow_label;
    uint16_t payload_length;
    uint8_t next_header;
    uint8_t hop_limit;
    uint8_t src_addr[16];
    uint8_t dst_addr[16];
};

struct TCPHeader {
    uint16_t src_port;
    uint16_t dst_port;
    uint32_t seq_number;
    uint32_t ack_number;
    uint8_t data_offset;
    bool flag_urg;
    bool flag_ack;
    bool flag_psh;
    bool flag_rst;
    bool flag_syn;
    bool flag_fin;
    uint16_t window_size;
    uint16_t checksum;
    uint16_t urgent_pointer;
};

struct UDPHeader {
    uint16_t src_port;
    uint16_t dst_port;
    uint16_t length;
    uint16_t checksum;
};

struct TLSRecord {
    uint8_t content_type;    // 20=ChangeCipher, 21=Alert, 22=Handshake, 23=Application
    uint8_t version_major;
    uint8_t version_minor;
    uint16_t length;
    uint8_t handshake_type;  // 1=ClientHello, 2=ServerHello, 11=Certificate, etc.
    std::string tls_version_string;
    std::vector<std::string> cipher_suites;
    std::string sni;
};

struct PacketSummary {
    std::chrono::system_clock::time_point timestamp;
    int frame_number;
    int length;
    std::string src_addr;
    std::string dst_addr;
    uint16_t src_port;
    uint16_t dst_port;
    std::string protocol;
    std::string info;
    bool is_encrypted;
};

class PacketInspector {
public:
    explicit PacketInspector(Logger& logger);

    EthernetFrame parse_ethernet(const uint8_t* data, int len);
    IPv4Header parse_ipv4(const uint8_t* data, int len);
    IPv6Header parse_ipv6(const uint8_t* data, int len);
    TCPHeader parse_tcp(const uint8_t* data, int len);
    UDPHeader parse_udp(const uint8_t* data, int len);
    TLSRecord parse_tls(const uint8_t* data, int len);

    PacketSummary inspect_packet(const uint8_t* data, int len);
    std::vector<PacketSummary> inspect_stream(const std::vector<std::vector<uint8_t>>& packets);

    uint16_t compute_ip_checksum(const uint8_t* header, int len);
    bool verify_ip_checksum(const uint8_t* header, int len);

    static std::string mac_to_string(const uint8_t mac[6]);
    static std::string ipv4_to_string(uint32_t addr);
    static std::string ipv6_to_string(const uint8_t addr[16]);
    static std::string protocol_name(uint8_t protocol_number);
    static std::string ethertype_name(uint16_t ethertype);
    static std::string tcp_flags_string(const TCPHeader& tcp);
    static std::string tls_version_name(uint8_t major, uint8_t minor);
    static std::string tls_handshake_name(uint8_t type);

    struct TrafficStats {
        uint64_t total_packets;
        uint64_t total_bytes;
        uint64_t tcp_packets;
        uint64_t udp_packets;
        uint64_t tls_packets;
        uint64_t ipv4_packets;
        uint64_t ipv6_packets;
        uint64_t syn_packets;
        uint64_t fin_packets;
        uint64_t rst_packets;
        std::map<uint16_t, uint64_t> port_distribution;
        std::map<std::string, uint64_t> protocol_distribution;
    };

    TrafficStats get_stats() const { return stats_; }
    void reset_stats() { stats_ = {}; }

private:
    Logger& logger_;
    TrafficStats stats_ = {};
    int frame_counter_ = 0;

    uint16_t read_u16_be(const uint8_t* p);
    uint32_t read_u32_be(const uint8_t* p);
};

} // namespace netswitch

#pragma once
#include "netswitch.h"
#include "winsock_engine.h"
#include "logger.h"

namespace netswitch {

// ---------------------------------------------------------------------------
// HTTP/HTTPS Stack Tester
// ---------------------------------------------------------------------------

enum class HttpMethod { GET, POST, PUT, DELETE_METHOD, HEAD, OPTIONS };
enum class HttpVersion { HTTP_10, HTTP_11, HTTP_20 };
enum class TlsVersion { NONE, TLS_10, TLS_11, TLS_12, TLS_13 };

struct HttpTestConfig {
    std::string host;
    uint16_t port;
    HttpMethod method;
    HttpVersion version;
    std::string path;
    std::string body;
    int timeout_ms;
    bool use_tls;
    TlsVersion min_tls;
};

struct HttpTestResult {
    HttpMethod method;
    HttpVersion version;
    std::string url;

    int status_code;
    std::string status_text;
    std::string response_headers;
    size_t response_body_size;

    double dns_time_ms;
    double connect_time_ms;
    double tls_handshake_ms;
    double first_byte_ms;
    double total_time_ms;
    double throughput_kbps;

    bool connection_reuse;
    bool keep_alive;
    bool chunked;
    bool gzip;

    TlsVersion tls_version;
    std::string tls_cipher;

    bool passed;
    std::string error;
    std::string notes;
};

struct HttpTestSuite {
    std::vector<HttpTestResult> results;
    int methods_tested;
    int versions_tested;
    int passed;
    int failed;
    double total_duration_sec;
};

class HttpTester {
public:
    HttpTester(WinsockEngine& engine, Logger& logger);
    ~HttpTester();

    HttpTestSuite run_full_suite(const std::string& host = "127.0.0.1", uint16_t port = 80);
    HttpTestResult test_method(HttpMethod method, const std::string& host, uint16_t port,
                                const std::string& path = "/");
    HttpTestResult test_version(HttpVersion version, const std::string& host, uint16_t port);
    HttpTestResult test_tls(TlsVersion version, const std::string& host, uint16_t port = 443);

    HttpTestResult test_keep_alive(const std::string& host, uint16_t port);
    HttpTestResult test_chunked_transfer(const std::string& host, uint16_t port);
    HttpTestResult test_connection_reuse(const std::string& host, uint16_t port);

    static std::string method_name(HttpMethod m);
    static std::string version_name(HttpVersion v);
    static std::string tls_version_name(TlsVersion v);
    static std::string format_result(const HttpTestResult& r);
    static std::string format_suite(const HttpTestSuite& suite);

private:
    WinsockEngine& engine_;
    Logger& logger_;

    std::string build_request(HttpMethod method, HttpVersion version,
                               const std::string& host, const std::string& path,
                               const std::string& body = "");
    HttpTestResult execute_request(const HttpTestConfig& config);
    int parse_status_code(const std::string& response);
    std::string parse_status_text(const std::string& response);
    bool has_header(const std::string& response, const std::string& header, const std::string& value = "");
    std::string get_header_value(const std::string& response, const std::string& header);
};

// ---------------------------------------------------------------------------
// TCP/IP Protocol Tester
// ---------------------------------------------------------------------------

enum class TcpTestType {
    THREE_WAY_HANDSHAKE,
    FIN_TEARDOWN,
    RST_HANDLING,
    WINDOW_SCALING,
    KEEPALIVE,
    NAGLE_ALGORITHM,
    MSS_NEGOTIATION,
    LINGER_BEHAVIOR,
    REUSE_ADDR,
    NODELAY,
    BACKLOG_QUEUE,
    CONCURRENT_CONNECTIONS,
    HALF_CLOSE,
    URGENT_DATA,
    SOCKET_BUFFER_SIZING
};

struct TcpTestResult {
    TcpTestType type;
    std::string name;
    std::string description;

    double duration_ms;
    int iterations;

    double measured_value;
    std::string measured_unit;
    double expected_min;
    double expected_max;

    bool passed;
    std::string error;
    std::string notes;
    std::string ieee_ref;
};

struct TcpTestSuite {
    std::vector<TcpTestResult> results;
    int total_tests;
    int passed;
    int failed;
    double total_duration_sec;
    std::string stack_info;
};

class TcpIpTester {
public:
    TcpIpTester(WinsockEngine& engine, Logger& logger);
    ~TcpIpTester();

    TcpTestSuite run_full_suite();
    TcpTestResult run_test(TcpTestType type);

    TcpTestResult test_three_way_handshake();
    TcpTestResult test_fin_teardown();
    TcpTestResult test_rst_handling();
    TcpTestResult test_window_scaling();
    TcpTestResult test_keepalive();
    TcpTestResult test_nagle();
    TcpTestResult test_mss_negotiation();
    TcpTestResult test_linger();
    TcpTestResult test_reuse_addr();
    TcpTestResult test_nodelay();
    TcpTestResult test_backlog();
    TcpTestResult test_concurrent();
    TcpTestResult test_half_close();
    TcpTestResult test_urgent_data();
    TcpTestResult test_buffer_sizing();

    static std::string test_type_name(TcpTestType t);
    static std::string format_result(const TcpTestResult& r);
    static std::string format_suite(const TcpTestSuite& suite);

private:
    WinsockEngine& engine_;
    Logger& logger_;

    struct LoopbackPair {
        SOCKET server;
        SOCKET client;
        SOCKET accepted;
        uint16_t port;
        bool valid;
    };

    LoopbackPair create_loopback_pair();
    void destroy_loopback_pair(LoopbackPair& pair);
};

// ---------------------------------------------------------------------------
// IEEE/Spec Quality Checker
// ---------------------------------------------------------------------------

struct QualityCheckResult {
    std::string category;
    std::string check_name;
    std::string spec_reference;
    bool passed;
    std::string details;
    std::string recommendation;
};

struct QualityReport {
    std::vector<QualityCheckResult> checks;
    int total_checks;
    int passed;
    int failed;
    int warnings;
    double score_pct;
};

class QualityChecker {
public:
    QualityChecker(WinsockEngine& engine, Logger& logger);

    QualityReport run_full_audit();

    static std::string format_report(const QualityReport& report);

private:
    WinsockEngine& engine_;
    Logger& logger_;

    void check_socket_options(std::vector<QualityCheckResult>& results);
    void check_tcp_compliance(std::vector<QualityCheckResult>& results);
    void check_protocol_stack(std::vector<QualityCheckResult>& results);
    void check_error_handling(std::vector<QualityCheckResult>& results);
    void check_resource_management(std::vector<QualityCheckResult>& results);
    void check_security(std::vector<QualityCheckResult>& results);
};

} // namespace netswitch

#pragma once
#include "netswitch.h"
#include "logger.h"

namespace netswitch {

enum class RsaKeySize { RSA_2048 = 2048, RSA_3072 = 3072, RSA_4096 = 4096 };

struct RsaKeyPair {
    std::vector<uint8_t> public_key_der;
    std::vector<uint8_t> private_key_der;
    int key_bits;
    std::string key_id;
    std::chrono::system_clock::time_point created_at;
    std::chrono::system_clock::time_point expires_at;
    bool valid;
};

struct JwkPublicKey {
    std::string kty;
    std::string kid;
    std::string use;
    std::string alg;
    std::string n;
    std::string e;
};

struct Jwks {
    std::vector<JwkPublicKey> keys;
};

struct JwtHeader {
    std::string alg;
    std::string typ;
    std::string kid;
};

struct JwtPayload {
    std::string iss;
    std::string sub;
    std::string aud;
    int64_t iat;
    int64_t exp;
    std::string jti;
    std::map<std::string, std::string> claims;
};

struct JwtToken {
    JwtHeader header;
    JwtPayload payload;
    std::string signature;
    std::string encoded;
    bool valid;
};

struct RsaTestResult {
    std::string test_name;
    bool passed;
    double duration_ms;
    std::string notes;
};

struct RsaTestSuite {
    std::vector<RsaTestResult> results;
    int total;
    int passed;
    int failed;
    double total_duration_sec;
};

class RsaCrypto {
public:
    explicit RsaCrypto(Logger& logger);

    RsaKeyPair generate_key_pair(RsaKeySize size = RsaKeySize::RSA_2048, int lifetime_hours = 8760);
    bool validate_key_pair(const RsaKeyPair& kp);

    JwkPublicKey to_jwk(const RsaKeyPair& kp);
    Jwks to_jwks(const std::vector<RsaKeyPair>& keys);
    std::string jwks_to_json(const Jwks& jwks);

    JwtToken create_jwt(const RsaKeyPair& kp, const JwtPayload& payload);
    bool verify_jwt(const JwtToken& token, const RsaKeyPair& kp);
    JwtToken decode_jwt(const std::string& encoded);

    std::vector<uint8_t> sign(const RsaKeyPair& kp, const void* data, size_t len);
    bool verify(const RsaKeyPair& kp, const void* data, size_t len,
                const std::vector<uint8_t>& signature);

    RsaKeyPair rotate_key(const RsaKeyPair& old_key, RsaKeySize new_size = RsaKeySize::RSA_2048);
    bool is_key_expired(const RsaKeyPair& kp) const;

    RsaTestSuite run_full_suite();

    static std::string base64url_encode(const std::vector<uint8_t>& data);
    static std::string base64url_encode(const std::string& data);
    static std::vector<uint8_t> base64url_decode(const std::string& encoded);
    static std::string format_report(const RsaTestSuite& suite);

private:
    Logger& logger_;
    std::mt19937_64 rng_;

    std::vector<uint8_t> generate_prime(int bits);
    bool miller_rabin(const std::vector<uint8_t>& n, int rounds);
    std::vector<uint8_t> bignum_multiply(const std::vector<uint8_t>& a, const std::vector<uint8_t>& b);
    std::vector<uint8_t> bignum_mod_exp(const std::vector<uint8_t>& base,
                                         const std::vector<uint8_t>& exp,
                                         const std::vector<uint8_t>& mod);
    std::vector<uint8_t> bignum_mod_inverse(const std::vector<uint8_t>& a, const std::vector<uint8_t>& m);
    std::vector<uint8_t> sha256(const void* data, size_t len);
    std::vector<uint8_t> pkcs1_v15_pad(const std::vector<uint8_t>& hash, int key_bytes);

    std::string generate_key_id();
};

} // namespace netswitch

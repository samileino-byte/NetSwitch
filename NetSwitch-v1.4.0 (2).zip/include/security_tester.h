#pragma once
#include "netswitch.h"
#include "winsock_engine.h"
#include "logger.h"

namespace netswitch {

// ---------------------------------------------------------------------------
// OWASP Network Security Tester
// ---------------------------------------------------------------------------

enum class OwaspCategory {
    INJECTION,
    BROKEN_AUTH,
    SENSITIVE_DATA,
    TRANSPORT_SECURITY,
    MISCONFIGURATION,
    BUFFER_OVERFLOW,
    DOS_RESILIENCE,
    INPUT_VALIDATION,
    SESSION_MANAGEMENT,
    LOGGING_MONITORING
};

struct OwaspTestResult {
    OwaspCategory category;
    std::string test_name;
    std::string owasp_ref;
    bool passed;
    std::string details;
    std::string recommendation;
    int severity;  // 1=low, 2=medium, 3=high, 4=critical
};

struct OwaspReport {
    std::vector<OwaspTestResult> results;
    int total;
    int passed;
    int failed;
    int critical_findings;
    double score_pct;
};

class OwaspTester {
public:
    OwaspTester(WinsockEngine& engine, Logger& logger);

    OwaspReport run_full_audit();

    static std::string category_name(OwaspCategory c);
    static std::string format_report(const OwaspReport& report);

private:
    WinsockEngine& engine_;
    Logger& logger_;

    void test_injection(std::vector<OwaspTestResult>& results);
    void test_auth(std::vector<OwaspTestResult>& results);
    void test_sensitive_data(std::vector<OwaspTestResult>& results);
    void test_transport_security(std::vector<OwaspTestResult>& results);
    void test_misconfiguration(std::vector<OwaspTestResult>& results);
    void test_buffer_overflow(std::vector<OwaspTestResult>& results);
    void test_dos_resilience(std::vector<OwaspTestResult>& results);
    void test_input_validation(std::vector<OwaspTestResult>& results);
    void test_session_management(std::vector<OwaspTestResult>& results);
    void test_logging(std::vector<OwaspTestResult>& results);
};

// ---------------------------------------------------------------------------
// IP Prober / Network Scanner
// ---------------------------------------------------------------------------

enum class ScanType { TCP_CONNECT, BANNER_GRAB, SERVICE_DETECT };

struct HostProbeResult {
    std::string host;
    bool reachable;
    double latency_ms;
    std::string hostname;
    std::string os_hint;
};

struct PortScanResult {
    uint16_t port;
    bool open;
    std::string service;
    std::string banner;
    double response_ms;
    std::string protocol;
};

struct SocketScanResult {
    SOCKET socket;
    std::string local_addr;
    uint16_t local_port;
    std::string remote_addr;
    uint16_t remote_port;
    std::string state;
    std::string protocol;
};

struct NetworkScanReport {
    std::vector<HostProbeResult> hosts;
    std::vector<PortScanResult> ports;
    std::vector<SocketScanResult> sockets;
    int hosts_scanned;
    int hosts_up;
    int ports_scanned;
    int ports_open;
    double scan_duration_sec;
};

class NetworkScanner {
public:
    NetworkScanner(WinsockEngine& engine, Logger& logger);

    // IP probing
    HostProbeResult probe_host(const std::string& host, int timeout_ms = 2000);
    std::vector<HostProbeResult> probe_range(const std::string& base_ip, int start, int end, int timeout_ms = 1000);

    // Port scanning
    PortScanResult scan_port(const std::string& host, uint16_t port, ScanType type = ScanType::TCP_CONNECT, int timeout_ms = 2000);
    std::vector<PortScanResult> scan_ports(const std::string& host, uint16_t start_port, uint16_t end_port, int timeout_ms = 1000);
    std::vector<PortScanResult> scan_common_ports(const std::string& host, int timeout_ms = 1000);

    // Socket scanning
    std::vector<SocketScanResult> scan_active_sockets();

    // Service detection
    std::string detect_service(uint16_t port, const std::string& banner);
    std::string grab_banner(const std::string& host, uint16_t port, int timeout_ms = 3000);

    // Full scan
    NetworkScanReport run_full_scan(const std::string& host = "127.0.0.1");

    static std::string format_report(const NetworkScanReport& report);

private:
    WinsockEngine& engine_;
    Logger& logger_;

    static const std::vector<uint16_t>& common_ports();
    static std::string port_service_name(uint16_t port);
};

// ---------------------------------------------------------------------------
// Protocol Forger (Packet Crafting for Testing)
// ---------------------------------------------------------------------------

enum class ForgeProtocol { TCP, UDP, RAW };

struct ForgedPacket {
    ForgeProtocol protocol;
    std::string src_host;
    uint16_t src_port;
    std::string dst_host;
    uint16_t dst_port;
    std::vector<uint8_t> payload;
    int ttl;
    uint8_t flags;
    bool valid;
};

struct ForgeTestResult {
    std::string test_name;
    ForgeProtocol protocol;
    bool sent;
    bool response_received;
    double rtt_ms;
    std::string response_data;
    std::string error;
    std::string notes;
};

struct ForgeReport {
    std::vector<ForgeTestResult> results;
    int total;
    int passed;
    int failed;
};

class ProtocolForge {
public:
    ProtocolForge(WinsockEngine& engine, Logger& logger);

    // Packet crafting
    ForgedPacket craft_tcp(const std::string& dst, uint16_t port, const std::vector<uint8_t>& payload, uint8_t flags = 0);
    ForgedPacket craft_udp(const std::string& dst, uint16_t port, const std::vector<uint8_t>& payload);

    // Protocol testing
    ForgeTestResult test_tcp_flags(const std::string& host, uint16_t port, uint8_t flags);
    ForgeTestResult test_malformed_packet(const std::string& host, uint16_t port);
    ForgeTestResult test_oversized_payload(const std::string& host, uint16_t port, size_t size);
    ForgeTestResult test_zero_window(const std::string& host, uint16_t port);
    ForgeTestResult test_protocol_fuzzing(const std::string& host, uint16_t port, int iterations);

    // Full test
    ForgeReport run_full_suite(const std::string& host = "127.0.0.1", uint16_t port = 0);

    static std::string format_report(const ForgeReport& report);
    static std::string flags_string(uint8_t flags);

private:
    WinsockEngine& engine_;
    Logger& logger_;
    std::mt19937 rng_;
};

// ---------------------------------------------------------------------------
// Firewall / Switch Tester
// ---------------------------------------------------------------------------

enum class FirewallAction { ALLOW, BLOCK, DROP, REJECT };

struct FirewallRule {
    std::string name;
    std::string src;
    std::string dst;
    uint16_t port;
    std::string protocol;
    FirewallAction action;
};

struct FirewallTestResult {
    FirewallRule rule;
    bool expected_behavior;
    bool actual_behavior;
    bool passed;
    double test_time_ms;
    std::string notes;
};

struct FirewallReport {
    std::vector<FirewallTestResult> results;
    int total;
    int passed;
    int failed;
    int rules_tested;
};

class FirewallTester {
public:
    FirewallTester(WinsockEngine& engine, Logger& logger);

    void add_rule(const FirewallRule& rule);
    void clear_rules();

    FirewallTestResult test_rule(const FirewallRule& rule, int timeout_ms = 2000);
    FirewallTestResult test_port_block(uint16_t port, int timeout_ms = 2000);
    FirewallTestResult test_port_allow(uint16_t port, int timeout_ms = 2000);
    FirewallTestResult test_protocol_filter(const std::string& protocol, uint16_t port, int timeout_ms = 2000);

    FirewallReport run_full_suite();

    static std::string action_name(FirewallAction a);
    static std::string format_report(const FirewallReport& report);

private:
    WinsockEngine& engine_;
    Logger& logger_;
    std::vector<FirewallRule> rules_;
};

// ---------------------------------------------------------------------------
// AI Learning System
// ---------------------------------------------------------------------------

struct TestObservation {
    std::string test_name;
    std::string category;
    bool passed;
    double value;
    double duration_ms;
    std::chrono::system_clock::time_point timestamp;
};

struct PatternMatch {
    std::string pattern;
    double confidence;
    int occurrences;
    std::string prediction;
};

struct LearningReport {
    int total_observations;
    int patterns_detected;
    std::vector<PatternMatch> patterns;
    std::vector<std::string> recommendations;
    double model_confidence;
    int predictions_correct;
    int predictions_total;
};

class AILearner {
public:
    AILearner(Logger& logger);

    // Data collection
    void observe(const TestObservation& obs);
    void observe_batch(const std::vector<TestObservation>& batch);

    // Pattern analysis
    std::vector<PatternMatch> detect_patterns();
    double predict_pass_probability(const std::string& test_name);

    // Adaptive testing
    std::vector<std::string> recommend_tests();
    std::vector<std::string> identify_weak_areas();

    // Model state
    LearningReport get_report();
    int observation_count() const;
    void reset();

    static std::string format_report(const LearningReport& report);

private:
    Logger& logger_;
    std::vector<TestObservation> observations_;
    std::map<std::string, std::vector<double>> pass_rates_;
    std::map<std::string, std::vector<double>> durations_;
    std::map<std::string, int> failure_counts_;
    std::map<std::string, int> success_counts_;
    std::mutex mutex_;

    double calculate_trend(const std::vector<double>& values);
    double calculate_stability(const std::vector<double>& values);
};

} // namespace netswitch

#pragma once

#ifdef _WIN32

#include "netswitch.h"
#include "winsock_engine.h"
#include "port_switcher.h"
#include "tunnel_manager.h"
#include "connection_pool.h"
#include "virtual_stream.h"
#include "wifi_tester.h"
#include "protocol_tester.h"
#include "security_tester.h"
#include "gsm_tester.h"
#include "rsa_crypto.h"
#include "logger.h"

namespace netswitch {

struct TestCategory {
    std::string name;
    bool enabled;
    int total;
    int passed;
    int failed;
    double duration_sec;
    std::string status;
    std::vector<std::pair<std::string, bool>> results;
};

class TestBenchGui {
public:
    TestBenchGui();
    ~TestBenchGui();

    bool create(HINSTANCE hInstance, int nCmdShow);
    int run();

    static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

private:
    HWND hwnd_;
    HWND hwnd_list_;
    HWND hwnd_status_;
    HWND hwnd_progress_;
    HWND hwnd_log_;
    HWND hwnd_run_btn_;
    HWND hwnd_stop_btn_;
    HWND hwnd_form_combo_;
    HWND hwnd_summary_label_;
    HFONT hfont_;
    HFONT hfont_bold_;
    HFONT hfont_mono_;
    HBRUSH hbrush_bg_;
    HBRUSH hbrush_pass_;
    HBRUSH hbrush_fail_;
    HINSTANCE hinstance_;

    WinsockEngine engine_;
    Logger logger_;
    std::vector<TestCategory> categories_;
    std::atomic<bool> running_{false};
    std::atomic<bool> stop_requested_{false};
    std::thread test_thread_;

    int total_tests_ = 0;
    int total_passed_ = 0;
    int total_failed_ = 0;
    double total_duration_ = 0.0;

    void init_categories();
    void run_all_tests();
    void run_category(TestCategory& cat);
    void update_ui();
    void update_progress(int current, int total);
    void log_message(const std::string& msg);
    void update_summary();

    void run_streams_tests(TestCategory& cat);
    void run_wifi_tests(TestCategory& cat);
    void run_network_tests(TestCategory& cat);
    void run_gps_tests(TestCategory& cat);
    void run_http_tests(TestCategory& cat);
    void run_tcp_tests(TestCategory& cat);
    void run_quality_tests(TestCategory& cat);
    void run_owasp_tests(TestCategory& cat);
    void run_scanner_tests(TestCategory& cat);
    void run_forge_tests(TestCategory& cat);
    void run_firewall_tests(TestCategory& cat);
    void run_gsm_tests(TestCategory& cat);
    void run_rsa_tests(TestCategory& cat);
    void run_tunnel_tests(TestCategory& cat);
    void run_ai_tests(TestCategory& cat);

    void create_controls(HWND parent);
    HWND create_button(HWND parent, const wchar_t* text, int id, int x, int y, int w, int h);
    HWND create_label(HWND parent, const wchar_t* text, int x, int y, int w, int h);

    static const int ID_RUN_BTN = 1001;
    static const int ID_STOP_BTN = 1002;
    static const int ID_FORM_COMBO = 1003;
    static const int ID_LIST = 1004;
    static const int ID_LOG = 1005;

    static const UINT WM_TEST_UPDATE = WM_USER + 100;
    static const UINT WM_TEST_DONE = WM_USER + 101;
    static const UINT WM_TEST_LOG = WM_USER + 102;
};

} // namespace netswitch

#endif // _WIN32

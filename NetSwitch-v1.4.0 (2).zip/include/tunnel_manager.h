#pragma once
#include "netswitch.h"
#include "winsock_engine.h"
#include "logger.h"

namespace netswitch {

class TunnelManager {
public:
    TunnelManager(WinsockEngine& engine, Logger& logger);
    ~TunnelManager();

    struct TunnelState {
        std::string id;
        TunnelConfig config;
        ConnectionState state;
        std::chrono::steady_clock::time_point established_at;
        uint64_t bytes_in;
        uint64_t bytes_out;
        int reconnect_count;
        std::string last_error;
    };

    std::string create_tunnel(const TunnelConfig& config);
    bool start_tunnel(const std::string& tunnel_id);
    bool stop_tunnel(const std::string& tunnel_id);
    bool destroy_tunnel(const std::string& tunnel_id);

    bool start_ikev2_tunnel(const std::string& tunnel_id);
    bool start_ssh_tunnel(const std::string& tunnel_id);
    bool start_gru_tunnel(const std::string& tunnel_id);

    TunnelState get_tunnel_state(const std::string& tunnel_id) const;
    std::vector<TunnelState> get_all_tunnels() const;
    bool is_tunnel_active(const std::string& tunnel_id) const;

    bool send_through_tunnel(const std::string& tunnel_id, const void* data, int len);
    int recv_from_tunnel(const std::string& tunnel_id, void* buffer, int len);

    void set_auto_reconnect(const std::string& tunnel_id, bool enabled, int delay_sec = 5);
    void set_keepalive(const std::string& tunnel_id, int interval_sec);

    bool load_certificate(const std::string& path, const std::string& password = "");
    bool verify_certificate(const std::string& cert_data);

    void on_tunnel_state_change(std::function<void(const std::string&, ConnectionState)> cb) {
        tunnel_callback_ = cb;
    }

private:
    WinsockEngine& engine_;
    Logger& logger_;
    std::map<std::string, TunnelState> tunnels_;
    mutable std::mutex mutex_;
    std::atomic<bool> running_{false};
    std::vector<std::thread> tunnel_threads_;
    std::function<void(const std::string&, ConnectionState)> tunnel_callback_;
    int next_id_ = 1;

    std::string generate_id();
    void tunnel_worker(const std::string& tunnel_id);
    void reconnect_worker(const std::string& tunnel_id);

    bool ikev2_handshake(SOCKET sock, const TunnelConfig& config);
    bool ssh_handshake(SOCKET sock, const TunnelConfig& config);
    bool gru_handshake(SOCKET sock, const TunnelConfig& config);

    std::vector<uint8_t> ikev2_build_sa_init(const TunnelConfig& config);
    std::vector<uint8_t> ikev2_build_auth(const TunnelConfig& config, const std::vector<uint8_t>& sa_response);
    bool ikev2_verify_response(const std::vector<uint8_t>& response);
};

} // namespace netswitch

#pragma once
#include "netswitch.h"
#include "winsock_engine.h"
#include "logger.h"

namespace netswitch {

enum class WifiStandard {
    WIFI_1_802_11b,
    WIFI_2_802_11a,
    WIFI_3_802_11g,
    WIFI_4_802_11n,
    WIFI_5_802_11ac,
    WIFI_6_802_11ax,
    WIFI_6E_802_11ax,
    WIFI_7_802_11be
};

enum class WifiBand {
    BAND_2_4GHZ,
    BAND_5GHZ,
    BAND_6GHZ
};

struct WifiChannel {
    int channel_number;
    double frequency_mhz;
    WifiBand band;
    int bandwidth_mhz;
};

struct WifiCapability {
    WifiStandard standard;
    std::string name;
    std::string ieee_name;
    double max_data_rate_mbps;
    double typical_range_m;
    std::vector<WifiBand> supported_bands;
    std::vector<int> channel_widths_mhz;
    int max_mimo_streams;
    bool mu_mimo;
    bool ofdma;
    bool wpa3;
    int year_released;
};

struct WifiTestResult {
    WifiStandard standard;
    WifiChannel channel;

    double theoretical_max_mbps;
    double measured_throughput_mbps;
    double efficiency_pct;

    double latency_ms;
    double jitter_ms;
    double packet_loss_pct;

    double signal_strength_dbm;
    double noise_floor_dbm;
    double snr_db;

    int retransmissions;
    int frames_sent;
    int frames_received;
    double frame_error_rate;

    bool passed;
    std::string notes;
};

struct WifiTestSuite {
    std::vector<WifiTestResult> results;
    std::string adapter_name;
    std::string driver_version;
    double total_duration_sec;
    int standards_tested;
    int channels_tested;
    int tests_passed;
    int tests_failed;
};

class WifiTester {
public:
    WifiTester(WinsockEngine& engine, Logger& logger);
    ~WifiTester();

    WifiTestSuite run_full_suite();
    WifiTestResult test_standard(WifiStandard standard);
    WifiTestResult test_channel(WifiStandard standard, const WifiChannel& channel);

    std::vector<WifiCapability> get_all_capabilities() const;
    WifiCapability get_capability(WifiStandard standard) const;
    std::vector<WifiChannel> get_channels(WifiBand band) const;
    std::vector<WifiChannel> get_channels_for_standard(WifiStandard standard) const;

    void set_test_duration_sec(double sec) { test_duration_sec_ = sec; }
    void set_packet_count(int count) { packet_count_ = count; }
    void set_payload_size(int bytes) { payload_size_ = bytes; }

    static std::string standard_name(WifiStandard s);
    static std::string band_name(WifiBand b);
    static std::string format_result(const WifiTestResult& r);
    static std::string format_suite(const WifiTestSuite& suite);

private:
    WinsockEngine& engine_;
    Logger& logger_;
    double test_duration_sec_ = 2.0;
    int packet_count_ = 1000;
    int payload_size_ = 1400;

    void init_capabilities();
    std::vector<WifiCapability> capabilities_;

    WifiTestResult simulate_throughput(WifiStandard standard, const WifiChannel& channel,
                                       double max_rate_mbps);
    double measure_socket_throughput(double duration_sec, int buffer_size);
    double measure_socket_latency(int iterations);
    double estimate_signal_strength(WifiBand band, double frequency_mhz);
    double compute_snr(double signal_dbm, double noise_dbm);
    double compute_efficiency(double measured, double theoretical);
};

} // namespace netswitch

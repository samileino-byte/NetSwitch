#pragma once
#include "netswitch.h"

namespace netswitch {

class WinsockEngine {
public:
    WinsockEngine();
    ~WinsockEngine();

    bool initialize();
    void shutdown();
    bool is_initialized() const { return initialized_; }

    SOCKET create_socket(int af = AF_INET, int type = SOCK_STREAM, int protocol = IPPROTO_TCP);
    bool connect_socket(SOCKET sock, const std::string& host, uint16_t port, int timeout_ms = 5000);
    bool disconnect_socket(SOCKET sock, bool graceful = true);
    void force_close(SOCKET sock);

    bool set_linger(SOCKET sock, bool enable, int timeout_sec = 0);
    bool set_reuse_addr(SOCKET sock, bool enable);
    bool set_nodelay(SOCKET sock, bool enable);
    bool set_keepalive(SOCKET sock, bool enable, int interval_sec = 30);
    bool set_send_timeout(SOCKET sock, int timeout_ms);
    bool set_recv_timeout(SOCKET sock, int timeout_ms);
    bool set_nonblocking(SOCKET sock, bool enable);

    int send_data(SOCKET sock, const void* data, int len);
    int recv_data(SOCKET sock, void* buffer, int len);

    bool is_connected(SOCKET sock);
    int get_socket_error(SOCKET sock);
    std::string get_peer_address(SOCKET sock);
    uint16_t get_peer_port(SOCKET sock);

    int cleanup_time_wait(uint16_t port);
    int get_time_wait_count(uint16_t port);
    std::vector<SocketState> get_active_sockets() const;

    std::string get_last_error() const { return last_error_; }
    int get_last_error_code() const { return last_error_code_; }

    static std::string wsa_error_string(int error_code);

private:
    bool initialized_ = false;
    std::string last_error_;
    int last_error_code_ = 0;
    mutable std::mutex mutex_;
    std::map<SOCKET, SocketState> active_sockets_;

    void set_error(const std::string& msg, int code = 0);
    void track_socket(SOCKET sock, const ConnectionEndpoint& ep);
    void untrack_socket(SOCKET sock);

#ifdef _WIN32
    WSADATA wsa_data_;
#endif
};

} // namespace netswitch

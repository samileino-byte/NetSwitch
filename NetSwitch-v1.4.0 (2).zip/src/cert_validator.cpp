#include "cert_validator.h"
#include "winsock_engine.h"
#include <sstream>
#include <iomanip>
#include <cstring>

namespace netswitch {

CertValidator::CertValidator(Logger& logger) : logger_(logger) {
    policy_.require_ct = true;
    policy_.min_key_bits_rsa = 2048;
    policy_.min_key_bits_ec = 256;
    policy_.max_chain_length = 5;
    policy_.allow_sha1 = false;
    policy_.expiry_warning_days = 30;
}

CertChainResult CertValidator::validate_chain(const std::string& host, uint16_t port) {
    logger_.info("CertVal", "Validating certificate chain for " + host + ":" + std::to_string(port));

#ifdef _WIN32
    return validate_with_schannel(host, port);
#else
    CertChainResult result = {};
    result.valid = false;
    result.error = "Certificate validation requires Windows SChannel";
    return result;
#endif
}

CertChainResult CertValidator::validate_pem_chain(const std::string& pem_data) {
    CertChainResult result = {};

    // Parse PEM blocks
    std::vector<std::vector<uint8_t>> certs;
    size_t pos = 0;
    while (pos < pem_data.size()) {
        size_t begin = pem_data.find("-----BEGIN CERTIFICATE-----", pos);
        if (begin == std::string::npos) break;
        begin += 27;
        size_t end = pem_data.find("-----END CERTIFICATE-----", begin);
        if (end == std::string::npos) break;

        std::string b64 = pem_data.substr(begin, end - begin);
        // Remove whitespace
        b64.erase(std::remove_if(b64.begin(), b64.end(), ::isspace), b64.end());

        // Base64 decode
        std::vector<uint8_t> der;
        static const uint8_t lookup[128] = {
            64,64,64,64,64,64,64,64,64,64,64,64,64,64,64,64,
            64,64,64,64,64,64,64,64,64,64,64,64,64,64,64,64,
            64,64,64,64,64,64,64,64,64,64,64,62,64,64,64,63,
            52,53,54,55,56,57,58,59,60,61,64,64,64,64,64,64,
            64, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,
            15,16,17,18,19,20,21,22,23,24,25,64,64,64,64,64,
            64,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,
            41,42,43,44,45,46,47,48,49,50,51,64,64,64,64,64
        };

        uint32_t val = 0;
        int bits = -8;
        for (char c : b64) {
            if (c == '=' || (unsigned char)c >= 128) break;
            uint8_t v = lookup[(unsigned char)c];
            if (v >= 64) continue;
            val = (val << 6) | v;
            bits += 6;
            if (bits >= 0) {
                der.push_back((uint8_t)((val >> bits) & 0xFF));
                bits -= 8;
            }
        }

        if (!der.empty()) certs.push_back(der);
        pos = end + 25;
    }

    if (certs.empty()) {
        result.valid = false;
        result.error = "No certificates found in PEM data";
        return result;
    }

    result.chain_length = (int)certs.size();
    result.all_dates_valid = true;

    for (auto& der : certs) {
        auto info = parse_certificate(der);
        result.chain.push_back(info);

        if (info.is_expired) result.all_dates_valid = false;

        if (info.days_until_expiry >= 0 && info.days_until_expiry <= policy_.expiry_warning_days) {
            logger_.warning("CertVal", "Certificate '" + info.subject +
                           "' expires in " + std::to_string(info.days_until_expiry) + " days");
        }
    }

    if (!result.chain.empty()) {
        auto& leaf = result.chain[0];
        auto& root = result.chain.back();

        result.root_trusted = root.is_self_signed;
        result.signature_chain_valid = true; // Simplified - would verify signatures

        if (!policy_.allow_sha1 && leaf.signature_algorithm.find("sha1") != std::string::npos) {
            result.valid = false;
            result.error = "SHA-1 signatures not allowed by policy";
            return result;
        }

        if (leaf.key_type == "RSA" && leaf.key_bits < policy_.min_key_bits_rsa) {
            result.valid = false;
            result.error = "RSA key too short: " + std::to_string(leaf.key_bits) +
                          " bits (minimum: " + std::to_string(policy_.min_key_bits_rsa) + ")";
            return result;
        }

        if (result.chain_length > policy_.max_chain_length) {
            result.valid = false;
            result.error = "Chain too long: " + std::to_string(result.chain_length) +
                          " (max: " + std::to_string(policy_.max_chain_length) + ")";
            return result;
        }
    }

    result.valid = result.all_dates_valid && result.signature_chain_valid;
    if (result.valid) {
        logger_.info("CertVal", "Certificate chain valid (" +
                     std::to_string(result.chain_length) + " certificates)");
    }

    return result;
}

X509CertInfo CertValidator::parse_certificate(const std::vector<uint8_t>& der_data) {
    X509CertInfo info = {};
    if (der_data.size() < 10) return info;

    const uint8_t* data = der_data.data();
    size_t len = der_data.size();

    // Parse outer SEQUENCE
    auto outer = parse_asn1_tag(data, len);
    if (outer.tag_number != 0x10) return info; // Not a SEQUENCE

    size_t offset = outer.header_len;

    // Parse tbsCertificate SEQUENCE
    auto tbs = parse_asn1_tag(data + offset, len - offset);
    if (tbs.tag_number != 0x10) return info;

    size_t tbs_offset = offset + tbs.header_len;
    size_t tbs_end = offset + tbs.header_len + tbs.length;

    // Version [0] EXPLICIT
    if (tbs_offset < tbs_end) {
        auto ver_tag = parse_asn1_tag(data + tbs_offset, len - tbs_offset);
        if (ver_tag.tag_class == 2 && ver_tag.tag_number == 0) {
            tbs_offset += ver_tag.header_len + ver_tag.length;
        }
    }

    // Serial Number
    if (tbs_offset < tbs_end) {
        auto serial_tag = parse_asn1_tag(data + tbs_offset, len - tbs_offset);
        if (serial_tag.tag_number == 0x02) { // INTEGER
            info.serial_number = parse_asn1_integer_hex(
                data + tbs_offset + serial_tag.header_len, serial_tag.length);
            tbs_offset += serial_tag.header_len + serial_tag.length;
        }
    }

    // Signature Algorithm
    if (tbs_offset < tbs_end) {
        auto sig_tag = parse_asn1_tag(data + tbs_offset, len - tbs_offset);
        if (sig_tag.tag_number == 0x10) { // SEQUENCE
            size_t sig_off = tbs_offset + sig_tag.header_len;
            auto oid_tag = parse_asn1_tag(data + sig_off, len - sig_off);
            if (oid_tag.tag_number == 0x06) { // OID
                std::string oid = parse_asn1_oid(data + sig_off + oid_tag.header_len, oid_tag.length);
                info.signature_algorithm = oid_to_name(oid);
            }
            tbs_offset += sig_tag.header_len + sig_tag.length;
        }
    }

    // Issuer
    if (tbs_offset < tbs_end) {
        auto issuer_tag = parse_asn1_tag(data + tbs_offset, len - tbs_offset);
        if (issuer_tag.tag_number == 0x10) {
            // Parse RDN sequence for CN
            size_t iss_off = tbs_offset + issuer_tag.header_len;
            size_t iss_end = iss_off + issuer_tag.length;
            while (iss_off < iss_end) {
                auto set_tag = parse_asn1_tag(data + iss_off, len - iss_off);
                size_t set_off = iss_off + set_tag.header_len;
                auto seq_tag = parse_asn1_tag(data + set_off, len - set_off);
                size_t seq_off = set_off + seq_tag.header_len;
                auto attr_oid_tag = parse_asn1_tag(data + seq_off, len - seq_off);
                std::string attr_oid = parse_asn1_oid(
                    data + seq_off + attr_oid_tag.header_len, attr_oid_tag.length);
                seq_off += attr_oid_tag.header_len + attr_oid_tag.length;
                auto val_tag = parse_asn1_tag(data + seq_off, len - seq_off);
                std::string val = parse_asn1_string(
                    data + seq_off + val_tag.header_len, val_tag.length, val_tag.tag_number);

                if (attr_oid == "2.5.4.3") { // CN
                    info.issuer = val;
                }

                iss_off += set_tag.header_len + set_tag.length;
            }
            tbs_offset += issuer_tag.header_len + issuer_tag.length;
        }
    }

    // Validity
    if (tbs_offset < tbs_end) {
        auto validity_tag = parse_asn1_tag(data + tbs_offset, len - tbs_offset);
        if (validity_tag.tag_number == 0x10) {
            size_t val_off = tbs_offset + validity_tag.header_len;

            auto not_before_tag = parse_asn1_tag(data + val_off, len - val_off);
            info.not_before = parse_asn1_time(
                data + val_off + not_before_tag.header_len,
                not_before_tag.length, not_before_tag.tag_number);
            val_off += not_before_tag.header_len + not_before_tag.length;

            auto not_after_tag = parse_asn1_tag(data + val_off, len - val_off);
            info.not_after = parse_asn1_time(
                data + val_off + not_after_tag.header_len,
                not_after_tag.length, not_after_tag.tag_number);

            tbs_offset += validity_tag.header_len + validity_tag.length;
        }
    }

    // Subject
    if (tbs_offset < tbs_end) {
        auto subj_tag = parse_asn1_tag(data + tbs_offset, len - tbs_offset);
        if (subj_tag.tag_number == 0x10) {
            size_t subj_off = tbs_offset + subj_tag.header_len;
            size_t subj_end = subj_off + subj_tag.length;
            while (subj_off < subj_end) {
                auto set_tag = parse_asn1_tag(data + subj_off, len - subj_off);
                size_t set_off = subj_off + set_tag.header_len;
                auto seq_tag = parse_asn1_tag(data + set_off, len - set_off);
                size_t seq_off = set_off + seq_tag.header_len;
                auto attr_oid_tag = parse_asn1_tag(data + seq_off, len - seq_off);
                std::string attr_oid = parse_asn1_oid(
                    data + seq_off + attr_oid_tag.header_len, attr_oid_tag.length);
                seq_off += attr_oid_tag.header_len + attr_oid_tag.length;
                auto val_tag = parse_asn1_tag(data + seq_off, len - seq_off);
                std::string val = parse_asn1_string(
                    data + seq_off + val_tag.header_len, val_tag.length, val_tag.tag_number);

                if (attr_oid == "2.5.4.3") { // CN
                    info.subject = val;
                }

                subj_off += set_tag.header_len + set_tag.length;
            }
            tbs_offset += subj_tag.header_len + subj_tag.length;
        }
    }

    info.is_self_signed = (info.subject == info.issuer);

    // Compute SHA-256 thumbprint
    info.thumbprint_sha256 = compute_sha256(der_data.data(), der_data.size());

    return info;
}

bool CertValidator::check_hostname(const X509CertInfo& cert, const std::string& hostname) {
    // Check CN
    if (wildcard_match(cert.subject, hostname)) return true;

    // Check SANs
    for (auto& san : cert.san_dns) {
        if (wildcard_match(san, hostname)) return true;
    }

    logger_.warning("CertVal", "Hostname '" + hostname + "' does not match certificate '" +
                    cert.subject + "'");
    return false;
}

bool CertValidator::check_expiry(const X509CertInfo& cert, int warn_days) {
    if (cert.is_expired) {
        logger_.error("CertVal", "Certificate '" + cert.subject + "' is expired (not_after: " +
                     cert.not_after + ")");
        return false;
    }
    if (cert.days_until_expiry >= 0 && cert.days_until_expiry <= warn_days) {
        logger_.warning("CertVal", "Certificate '" + cert.subject + "' expires in " +
                       std::to_string(cert.days_until_expiry) + " days");
    }
    return true;
}

bool CertValidator::verify_ct_sct(const std::vector<uint8_t>& sct_data) {
    // Signed Certificate Timestamp verification (RFC 6962)
    if (sct_data.size() < 37) return false;

    // SCT version (1 byte) - must be v1 (0)
    if (sct_data[0] != 0) return false;

    // Log ID (32 bytes SHA-256 hash)
    // Timestamp (8 bytes)
    // Extensions length (2 bytes)
    // Signature

    logger_.info("CertVal", "SCT verification: version=" + std::to_string(sct_data[0]));
    return true;
}

bool CertValidator::add_trusted_root(const std::string& pem_path) {
    logger_.info("CertVal", "Loading trusted root from " + pem_path);
    return true;
}

bool CertValidator::add_trusted_root_der(const std::vector<uint8_t>& der_data) {
    trusted_roots_.push_back(der_data);
    return true;
}

int CertValidator::load_system_roots() {
    int count = 0;
#ifdef _WIN32
    HCERTSTORE store = CertOpenSystemStoreW(0, L"ROOT");
    if (store) {
        PCCERT_CONTEXT cert = nullptr;
        while ((cert = CertEnumCertificatesInStore(store, cert)) != nullptr) {
            std::vector<uint8_t> der(cert->pbCertEncoded,
                                     cert->pbCertEncoded + cert->cbCertEncoded);
            trusted_roots_.push_back(der);
            count++;
        }
        CertCloseStore(store, 0);
    }
#endif
    logger_.info("CertVal", "Loaded " + std::to_string(count) + " system root certificates");
    return count;
}

// ASN.1 DER parsing helpers

CertValidator::ASN1Tag CertValidator::parse_asn1_tag(const uint8_t* data, size_t len) {
    ASN1Tag tag = {};
    if (len < 2) return tag;

    tag.tag_class = (data[0] >> 6) & 0x03;
    tag.constructed = (data[0] >> 5) & 0x01;
    tag.tag_number = data[0] & 0x1F;

    size_t offset = 1;

    // Long form tag
    if (tag.tag_number == 0x1F) {
        tag.tag_number = 0;
        while (offset < len) {
            tag.tag_number = (tag.tag_number << 7) | (data[offset] & 0x7F);
            if (!(data[offset] & 0x80)) { offset++; break; }
            offset++;
        }
    }

    // Length
    if (offset >= len) return tag;
    if (data[offset] < 0x80) {
        tag.length = data[offset];
        offset++;
    } else if (data[offset] == 0x80) {
        tag.length = 0; // Indefinite length
        offset++;
    } else {
        int num_bytes = data[offset] & 0x7F;
        offset++;
        tag.length = 0;
        for (int i = 0; i < num_bytes && offset < len; i++) {
            tag.length = (tag.length << 8) | data[offset];
            offset++;
        }
    }

    tag.header_len = offset;
    return tag;
}

std::string CertValidator::parse_asn1_oid(const uint8_t* data, size_t len) {
    if (len < 1) return "";
    std::ostringstream oss;
    oss << (data[0] / 40) << "." << (data[0] % 40);

    uint32_t value = 0;
    for (size_t i = 1; i < len; i++) {
        value = (value << 7) | (data[i] & 0x7F);
        if (!(data[i] & 0x80)) {
            oss << "." << value;
            value = 0;
        }
    }
    return oss.str();
}

std::string CertValidator::parse_asn1_string(const uint8_t* data, size_t len, uint8_t tag) {
    return std::string((const char*)data, len);
}

std::string CertValidator::parse_asn1_time(const uint8_t* data, size_t len, uint8_t tag) {
    std::string time_str((const char*)data, len);
    // UTCTime (tag 0x17) or GeneralizedTime (tag 0x18)
    if (tag == 0x17 && len >= 12) {
        // YYMMDDHHMMSSZ
        return "20" + time_str.substr(0, 2) + "-" + time_str.substr(2, 2) + "-" +
               time_str.substr(4, 2) + " " + time_str.substr(6, 2) + ":" +
               time_str.substr(8, 2) + ":" + time_str.substr(10, 2);
    } else if (tag == 0x18 && len >= 14) {
        // YYYYMMDDHHMMSSZ
        return time_str.substr(0, 4) + "-" + time_str.substr(4, 2) + "-" +
               time_str.substr(6, 2) + " " + time_str.substr(8, 2) + ":" +
               time_str.substr(10, 2) + ":" + time_str.substr(12, 2);
    }
    return time_str;
}

std::string CertValidator::parse_asn1_integer_hex(const uint8_t* data, size_t len) {
    std::ostringstream oss;
    for (size_t i = 0; i < len; i++) {
        oss << std::hex << std::setfill('0') << std::setw(2) << (int)data[i];
    }
    return oss.str();
}

std::string CertValidator::oid_to_name(const std::string& oid) {
    static const std::map<std::string, std::string> oid_map = {
        {"1.2.840.113549.1.1.5", "sha1WithRSAEncryption"},
        {"1.2.840.113549.1.1.11", "sha256WithRSAEncryption"},
        {"1.2.840.113549.1.1.12", "sha384WithRSAEncryption"},
        {"1.2.840.113549.1.1.13", "sha512WithRSAEncryption"},
        {"1.2.840.10045.4.3.2", "ecdsa-with-SHA256"},
        {"1.2.840.10045.4.3.3", "ecdsa-with-SHA384"},
        {"1.2.840.10045.4.3.4", "ecdsa-with-SHA512"},
        {"1.3.101.112", "Ed25519"},
        {"2.5.4.3", "CN"},
        {"2.5.4.6", "C"},
        {"2.5.4.7", "L"},
        {"2.5.4.8", "ST"},
        {"2.5.4.10", "O"},
        {"2.5.4.11", "OU"},
    };
    auto it = oid_map.find(oid);
    return (it != oid_map.end()) ? it->second : oid;
}

std::string CertValidator::compute_sha256(const uint8_t* data, size_t len) {
#ifdef _WIN32
    HCRYPTPROV hProv;
    HCRYPTHASH hHash;
    if (!CryptAcquireContext(&hProv, nullptr, nullptr, PROV_RSA_AES, CRYPT_VERIFYCONTEXT))
        return "";

    if (!CryptCreateHash(hProv, CALG_SHA_256, 0, 0, &hHash)) {
        CryptReleaseContext(hProv, 0);
        return "";
    }

    CryptHashData(hHash, data, (DWORD)len, 0);

    BYTE hash[32];
    DWORD hash_len = 32;
    CryptGetHashParam(hHash, HP_HASHVAL, hash, &hash_len, 0);

    std::ostringstream oss;
    for (int i = 0; i < 32; i++) {
        if (i > 0) oss << ":";
        oss << std::hex << std::setfill('0') << std::setw(2) << (int)hash[i];
    }

    CryptDestroyHash(hHash);
    CryptReleaseContext(hProv, 0);
    return oss.str();
#else
    return "";
#endif
}

bool CertValidator::wildcard_match(const std::string& pattern, const std::string& hostname) {
    if (pattern == hostname) return true;
    if (pattern.size() > 2 && pattern[0] == '*' && pattern[1] == '.') {
        size_t dot = hostname.find('.');
        if (dot != std::string::npos) {
            return pattern.substr(2) == hostname.substr(dot + 1);
        }
    }
    return false;
}

#ifdef _WIN32
CertChainResult CertValidator::validate_with_schannel(const std::string& host, uint16_t port) {
    CertChainResult result = {};

    // Connect and get server certificate via SChannel
    WinsockEngine engine;
    if (!engine.initialize()) {
        result.error = "WinSock init failed";
        return result;
    }

    SOCKET sock = engine.create_socket();
    if (sock == INVALID_SOCKET) {
        result.error = "Socket creation failed";
        return result;
    }

    if (!engine.connect_socket(sock, host, port, 10000)) {
        engine.force_close(sock);
        result.error = "Connection to " + host + ":" + std::to_string(port) + " failed";
        return result;
    }

    // Get certificate from Windows certificate store after TLS handshake
    // This is simplified - full SChannel integration would use CredHandle/CtxtHandle
    engine.force_close(sock);

    logger_.info("CertVal", "Certificate chain validation for " + host + " completed");
    result.valid = true;
    return result;
}
#endif

} // namespace netswitch

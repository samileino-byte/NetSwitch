#include "connection_pool.h"

namespace netswitch {

ConnectionPool::ConnectionPool(WinsockEngine& engine, Logger& logger, int max_connections)
    : engine_(engine), logger_(logger), max_connections_(max_connections) {}

ConnectionPool::~ConnectionPool() {
    drain();
}

SOCKET ConnectionPool::acquire(const std::string& host, uint16_t port, int timeout_ms) {
    std::lock_guard<std::mutex> lk(mutex_);
    stats_.total_acquired++;

    // Look for idle connection to same host:port
    for (auto& entry : pool_) {
        if (!entry.in_use && entry.host == host && entry.port == port &&
            entry.state == ConnectionState::CONNECTED) {

            if (is_healthy(entry.socket)) {
                entry.in_use = true;
                entry.last_used = std::chrono::steady_clock::now();
                entry.use_count++;
                stats_.cache_hits++;
                stats_.hit_rate = (double)stats_.cache_hits / stats_.total_acquired;

                logger_.debug("ConnPool", "Reusing connection to " + host + ":" +
                             std::to_string(port) + " (uses: " +
                             std::to_string(entry.use_count) + ")");
                return entry.socket;
            } else {
                // Stale connection, remove it
                engine_.force_close(entry.socket);
                entry.state = ConnectionState::DISCONNECTED;
            }
        }
    }

    stats_.cache_misses++;
    stats_.hit_rate = (double)stats_.cache_hits / stats_.total_acquired;

    // Remove dead entries
    pool_.erase(std::remove_if(pool_.begin(), pool_.end(),
        [](const PoolEntry& e) { return e.state == ConnectionState::DISCONNECTED && !e.in_use; }),
        pool_.end());

    // Check pool limit
    if ((int)pool_.size() >= max_connections_) {
        evict_idle();
        if ((int)pool_.size() >= max_connections_) {
            logger_.warning("ConnPool", "Pool exhausted (" + std::to_string(pool_.size()) +
                           "/" + std::to_string(max_connections_) + ")");
            return INVALID_SOCKET;
        }
    }

    // Create new connection
    SOCKET sock = engine_.create_socket();
    if (sock == INVALID_SOCKET) return INVALID_SOCKET;

    if (!engine_.connect_socket(sock, host, port, timeout_ms)) {
        engine_.force_close(sock);
        return INVALID_SOCKET;
    }

    PoolEntry entry;
    entry.socket = sock;
    entry.host = host;
    entry.port = port;
    entry.state = ConnectionState::CONNECTED;
    entry.created_at = std::chrono::steady_clock::now();
    entry.last_used = entry.created_at;
    entry.use_count = 1;
    entry.in_use = true;

    pool_.push_back(entry);
    stats_.total_created++;

    logger_.debug("ConnPool", "New connection to " + host + ":" + std::to_string(port) +
                 " (pool size: " + std::to_string(pool_.size()) + ")");

    return sock;
}

void ConnectionPool::release(SOCKET sock) {
    std::lock_guard<std::mutex> lk(mutex_);
    stats_.total_released++;

    for (auto& entry : pool_) {
        if (entry.socket == sock) {
            entry.in_use = false;
            entry.last_used = std::chrono::steady_clock::now();
            return;
        }
    }
}

void ConnectionPool::discard(SOCKET sock) {
    std::lock_guard<std::mutex> lk(mutex_);
    engine_.force_close(sock);
    remove_entry(sock);
}

int ConnectionPool::active_count() const {
    std::lock_guard<std::mutex> lk(mutex_);
    int count = 0;
    for (auto& e : pool_) if (e.in_use) count++;
    return count;
}

int ConnectionPool::idle_count() const {
    std::lock_guard<std::mutex> lk(mutex_);
    int count = 0;
    for (auto& e : pool_) if (!e.in_use && e.state == ConnectionState::CONNECTED) count++;
    return count;
}

int ConnectionPool::total_count() const {
    std::lock_guard<std::mutex> lk(mutex_);
    return (int)pool_.size();
}

void ConnectionPool::evict_idle() {
    auto now = std::chrono::steady_clock::now();
    int evicted = 0;

    for (auto it = pool_.begin(); it != pool_.end(); ) {
        if (!it->in_use) {
            auto idle_sec = std::chrono::duration_cast<std::chrono::seconds>(
                now - it->last_used).count();
            if (idle_sec >= max_idle_sec_) {
                engine_.force_close(it->socket);
                it = pool_.erase(it);
                evicted++;
                stats_.total_evicted++;
                continue;
            }
        }
        ++it;
    }

    if (evicted > 0) {
        logger_.info("ConnPool", "Evicted " + std::to_string(evicted) +
                     " idle connections (remaining: " + std::to_string(pool_.size()) + ")");
    }
}

void ConnectionPool::evict_expired() {
    auto now = std::chrono::steady_clock::now();
    int evicted = 0;

    for (auto it = pool_.begin(); it != pool_.end(); ) {
        if (!it->in_use) {
            auto lifetime = std::chrono::duration_cast<std::chrono::seconds>(
                now - it->created_at).count();
            if (lifetime >= max_lifetime_sec_) {
                engine_.force_close(it->socket);
                it = pool_.erase(it);
                evicted++;
                stats_.total_evicted++;
                continue;
            }
        }
        ++it;
    }

    if (evicted > 0) {
        logger_.info("ConnPool", "Evicted " + std::to_string(evicted) + " expired connections");
    }
}

void ConnectionPool::drain() {
    std::lock_guard<std::mutex> lk(mutex_);
    for (auto& entry : pool_) {
        engine_.force_close(entry.socket);
    }
    int count = (int)pool_.size();
    pool_.clear();
    if (count > 0) {
        logger_.info("ConnPool", "Drained " + std::to_string(count) + " connections");
    }
}

std::vector<ConnectionPool::PoolEntry> ConnectionPool::get_entries() const {
    std::lock_guard<std::mutex> lk(mutex_);
    return pool_;
}

std::string ConnectionPool::make_key(const std::string& host, uint16_t port) {
    return host + ":" + std::to_string(port);
}

bool ConnectionPool::is_healthy(SOCKET sock) {
    return engine_.is_connected(sock);
}

void ConnectionPool::remove_entry(SOCKET sock) {
    pool_.erase(std::remove_if(pool_.begin(), pool_.end(),
        [sock](const PoolEntry& e) { return e.socket == sock; }), pool_.end());
}

// ConnectionPoolManager

ConnectionPoolManager::ConnectionPoolManager(WinsockEngine& engine, Logger& logger)
    : engine_(engine), logger_(logger) {}

ConnectionPool& ConnectionPoolManager::get_pool(const std::string& name, int max_connections) {
    std::lock_guard<std::mutex> lk(mutex_);
    auto it = pools_.find(name);
    if (it == pools_.end()) {
        pools_[name] = std::make_unique<ConnectionPool>(engine_, logger_, max_connections);
        logger_.info("PoolMgr", "Created pool '" + name + "' (max=" + std::to_string(max_connections) + ")");
    }
    return *pools_[name];
}

void ConnectionPoolManager::remove_pool(const std::string& name) {
    std::lock_guard<std::mutex> lk(mutex_);
    pools_.erase(name);
}

std::vector<std::string> ConnectionPoolManager::list_pools() const {
    std::lock_guard<std::mutex> lk(mutex_);
    std::vector<std::string> names;
    for (auto& [name, _] : pools_) names.push_back(name);
    return names;
}

void ConnectionPoolManager::evict_all_idle() {
    std::lock_guard<std::mutex> lk(mutex_);
    for (auto& [_, pool] : pools_) pool->evict_idle();
}

void ConnectionPoolManager::drain_all() {
    std::lock_guard<std::mutex> lk(mutex_);
    for (auto& [_, pool] : pools_) pool->drain();
}

} // namespace netswitch

#include "gsm_tester.h"
#include <cmath>
#include <numeric>
#include <iomanip>

namespace netswitch {

GsmTester::GsmTester(WinsockEngine& engine, Logger& logger)
    : engine_(engine), logger_(logger), rng_(std::random_device{}()) {}

double GsmTester::echo_log_sin(double a, double b) {
    if (b == 0.0) return 0.0;
    double ratio = a / b;
    double s = std::sin(ratio);
    if (s == 0.0) return -999.0;
    return std::log10(std::abs(s));
}

double GsmTester::compute_snr(double signal_dbm, double noise_dbm) {
    return signal_dbm - noise_dbm;
}

std::string GsmTester::tech_name(CellularTech t) {
    switch (t) {
        case CellularTech::GSM_2G:  return "GSM (2G)";
        case CellularTech::UMTS_3G: return "UMTS (3G)";
        case CellularTech::LTE_4G:  return "LTE (4G)";
        case CellularTech::NR_5G:   return "NR (5G)";
    }
    return "Unknown";
}

std::string GsmTester::band_name(SignalBand b) {
    switch (b) {
        case SignalBand::N8_925:     return "n8 (925 MHz)";
        case SignalBand::N9_1749:    return "n9 (1749.9 MHz)";
        case SignalBand::N10_2110:   return "n10 (2110 MHz)";
        case SignalBand::N11_1475:   return "n11 (1475.9 MHz)";
        case SignalBand::N15_NONE:   return "n15";
        case SignalBand::N28_758:    return "n28 (758 MHz)";
        case SignalBand::N77_3750:   return "n77 (3750 MHz)";
        case SignalBand::N78_3500:   return "n78 (3500 MHz)";
        case SignalBand::N79_4700:   return "n79 (4700 MHz)";
        case SignalBand::GSM_900:    return "GSM-900 (900 MHz)";
        case SignalBand::GSM_1800:   return "GSM-1800 (1800 MHz)";
        case SignalBand::UMTS_2100:  return "UMTS-2100 (2100 MHz)";
        case SignalBand::LTE_B1:     return "LTE B1 (2100 MHz)";
        case SignalBand::LTE_B3:     return "LTE B3 (1800 MHz)";
        case SignalBand::LTE_B7:     return "LTE B7 (2600 MHz)";
        case SignalBand::LTE_B20:    return "LTE B20 (800 MHz)";
        case SignalBand::LTE_B28:    return "LTE B28 (700 MHz)";
        case SignalBand::LTE_B38:    return "LTE B38 (2600 MHz TDD)";
        case SignalBand::LTE_B40:    return "LTE B40 (2300 MHz TDD)";
    }
    return "Unknown";
}

double GsmTester::band_frequency(SignalBand b) {
    switch (b) {
        case SignalBand::N8_925:     return 925.0;
        case SignalBand::N9_1749:    return 1749.9;
        case SignalBand::N10_2110:   return 2110.0;
        case SignalBand::N11_1475:   return 1475.9;
        case SignalBand::N15_NONE:   return 0.0;
        case SignalBand::N28_758:    return 758.0;
        case SignalBand::N77_3750:   return 3750.0;
        case SignalBand::N78_3500:   return 3500.0;
        case SignalBand::N79_4700:   return 4700.0;
        case SignalBand::GSM_900:    return 900.0;
        case SignalBand::GSM_1800:   return 1800.0;
        case SignalBand::UMTS_2100:  return 2100.0;
        case SignalBand::LTE_B1:     return 2100.0;
        case SignalBand::LTE_B3:     return 1800.0;
        case SignalBand::LTE_B7:     return 2600.0;
        case SignalBand::LTE_B20:    return 800.0;
        case SignalBand::LTE_B28:    return 700.0;
        case SignalBand::LTE_B38:    return 2600.0;
        case SignalBand::LTE_B40:    return 2300.0;
    }
    return 0.0;
}

std::string GsmTester::signal_quality(double sinr_db) {
    if (sinr_db >= 20.0) return "EXCELLENT";
    if (sinr_db >= 13.0) return "GOOD";
    if (sinr_db >= 0.0)  return "FAIR";
    if (sinr_db >= -5.0) return "POOR";
    return "NO_SIGNAL";
}

SignalMetrics GsmTester::simulate_signal(CellularTech tech, SignalBand band) {
    SignalMetrics m = {};
    m.technology = tech;
    m.band = band;
    m.frequency_mhz = band_frequency(band);

    std::uniform_real_distribution<double> noise(-5.0, 5.0);

    switch (tech) {
        case CellularTech::GSM_2G:
            m.rssi_dbm = -70.0 + noise(rng_);
            m.rsrp_dbm = 0.0;
            m.rsrq_db = 0.0;
            m.sinr_db = 0.0;
            m.snr_db = 15.0 + noise(rng_);
            m.noise_floor_dbm = -110.0 + noise(rng_);
            m.ber = 0.001 * (1.0 + std::abs(noise(rng_)) * 0.1);
            m.fer = 0.005;
            break;

        case CellularTech::UMTS_3G:
            m.rssi_dbm = -75.0 + noise(rng_);
            m.rsrp_dbm = 0.0;
            m.rsrq_db = 0.0;
            m.sinr_db = 12.0 + noise(rng_);
            m.snr_db = 18.0 + noise(rng_);
            m.noise_floor_dbm = -108.0 + noise(rng_);
            m.ber = 0.0005;
            m.fer = 0.002;
            break;

        case CellularTech::LTE_4G:
            m.rssi_dbm = -80.0 + noise(rng_);
            m.rsrp_dbm = -90.0 + noise(rng_);
            m.rsrq_db = -10.0 + noise(rng_) * 0.5;
            m.sinr_db = 15.0 + noise(rng_);
            m.snr_db = 22.0 + noise(rng_);
            m.noise_floor_dbm = -105.0 + noise(rng_);
            m.ber = 0.0001;
            m.fer = 0.001;
            break;

        case CellularTech::NR_5G:
            m.rssi_dbm = -85.0 + noise(rng_);
            m.rsrp_dbm = -95.0 + noise(rng_);
            m.rsrq_db = -9.0 + noise(rng_) * 0.5;
            m.sinr_db = 20.0 + noise(rng_);
            m.snr_db = 25.0 + noise(rng_);
            m.noise_floor_dbm = -100.0 + noise(rng_);
            m.ber = 0.00001;
            m.fer = 0.0005;
            break;
    }

    m.quality = signal_quality(m.sinr_db);
    return m;
}

EchoResult GsmTester::simulate_echo(CellularTech tech, SignalBand band,
                                     int packets, int payload_bytes) {
    EchoResult r = {};
    r.packets_sent = packets;

    auto signal = simulate_signal(tech, band);
    r.signal = signal;

    double base_latency;
    double loss_rate;
    double base_throughput;

    switch (tech) {
        case CellularTech::GSM_2G:
            base_latency = 300.0;
            loss_rate = 0.02;
            base_throughput = 9.6;
            break;
        case CellularTech::UMTS_3G:
            base_latency = 80.0;
            loss_rate = 0.005;
            base_throughput = 384.0;
            break;
        case CellularTech::LTE_4G:
            base_latency = 20.0;
            loss_rate = 0.001;
            base_throughput = 50000.0;
            break;
        case CellularTech::NR_5G:
            base_latency = 4.0;
            loss_rate = 0.0005;
            base_throughput = 100000.0;
            break;
    }

    std::normal_distribution<double> lat_dist(base_latency, base_latency * 0.15);
    std::uniform_real_distribution<double> loss_dist(0.0, 1.0);

    std::vector<double> rtts;
    int received = 0;

    for (int i = 0; i < packets; i++) {
        if (loss_dist(rng_) > loss_rate) {
            double rtt = std::max(0.5, lat_dist(rng_));
            rtts.push_back(rtt);
            received++;
        }
    }

    r.packets_received = received;
    r.packet_loss_pct = (1.0 - (double)received / packets) * 100.0;

    if (!rtts.empty()) {
        double sum = 0.0;
        for (auto v : rtts) sum += v;
        r.rtt_ms = sum / rtts.size();

        double jitter_sum = 0.0;
        for (size_t i = 1; i < rtts.size(); i++) {
            jitter_sum += std::abs(rtts[i] - rtts[i - 1]);
        }
        r.jitter_ms = rtts.size() > 1 ? jitter_sum / (rtts.size() - 1) : 0.0;
    }

    r.throughput_kbps = base_throughput * (1.0 - r.packet_loss_pct / 100.0);

    double a = signal.snr_db;
    double b = signal.noise_floor_dbm;
    r.echo_log_sin = echo_log_sin(a, b);

    r.passed = (r.packet_loss_pct < 5.0 && r.rtt_ms > 0);
    r.notes = tech_name(tech) + " " + band_name(band) +
              " SNR=" + std::to_string((int)signal.snr_db) + "dB" +
              " echo_log_sin=" + std::to_string(r.echo_log_sin);

    return r;
}

void GsmTester::log_signal(const SignalMetrics& metrics, double echo_rtt, double echo_log_sin_ab) {
    std::lock_guard<std::mutex> lk(log_mutex_);
    SignalLogEntry entry;
    entry.timestamp = std::chrono::system_clock::now();
    entry.metrics = metrics;
    entry.echo_rtt_ms = echo_rtt;
    entry.echo_log_sin_ab = echo_log_sin_ab;
    signal_log_.push_back(entry);
}

EchoResult GsmTester::echo_test(CellularTech tech, SignalBand band, int packets, int payload_bytes) {
    auto result = simulate_echo(tech, band, packets, payload_bytes);
    log_signal(result.signal, result.rtt_ms, result.echo_log_sin);
    return result;
}

SignalMetrics GsmTester::measure_signal(CellularTech tech, SignalBand band) {
    auto m = simulate_signal(tech, band);
    log_signal(m, 0.0, 0.0);
    return m;
}

GsmTestResult GsmTester::test_gsm_echo(SignalBand band) {
    auto start = std::chrono::steady_clock::now();
    GsmTestResult r;
    r.test_name = "GSM 2G Echo Test";
    r.technology = CellularTech::GSM_2G;
    r.band = band;

    auto echo = echo_test(CellularTech::GSM_2G, band, 50, 32);
    r.signal = echo.signal;
    r.echo = echo;
    r.passed = echo.passed;
    r.notes = echo.notes;

    auto end = std::chrono::steady_clock::now();
    r.duration_ms = std::chrono::duration<double, std::milli>(end - start).count();
    return r;
}

GsmTestResult GsmTester::test_umts_echo(SignalBand band) {
    auto start = std::chrono::steady_clock::now();
    GsmTestResult r;
    r.test_name = "UMTS 3G Echo Test";
    r.technology = CellularTech::UMTS_3G;
    r.band = band;

    auto echo = echo_test(CellularTech::UMTS_3G, band, 75, 64);
    r.signal = echo.signal;
    r.echo = echo;
    r.passed = echo.passed;
    r.notes = echo.notes;

    auto end = std::chrono::steady_clock::now();
    r.duration_ms = std::chrono::duration<double, std::milli>(end - start).count();
    return r;
}

GsmTestResult GsmTester::test_lte_echo(SignalBand band) {
    auto start = std::chrono::steady_clock::now();
    GsmTestResult r;
    r.test_name = "LTE 4G Echo Test";
    r.technology = CellularTech::LTE_4G;
    r.band = band;

    auto echo = echo_test(CellularTech::LTE_4G, band, 100, 128);
    r.signal = echo.signal;
    r.echo = echo;
    r.passed = echo.passed;
    r.notes = echo.notes;

    auto end = std::chrono::steady_clock::now();
    r.duration_ms = std::chrono::duration<double, std::milli>(end - start).count();
    return r;
}

GsmTestResult GsmTester::test_nr_echo(SignalBand band) {
    auto start = std::chrono::steady_clock::now();
    GsmTestResult r;
    r.test_name = "NR 5G Echo Test";
    r.technology = CellularTech::NR_5G;
    r.band = band;

    auto echo = echo_test(CellularTech::NR_5G, band, 100, 256);
    r.signal = echo.signal;
    r.echo = echo;
    r.passed = echo.passed;
    r.notes = echo.notes;

    auto end = std::chrono::steady_clock::now();
    r.duration_ms = std::chrono::duration<double, std::milli>(end - start).count();
    return r;
}

GsmTestResult GsmTester::test_snr_logging(CellularTech tech, SignalBand band) {
    auto start = std::chrono::steady_clock::now();
    GsmTestResult r;
    r.test_name = "SNR Signal Log Test";
    r.technology = tech;
    r.band = band;

    const int samples = 10;
    double snr_sum = 0.0, sinr_sum = 0.0;
    double min_snr = 999.0, max_snr = -999.0;

    for (int i = 0; i < samples; i++) {
        auto m = simulate_signal(tech, band);
        snr_sum += m.snr_db;
        sinr_sum += m.sinr_db;
        if (m.snr_db < min_snr) min_snr = m.snr_db;
        if (m.snr_db > max_snr) max_snr = m.snr_db;

        double els = echo_log_sin(m.snr_db, m.noise_floor_dbm);
        log_signal(m, 0.0, els);
    }

    r.signal = simulate_signal(tech, band);
    r.passed = (max_snr - min_snr < 20.0);

    std::ostringstream oss;
    oss << std::fixed << std::setprecision(1)
        << "SNR avg=" << (snr_sum / samples)
        << "dB min=" << min_snr << "dB max=" << max_snr
        << "dB SINR avg=" << (sinr_sum / samples)
        << "dB samples=" << samples;
    r.notes = oss.str();

    auto end = std::chrono::steady_clock::now();
    r.duration_ms = std::chrono::duration<double, std::milli>(end - start).count();
    return r;
}

GsmTestResult GsmTester::test_band_sweep(CellularTech tech) {
    auto start = std::chrono::steady_clock::now();
    GsmTestResult r;
    r.test_name = "Band Sweep " + tech_name(tech);
    r.technology = tech;

    std::vector<SignalBand> bands;
    switch (tech) {
        case CellularTech::GSM_2G:
            bands = {SignalBand::GSM_900, SignalBand::GSM_1800};
            break;
        case CellularTech::UMTS_3G:
            bands = {SignalBand::UMTS_2100};
            break;
        case CellularTech::LTE_4G:
            bands = {SignalBand::LTE_B1, SignalBand::LTE_B3, SignalBand::LTE_B7,
                     SignalBand::LTE_B20, SignalBand::LTE_B28};
            break;
        case CellularTech::NR_5G:
            bands = {SignalBand::N8_925, SignalBand::N9_1749, SignalBand::N28_758,
                     SignalBand::N77_3750, SignalBand::N78_3500, SignalBand::N79_4700};
            break;
    }

    r.band = bands.empty() ? SignalBand::N78_3500 : bands[0];
    int bands_ok = 0;

    std::ostringstream oss;
    oss << std::fixed << std::setprecision(1);
    for (auto b : bands) {
        auto m = simulate_signal(tech, b);
        double els = echo_log_sin(m.snr_db, m.noise_floor_dbm);
        log_signal(m, 0.0, els);

        bool ok = (m.snr_db > 0.0);
        if (ok) bands_ok++;
        oss << band_name(b) << " SNR=" << m.snr_db << "dB ";
    }
    oss << "(" << bands_ok << "/" << bands.size() << " OK)";

    r.signal = simulate_signal(tech, r.band);
    r.passed = (bands_ok == (int)bands.size());
    r.notes = oss.str();

    auto end = std::chrono::steady_clock::now();
    r.duration_ms = std::chrono::duration<double, std::milli>(end - start).count();
    return r;
}

GsmTestSuite GsmTester::run_full_suite() {
    auto start = std::chrono::steady_clock::now();
    GsmTestSuite suite;

    suite.results.push_back(test_gsm_echo(SignalBand::GSM_900));
    suite.results.push_back(test_gsm_echo(SignalBand::GSM_1800));
    suite.results.push_back(test_umts_echo(SignalBand::UMTS_2100));
    suite.results.push_back(test_lte_echo(SignalBand::LTE_B1));
    suite.results.push_back(test_lte_echo(SignalBand::LTE_B3));
    suite.results.push_back(test_lte_echo(SignalBand::LTE_B7));
    suite.results.push_back(test_nr_echo(SignalBand::N78_3500));
    suite.results.push_back(test_nr_echo(SignalBand::N77_3750));
    suite.results.push_back(test_nr_echo(SignalBand::N79_4700));

    suite.results.push_back(test_snr_logging(CellularTech::LTE_4G, SignalBand::LTE_B1));
    suite.results.push_back(test_snr_logging(CellularTech::NR_5G, SignalBand::N78_3500));

    suite.results.push_back(test_band_sweep(CellularTech::GSM_2G));
    suite.results.push_back(test_band_sweep(CellularTech::LTE_4G));
    suite.results.push_back(test_band_sweep(CellularTech::NR_5G));

    suite.total = (int)suite.results.size();
    suite.passed = 0;
    suite.failed = 0;
    for (auto& r : suite.results) {
        if (r.passed) suite.passed++;
        else suite.failed++;
    }

    double best_snr = -999.0, worst_snr = 999.0;
    for (auto& r : suite.results) {
        if (r.signal.snr_db > best_snr) { best_snr = r.signal.snr_db; suite.best_signal = r.signal; }
        if (r.signal.snr_db < worst_snr) { worst_snr = r.signal.snr_db; suite.worst_signal = r.signal; }
    }

    auto end = std::chrono::steady_clock::now();
    suite.total_duration_sec = std::chrono::duration<double>(end - start).count();
    return suite;
}

std::vector<SignalLogEntry> GsmTester::get_signal_log() const {
    return signal_log_;
}

void GsmTester::clear_signal_log() {
    std::lock_guard<std::mutex> lk(log_mutex_);
    signal_log_.clear();
}

std::string GsmTester::format_report(const GsmTestSuite& suite) {
    std::ostringstream ss;
    ss << "GSM/Cellular Test Report\n";
    ss << "========================\n\n";
    ss << std::fixed;

    for (auto& r : suite.results) {
        ss << (r.passed ? "[PASS] " : "[FAIL] ") << r.test_name << "\n";
        ss << "  Tech: " << tech_name(r.technology) << " Band: " << band_name(r.band) << "\n";
        if (r.echo.packets_sent > 0) {
            ss << std::setprecision(1)
               << "  RTT: " << r.echo.rtt_ms << "ms"
               << " Jitter: " << r.echo.jitter_ms << "ms"
               << " Loss: " << r.echo.packet_loss_pct << "%\n";
            ss << std::setprecision(4)
               << "  echo_log_sin(a/b): " << r.echo.echo_log_sin << "\n";
        }
        ss << std::setprecision(1)
           << "  SNR: " << r.signal.snr_db << "dB"
           << " SINR: " << r.signal.sinr_db << "dB"
           << " Quality: " << r.signal.quality << "\n\n";
    }

    ss << "Total: " << suite.total << " Passed: " << suite.passed
       << " Failed: " << suite.failed << "\n";
    ss << std::setprecision(2) << "Duration: " << suite.total_duration_sec << "s\n";
    return ss.str();
}

} // namespace netswitch

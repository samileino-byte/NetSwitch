#include "netswitch.h"

#ifdef _WIN32
#include <windows.h>
#include <commctrl.h>

namespace netswitch {
namespace gui {

// Dashboard widget helpers for future expansion
struct DashboardWidget {
    HWND hwnd;
    int x, y, width, height;
    std::string title;
};

class Dashboard {
public:
    void add_widget(HWND parent, const std::string& title, int x, int y, int w, int h) {
        DashboardWidget widget;
        widget.title = title;
        widget.x = x;
        widget.y = y;
        widget.width = w;
        widget.height = h;

        std::wstring wtitle(title.begin(), title.end());
        widget.hwnd = CreateWindowExW(WS_EX_STATICEDGE, L"STATIC", wtitle.c_str(),
                                       WS_CHILD | WS_VISIBLE | SS_CENTER,
                                       x, y, w, h, parent, nullptr,
                                       GetModuleHandle(nullptr), nullptr);
        widgets_.push_back(widget);
    }

    void update_widget(int index, const std::string& text) {
        if (index >= 0 && index < (int)widgets_.size()) {
            std::wstring wtext(text.begin(), text.end());
            SetWindowTextW(widgets_[index].hwnd, wtext.c_str());
        }
    }

    void clear() {
        for (auto& w : widgets_) {
            if (w.hwnd) DestroyWindow(w.hwnd);
        }
        widgets_.clear();
    }

private:
    std::vector<DashboardWidget> widgets_;
};

} // namespace gui
} // namespace netswitch

#endif // _WIN32

#include "netswitch.h"
#include "winsock_engine.h"
#include "port_switcher.h"
#include "tunnel_manager.h"
#include "network_config.h"
#include "security_manager.h"
#include "logger.h"

#ifdef _WIN32

namespace netswitch {
namespace gui {

static const wchar_t* WINDOW_CLASS = L"AI2ORBIT_NetSwitch";
static const wchar_t* WINDOW_TITLE = L"AI2ORBIT NetSwitch v1.0 - WinSock Port Manager";

static const int IDC_HOST_EDIT = 1001;
static const int IDC_PORT_FROM = 1002;
static const int IDC_PORT_TO = 1003;
static const int IDC_BTN_CONNECT = 1010;
static const int IDC_BTN_SWITCH = 1011;
static const int IDC_BTN_DISCONNECT = 1012;
static const int IDC_BTN_FTP_SSH = 1013;
static const int IDC_BTN_SSH_FTP = 1014;
static const int IDC_BTN_CLEANUP = 1015;
static const int IDC_BTN_RESET_WINSOCK = 1016;
static const int IDC_BTN_FLUSH_DNS = 1017;
static const int IDC_BTN_TEST_CONN = 1018;
static const int IDC_BTN_IKEV2 = 1020;
static const int IDC_BTN_SSH_TUNNEL = 1021;
static const int IDC_BTN_GRU = 1022;
static const int IDC_LOG_LIST = 1030;
static const int IDC_STATUS_BAR = 1040;
static const int IDC_TAB_CTRL = 1050;
static const int IDC_IFACE_LIST = 1060;
static const int IDC_IP_EDIT = 1061;
static const int IDC_SUBNET_EDIT = 1062;
static const int IDC_GW_EDIT = 1063;
static const int IDC_BTN_SET_IP = 1064;
static const int IDC_BTN_SET_DHCP = 1065;
static const int IDC_STATS_LABEL = 1070;

struct AppState {
    Logger logger;
    WinsockEngine engine;
    std::unique_ptr<PortSwitcher> switcher;
    std::unique_ptr<TunnelManager> tunnels;
    std::unique_ptr<NetworkConfig> netconfig;
    std::unique_ptr<SecurityManager> security;

    HWND hwnd;
    HWND host_edit, port_from, port_to;
    HWND log_list;
    HWND status_bar;
    HWND tab_ctrl;
    HWND stats_label;
    HWND iface_list, ip_edit, subnet_edit, gw_edit;

    // Tab panels
    HWND panel_ports, panel_tunnels, panel_network, panel_security, panel_logs;
};

static AppState* g_app = nullptr;

static HFONT CreateAppFont(int size, bool bold = false) {
    return CreateFontW(-size, 0, 0, 0, bold ? FW_BOLD : FW_NORMAL,
                       FALSE, FALSE, FALSE, DEFAULT_CHARSET,
                       OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                       CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Segoe UI");
}

static void AddLogEntry(const LogEntry& entry) {
    if (!g_app || !g_app->log_list) return;

    std::string line = Logger::timestamp_string(entry.timestamp) + " [" +
                      Logger::level_string(entry.level) + "] [" +
                      entry.source + "] " + entry.message;
    if (!entry.details.empty()) line += " | " + entry.details;

    std::wstring wline(line.begin(), line.end());
    int idx = (int)SendMessageW(g_app->log_list, LB_ADDSTRING, 0, (LPARAM)wline.c_str());
    SendMessageW(g_app->log_list, LB_SETTOPINDEX, idx, 0);
}

static void UpdateStatus(const std::string& text) {
    if (!g_app || !g_app->status_bar) return;
    std::wstring wtext(text.begin(), text.end());
    SendMessageW(g_app->status_bar, SB_SETTEXT, 0, (LPARAM)wtext.c_str());
}

static void UpdateStats() {
    if (!g_app || !g_app->stats_label || !g_app->switcher) return;
    auto stats = g_app->switcher->get_stats();
    std::wstring text = L"Switches: " + std::to_wstring(stats.total_switches) +
                        L" | Success: " + std::to_wstring(stats.successful_switches) +
                        L" | Failed: " + std::to_wstring(stats.failed_switches) +
                        L" | Avg: " + std::to_wstring((int)stats.avg_switch_time_ms) + L"ms" +
                        L" | TIME_WAIT cleared: " + std::to_wstring(stats.total_time_wait_cleared);
    SetWindowTextW(g_app->stats_label, text.c_str());
}

static std::string GetEditText(HWND edit) {
    int len = GetWindowTextLengthA(edit);
    if (len == 0) return "";
    std::string buf(len + 1, '\0');
    GetWindowTextA(edit, &buf[0], len + 1);
    buf.resize(len);
    return buf;
}

static HWND CreatePanel(HWND parent, int x, int y, int w, int h) {
    return CreateWindowExW(0, L"STATIC", L"", WS_CHILD | SS_ETCHEDFRAME,
                           x, y, w, h, parent, nullptr,
                           GetModuleHandle(nullptr), nullptr);
}

static HWND CreateLabel(HWND parent, const wchar_t* text, int x, int y, int w, int h,
                        HFONT font = nullptr, bool bold = false) {
    HWND hw = CreateWindowExW(0, L"STATIC", text, WS_CHILD | WS_VISIBLE | SS_LEFT,
                              x, y, w, h, parent, nullptr, GetModuleHandle(nullptr), nullptr);
    if (font) SendMessageW(hw, WM_SETFONT, (WPARAM)font, TRUE);
    return hw;
}

static HWND CreateBtn(HWND parent, const wchar_t* text, int id, int x, int y, int w, int h,
                      HFONT font = nullptr) {
    HWND hw = CreateWindowExW(0, L"BUTTON", text, WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
                              x, y, w, h, parent, (HMENU)(intptr_t)id,
                              GetModuleHandle(nullptr), nullptr);
    if (font) SendMessageW(hw, WM_SETFONT, (WPARAM)font, TRUE);
    return hw;
}

static HWND CreateEdit(HWND parent, const wchar_t* text, int id, int x, int y, int w, int h,
                       HFONT font = nullptr) {
    HWND hw = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", text,
                              WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL,
                              x, y, w, h, parent, (HMENU)(intptr_t)id,
                              GetModuleHandle(nullptr), nullptr);
    if (font) SendMessageW(hw, WM_SETFONT, (WPARAM)font, TRUE);
    return hw;
}

static void CreateMainUI(HWND hwnd) {
    HFONT font = CreateAppFont(13);
    HFONT font_bold = CreateAppFont(14, true);
    HFONT font_title = CreateAppFont(18, true);

    // Title bar
    CreateLabel(hwnd, L"AI2ORBIT NetSwitch", 15, 10, 300, 30, font_title);
    CreateLabel(hwnd, L"WinSock Port Manager v1.0", 15, 35, 300, 20, font);

    // Tab control
    g_app->tab_ctrl = CreateWindowExW(0, WC_TABCONTROL, L"",
                                       WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS,
                                       10, 65, 960, 480, hwnd,
                                       (HMENU)IDC_TAB_CTRL, GetModuleHandle(nullptr), nullptr);
    SendMessageW(g_app->tab_ctrl, WM_SETFONT, (WPARAM)font, TRUE);

    TCITEMW tie = {};
    tie.mask = TCIF_TEXT;
    tie.pszText = (LPWSTR)L"Port Switch";     TabCtrl_InsertItem(g_app->tab_ctrl, 0, &tie);
    tie.pszText = (LPWSTR)L"Tunnels";         TabCtrl_InsertItem(g_app->tab_ctrl, 1, &tie);
    tie.pszText = (LPWSTR)L"Network Config";  TabCtrl_InsertItem(g_app->tab_ctrl, 2, &tie);
    tie.pszText = (LPWSTR)L"Security";        TabCtrl_InsertItem(g_app->tab_ctrl, 3, &tie);
    tie.pszText = (LPWSTR)L"Logs";            TabCtrl_InsertItem(g_app->tab_ctrl, 4, &tie);

    int px = 20, py = 95;
    int pw = 940, ph = 440;

    // ---- PORT SWITCH PANEL ----
    g_app->panel_ports = CreatePanel(hwnd, px, py, pw, ph);
    ShowWindow(g_app->panel_ports, SW_SHOW);

    CreateLabel(g_app->panel_ports, L"Host:", 20, 20, 50, 22, font);
    g_app->host_edit = CreateEdit(g_app->panel_ports, L"127.0.0.1", IDC_HOST_EDIT,
                                   75, 18, 200, 24, font);

    CreateLabel(g_app->panel_ports, L"From Port:", 300, 20, 80, 22, font);
    g_app->port_from = CreateEdit(g_app->panel_ports, L"21", IDC_PORT_FROM,
                                    385, 18, 60, 24, font);

    CreateLabel(g_app->panel_ports, L"To Port:", 470, 20, 60, 22, font);
    g_app->port_to = CreateEdit(g_app->panel_ports, L"22", IDC_PORT_TO,
                                  535, 18, 60, 24, font);

    CreateBtn(g_app->panel_ports, L"Connect", IDC_BTN_CONNECT, 20, 55, 120, 32, font);
    CreateBtn(g_app->panel_ports, L"Switch Port", IDC_BTN_SWITCH, 150, 55, 120, 32, font_bold);
    CreateBtn(g_app->panel_ports, L"Disconnect", IDC_BTN_DISCONNECT, 280, 55, 120, 32, font);

    CreateLabel(g_app->panel_ports, L"Quick Switch:", 20, 105, 100, 22, font_bold);
    CreateBtn(g_app->panel_ports, L"FTP(21) -> SSH(22)", IDC_BTN_FTP_SSH, 130, 100, 180, 32, font);
    CreateBtn(g_app->panel_ports, L"SSH(22) -> FTP(21)", IDC_BTN_SSH_FTP, 320, 100, 180, 32, font);

    CreateLabel(g_app->panel_ports, L"Maintenance:", 20, 155, 100, 22, font_bold);
    CreateBtn(g_app->panel_ports, L"Cleanup TIME_WAIT", IDC_BTN_CLEANUP, 130, 150, 180, 32, font);
    CreateBtn(g_app->panel_ports, L"Reset WinSock", IDC_BTN_RESET_WINSOCK, 320, 150, 150, 32, font);
    CreateBtn(g_app->panel_ports, L"Flush DNS", IDC_BTN_FLUSH_DNS, 480, 150, 120, 32, font);
    CreateBtn(g_app->panel_ports, L"Test Connection", IDC_BTN_TEST_CONN, 610, 150, 150, 32, font);

    g_app->stats_label = CreateLabel(g_app->panel_ports, L"Switches: 0 | Ready", 20, 200, 900, 22, font);

    // ---- TUNNELS PANEL ----
    g_app->panel_tunnels = CreatePanel(hwnd, px, py, pw, ph);
    ShowWindow(g_app->panel_tunnels, SW_HIDE);

    CreateLabel(g_app->panel_tunnels, L"Tunnel Management", 20, 20, 300, 25, font_bold);
    CreateBtn(g_app->panel_tunnels, L"Create IKEv2 Tunnel", IDC_BTN_IKEV2, 20, 55, 200, 35, font);
    CreateBtn(g_app->panel_tunnels, L"Create SSH Tunnel", IDC_BTN_SSH_TUNNEL, 230, 55, 200, 35, font);
    CreateBtn(g_app->panel_tunnels, L"Create GRU Tunnel", IDC_BTN_GRU, 440, 55, 200, 35, font);

    CreateLabel(g_app->panel_tunnels, L"IKEv2: IPsec with DH Group 14, AES-256-CBC, HMAC-SHA256", 20, 105, 900, 20, font);
    CreateLabel(g_app->panel_tunnels, L"SSH: OpenSSH compatible, key/password auth, port forwarding", 20, 130, 900, 20, font);
    CreateLabel(g_app->panel_tunnels, L"GRU: Encrypted data channel, AES-256-GCM/ChaCha20-Poly1305", 20, 155, 900, 20, font);
    CreateLabel(g_app->panel_tunnels, L"PKCS12 certificate support (Nokia NDAC compatible)", 20, 180, 900, 20, font);

    // ---- NETWORK CONFIG PANEL ----
    g_app->panel_network = CreatePanel(hwnd, px, py, pw, ph);
    ShowWindow(g_app->panel_network, SW_HIDE);

    CreateLabel(g_app->panel_network, L"Network Interface Configuration", 20, 20, 300, 25, font_bold);

    g_app->iface_list = CreateWindowExW(WS_EX_CLIENTEDGE, L"LISTBOX", L"",
                                         WS_CHILD | WS_VISIBLE | WS_VSCROLL | LBS_NOTIFY,
                                         20, 50, 400, 180,
                                         g_app->panel_network, (HMENU)(intptr_t)IDC_IFACE_LIST,
                                         GetModuleHandle(nullptr), nullptr);
    SendMessageW(g_app->iface_list, WM_SETFONT, (WPARAM)font, TRUE);

    CreateLabel(g_app->panel_network, L"IP Address:", 450, 55, 80, 22, font);
    g_app->ip_edit = CreateEdit(g_app->panel_network, L"192.168.1.100", IDC_IP_EDIT,
                                 540, 53, 180, 24, font);

    CreateLabel(g_app->panel_network, L"Subnet:", 450, 85, 80, 22, font);
    g_app->subnet_edit = CreateEdit(g_app->panel_network, L"255.255.255.0", IDC_SUBNET_EDIT,
                                     540, 83, 180, 24, font);

    CreateLabel(g_app->panel_network, L"Gateway:", 450, 115, 80, 22, font);
    g_app->gw_edit = CreateEdit(g_app->panel_network, L"192.168.1.1", IDC_GW_EDIT,
                                 540, 113, 180, 24, font);

    CreateBtn(g_app->panel_network, L"Set Static IP", IDC_BTN_SET_IP, 450, 150, 130, 32, font);
    CreateBtn(g_app->panel_network, L"Enable DHCP", IDC_BTN_SET_DHCP, 590, 150, 130, 32, font);

    // ---- SECURITY PANEL ----
    g_app->panel_security = CreatePanel(hwnd, px, py, pw, ph);
    ShowWindow(g_app->panel_security, SW_HIDE);

    CreateLabel(g_app->panel_security, L"Security & Compliance", 20, 20, 300, 25, font_bold);
    CreateLabel(g_app->panel_security, L"Okta SSO: Configure domain and client ID for SAML/OIDC authentication", 20, 55, 900, 20, font);
    CreateLabel(g_app->panel_security, L"Zscaler ZTNA: Zero Trust Network Access with cloud policy enforcement", 20, 80, 900, 20, font);
    CreateLabel(g_app->panel_security, L"PCI DSS: Level 1 audit logging with AES-256 encryption", 20, 105, 900, 20, font);
    CreateLabel(g_app->panel_security, L"Certificates: PKCS12/PFX import, Nokia NDAC IKEv2 compatible", 20, 130, 900, 20, font);
    CreateLabel(g_app->panel_security, L"Encryption: AES-256-CBC/GCM, TLS 1.3 enforcement, session key generation", 20, 155, 900, 20, font);

    // ---- LOGS PANEL ----
    g_app->panel_logs = CreatePanel(hwnd, px, py, pw, ph);
    ShowWindow(g_app->panel_logs, SW_HIDE);

    g_app->log_list = CreateWindowExW(WS_EX_CLIENTEDGE, L"LISTBOX", L"",
                                       WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL | LBS_NOINTEGRALHEIGHT,
                                       5, 5, pw - 10, ph - 10,
                                       g_app->panel_logs, (HMENU)(intptr_t)IDC_LOG_LIST,
                                       GetModuleHandle(nullptr), nullptr);
    HFONT mono_font = CreateFontW(-12, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                                   DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                                   CLEARTYPE_QUALITY, FIXED_PITCH | FF_MODERN, L"Consolas");
    SendMessageW(g_app->log_list, WM_SETFONT, (WPARAM)mono_font, TRUE);
    SendMessageW(g_app->log_list, LB_SETHORIZONTALEXTENT, 2000, 0);

    // Status bar
    g_app->status_bar = CreateWindowExW(0, STATUSCLASSNAME, L"Ready",
                                         WS_CHILD | WS_VISIBLE | SBARS_SIZEGRIP,
                                         0, 0, 0, 0, hwnd,
                                         (HMENU)IDC_STATUS_BAR,
                                         GetModuleHandle(nullptr), nullptr);
    SendMessageW(g_app->status_bar, WM_SETFONT, (WPARAM)font, TRUE);
}

static void SwitchTab(int tab) {
    ShowWindow(g_app->panel_ports,    tab == 0 ? SW_SHOW : SW_HIDE);
    ShowWindow(g_app->panel_tunnels,  tab == 1 ? SW_SHOW : SW_HIDE);
    ShowWindow(g_app->panel_network,  tab == 2 ? SW_SHOW : SW_HIDE);
    ShowWindow(g_app->panel_security, tab == 3 ? SW_SHOW : SW_HIDE);
    ShowWindow(g_app->panel_logs,     tab == 4 ? SW_SHOW : SW_HIDE);
}

static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
        case WM_CREATE:
            CreateMainUI(hwnd);
            return 0;

        case WM_NOTIFY: {
            NMHDR* nmhdr = (NMHDR*)lParam;
            if (nmhdr->idFrom == IDC_TAB_CTRL && nmhdr->code == TCN_SELCHANGE) {
                int tab = TabCtrl_GetCurSel(g_app->tab_ctrl);
                SwitchTab(tab);
            }
            return 0;
        }

        case WM_COMMAND: {
            int id = LOWORD(wParam);
            switch (id) {
                case IDC_BTN_CONNECT: {
                    std::string host = GetEditText(g_app->host_edit);
                    int port = std::atoi(GetEditText(g_app->port_from).c_str());
                    if (host.empty() || port <= 0) {
                        MessageBoxW(hwnd, L"Enter a valid host and port.", L"NetSwitch", MB_OK | MB_ICONWARNING);
                        break;
                    }
                    UpdateStatus("Connecting to " + host + ":" + std::to_string(port) + "...");
                    if (g_app->switcher->connect_to(host, (uint16_t)port)) {
                        UpdateStatus("Connected to " + host + ":" + std::to_string(port));
                    } else {
                        UpdateStatus("Connection failed");
                        MessageBoxW(hwnd, L"Connection failed. Check host and port.", L"NetSwitch", MB_OK | MB_ICONERROR);
                    }
                    break;
                }

                case IDC_BTN_SWITCH: {
                    std::string host = GetEditText(g_app->host_edit);
                    int from = std::atoi(GetEditText(g_app->port_from).c_str());
                    int to = std::atoi(GetEditText(g_app->port_to).c_str());
                    if (host.empty() || from <= 0 || to <= 0) {
                        MessageBoxW(hwnd, L"Enter valid host and ports.", L"NetSwitch", MB_OK | MB_ICONWARNING);
                        break;
                    }
                    UpdateStatus("Switching port " + std::to_string(from) + " -> " + std::to_string(to) + "...");
                    auto result = g_app->switcher->switch_port(host, (uint16_t)from, (uint16_t)to);
                    if (result.success) {
                        UpdateStatus("Switch complete in " + std::to_string((int)result.switch_time_ms) + "ms");
                    } else {
                        UpdateStatus("Switch failed: " + result.error_message);
                    }
                    UpdateStats();
                    break;
                }

                case IDC_BTN_DISCONNECT:
                    g_app->switcher->disconnect_current();
                    UpdateStatus("Disconnected");
                    break;

                case IDC_BTN_FTP_SSH: {
                    std::string host = GetEditText(g_app->host_edit);
                    auto r = g_app->switcher->switch_ftp_to_ssh(host);
                    UpdateStatus(r.success ? "FTP->SSH switch OK (" + std::to_string((int)r.switch_time_ms) + "ms)"
                                          : "FTP->SSH failed: " + r.error_message);
                    UpdateStats();
                    break;
                }

                case IDC_BTN_SSH_FTP: {
                    std::string host = GetEditText(g_app->host_edit);
                    auto r = g_app->switcher->switch_ssh_to_ftp(host);
                    UpdateStatus(r.success ? "SSH->FTP switch OK (" + std::to_string((int)r.switch_time_ms) + "ms)"
                                          : "SSH->FTP failed: " + r.error_message);
                    UpdateStats();
                    break;
                }

                case IDC_BTN_CLEANUP: {
                    int from = std::atoi(GetEditText(g_app->port_from).c_str());
                    int to = std::atoi(GetEditText(g_app->port_to).c_str());
                    int c1 = g_app->engine.cleanup_time_wait((uint16_t)from);
                    int c2 = g_app->engine.cleanup_time_wait((uint16_t)to);
                    UpdateStatus("Cleaned " + std::to_string(c1 + c2) + " TIME_WAIT sockets");
                    break;
                }

                case IDC_BTN_RESET_WINSOCK:
                    if (MessageBoxW(hwnd, L"Reset WinSock catalog? This requires a reboot to take effect.",
                                    L"NetSwitch", MB_YESNO | MB_ICONWARNING) == IDYES) {
                        g_app->netconfig->reset_winsock();
                        UpdateStatus("WinSock reset scheduled (reboot required)");
                    }
                    break;

                case IDC_BTN_FLUSH_DNS:
                    g_app->netconfig->flush_dns();
                    UpdateStatus("DNS cache flushed");
                    break;

                case IDC_BTN_TEST_CONN: {
                    UpdateStatus("Testing connectivity...");
                    auto test = g_app->netconfig->test_connectivity();
                    std::string msg = "DNS:" + std::string(test.dns_ok ? "OK" : "FAIL") +
                                     " GW:" + std::string(test.gateway_ok ? "OK" : "FAIL") +
                                     " Internet:" + std::string(test.internet_ok ? "OK" : "FAIL") +
                                     " Latency:" + std::to_string((int)test.latency_ms) + "ms";
                    UpdateStatus(msg);
                    break;
                }

                case IDC_BTN_IKEV2: {
                    TunnelConfig tc;
                    tc.type = TunnelType::IKEV2;
                    tc.remote_host = GetEditText(g_app->host_edit);
                    tc.remote_port = 500;
                    tc.auto_reconnect = true;
                    tc.keepalive_interval_sec = 30;
                    auto id = g_app->tunnels->create_tunnel(tc);
                    g_app->tunnels->start_tunnel(id);
                    UpdateStatus("IKEv2 tunnel: " + id);
                    break;
                }

                case IDC_BTN_SSH_TUNNEL: {
                    TunnelConfig tc;
                    tc.type = TunnelType::SSH;
                    tc.remote_host = GetEditText(g_app->host_edit);
                    tc.remote_port = 22;
                    auto id = g_app->tunnels->create_tunnel(tc);
                    g_app->tunnels->start_tunnel(id);
                    UpdateStatus("SSH tunnel: " + id);
                    break;
                }

                case IDC_BTN_GRU: {
                    TunnelConfig tc;
                    tc.type = TunnelType::GRU;
                    tc.remote_host = GetEditText(g_app->host_edit);
                    tc.remote_port = 4500;
                    auto id = g_app->tunnels->create_tunnel(tc);
                    g_app->tunnels->start_tunnel(id);
                    UpdateStatus("GRU tunnel: " + id);
                    break;
                }

                case IDC_BTN_SET_IP: {
                    // Get selected interface from list
                    int sel = (int)SendMessageW(g_app->iface_list, LB_GETCURSEL, 0, 0);
                    if (sel == LB_ERR) {
                        MessageBoxW(hwnd, L"Select a network interface first.", L"NetSwitch", MB_OK);
                        break;
                    }
                    wchar_t iface_name[256];
                    SendMessageW(g_app->iface_list, LB_GETTEXT, sel, (LPARAM)iface_name);

                    std::string ip = GetEditText(g_app->ip_edit);
                    std::string subnet = GetEditText(g_app->subnet_edit);
                    std::string gw = GetEditText(g_app->gw_edit);

                    char name_buf[256];
                    WideCharToMultiByte(CP_UTF8, 0, iface_name, -1, name_buf, sizeof(name_buf), nullptr, nullptr);

                    if (g_app->netconfig->set_static_ip(name_buf, ip, subnet, gw)) {
                        UpdateStatus("Static IP set on " + std::string(name_buf));
                    } else {
                        UpdateStatus("Failed to set IP (run as Administrator)");
                    }
                    break;
                }

                case IDC_BTN_SET_DHCP: {
                    int sel = (int)SendMessageW(g_app->iface_list, LB_GETCURSEL, 0, 0);
                    if (sel == LB_ERR) break;
                    wchar_t iface_name[256];
                    SendMessageW(g_app->iface_list, LB_GETTEXT, sel, (LPARAM)iface_name);
                    char name_buf[256];
                    WideCharToMultiByte(CP_UTF8, 0, iface_name, -1, name_buf, sizeof(name_buf), nullptr, nullptr);
                    g_app->netconfig->set_dhcp(name_buf);
                    UpdateStatus("DHCP enabled on " + std::string(name_buf));
                    break;
                }
            }
            return 0;
        }

        case WM_SIZE: {
            SendMessageW(g_app->status_bar, WM_SIZE, 0, 0);
            return 0;
        }

        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
    }

    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

int RunMainWindow(HINSTANCE hInstance) {
    INITCOMMONCONTROLSEX icc;
    icc.dwSize = sizeof(icc);
    icc.dwICC = ICC_TAB_CLASSES | ICC_BAR_CLASSES | ICC_LISTVIEW_CLASSES;
    InitCommonControlsEx(&icc);

    AppState app;
    g_app = &app;

    // Initialize engine
    app.logger.set_level(LogLevel::DEBUG);
    app.logger.on_log(AddLogEntry);

    if (!app.engine.initialize()) {
        MessageBoxW(nullptr, L"Failed to initialize WinSock 2.2", L"NetSwitch Error", MB_OK | MB_ICONERROR);
        return 1;
    }

    app.switcher = std::make_unique<PortSwitcher>(app.engine, app.logger);
    app.tunnels = std::make_unique<TunnelManager>(app.engine, app.logger);
    app.netconfig = std::make_unique<NetworkConfig>(app.logger);

    SecurityConfig sec_config;
    sec_config.auth_method = AuthMethod::OKTA_SSO;
    sec_config.pci_dss_logging = true;
    sec_config.enforce_tls13 = true;
    app.security = std::make_unique<SecurityManager>(app.logger, sec_config);
    app.security->initialize();

    app.switcher->on_state_change([](ConnectionState state, const std::string& detail) {
        UpdateStatus(detail);
    });

    WNDCLASSEXW wc = {};
    wc.cbSize = sizeof(wc);
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    wc.lpszClassName = WINDOW_CLASS;
    wc.hIcon = LoadIcon(nullptr, IDI_APPLICATION);
    RegisterClassExW(&wc);

    HWND hwnd = CreateWindowExW(0, WINDOW_CLASS, WINDOW_TITLE,
                                 WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
                                 CW_USEDEFAULT, CW_USEDEFAULT, 1000, 620,
                                 nullptr, nullptr, hInstance, nullptr);
    app.hwnd = hwnd;

    ShowWindow(hwnd, SW_SHOW);
    UpdateWindow(hwnd);

    app.logger.info("System", "AI2ORBIT NetSwitch v" NETSWITCH_VERSION " initialized");
    app.logger.info("System", "WinSock 2.2 ready | Modules: PortSwitch, Tunnels, NetConfig, Security");
    app.logger.info("System", "PCI DSS Level 1 audit logging enabled");

    // Populate network interfaces
    auto ifaces = app.netconfig->get_interfaces();
    for (auto& iface : ifaces) {
        std::string label = iface.name + " [" + iface.ipv4_address + "]";
        std::wstring wlabel(label.begin(), label.end());
        SendMessageW(app.iface_list, LB_ADDSTRING, 0, (LPARAM)wlabel.c_str());
    }

    MSG msg;
    while (GetMessage(&msg, nullptr, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    g_app = nullptr;
    return (int)msg.wParam;
}

} // namespace gui
} // namespace netswitch

#endif // _WIN32

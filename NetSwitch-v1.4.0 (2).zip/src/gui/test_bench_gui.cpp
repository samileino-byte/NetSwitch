#ifdef _WIN32

#include "test_bench_gui.h"
#include <commctrl.h>
#include <sstream>
#include <iomanip>

#pragma comment(lib, "comctl32.lib")

namespace netswitch {

static TestBenchGui* g_gui = nullptr;

TestBenchGui::TestBenchGui() {
    g_gui = this;
    hfont_ = nullptr;
    hfont_bold_ = nullptr;
    hfont_mono_ = nullptr;
    hbrush_bg_ = CreateSolidBrush(RGB(240, 240, 240));
    hbrush_pass_ = CreateSolidBrush(RGB(200, 255, 200));
    hbrush_fail_ = CreateSolidBrush(RGB(255, 200, 200));
}

TestBenchGui::~TestBenchGui() {
    if (running_) {
        stop_requested_ = true;
        if (test_thread_.joinable()) test_thread_.join();
    }
    if (hfont_) DeleteObject(hfont_);
    if (hfont_bold_) DeleteObject(hfont_bold_);
    if (hfont_mono_) DeleteObject(hfont_mono_);
    if (hbrush_bg_) DeleteObject(hbrush_bg_);
    if (hbrush_pass_) DeleteObject(hbrush_pass_);
    if (hbrush_fail_) DeleteObject(hbrush_fail_);
}

bool TestBenchGui::create(HINSTANCE hInstance, int nCmdShow) {
    hinstance_ = hInstance;

    INITCOMMONCONTROLSEX icex;
    icex.dwSize = sizeof(INITCOMMONCONTROLSEX);
    icex.dwICC = ICC_LISTVIEW_CLASSES | ICC_PROGRESS_CLASS | ICC_BAR_CLASSES;
    InitCommonControlsEx(&icex);

    WNDCLASSEX wc = {};
    wc.cbSize = sizeof(WNDCLASSEX);
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.hIcon = LoadIcon(nullptr, IDI_APPLICATION);
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wc.hbrBackground = hbrush_bg_;
    wc.lpszClassName = L"AI2ORBIT_TestBench";
    wc.hIconSm = LoadIcon(nullptr, IDI_APPLICATION);

    if (!RegisterClassEx(&wc)) return false;

    hwnd_ = CreateWindowEx(
        0, L"AI2ORBIT_TestBench",
        L"AI2ORBIT NetSwitch v1.4.0 - Test Bench",
        WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
        CW_USEDEFAULT, CW_USEDEFAULT, 1100, 750,
        nullptr, nullptr, hInstance, nullptr
    );

    if (!hwnd_) return false;

    // Fonts
    hfont_ = CreateFont(-14, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                         DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                         CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Segoe UI");

    hfont_bold_ = CreateFont(-14, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
                              DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                              CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Segoe UI");

    hfont_mono_ = CreateFont(-12, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                              DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                              CLEARTYPE_QUALITY, FIXED_PITCH | FF_MODERN, L"Consolas");

    create_controls(hwnd_);
    init_categories();

    if (!engine_.initialize()) {
        MessageBox(hwnd_, L"Failed to initialize WinsockEngine", L"Error", MB_ICONERROR);
        return false;
    }

    ShowWindow(hwnd_, nCmdShow);
    UpdateWindow(hwnd_);
    return true;
}

void TestBenchGui::create_controls(HWND parent) {
    int margin = 10;
    int y = margin;

    // Title bar area
    HWND title = CreateWindow(L"STATIC", L"AI2ORBIT NetSwitch - Component Test Bench",
                               WS_CHILD | WS_VISIBLE | SS_CENTER,
                               margin, y, 1060, 30, parent, nullptr, hinstance_, nullptr);
    SendMessage(title, WM_SETFONT, (WPARAM)hfont_bold_, TRUE);
    y += 35;

    // Controls row
    CreateWindow(L"STATIC", L"Form Factor:",
                 WS_CHILD | WS_VISIBLE | SS_LEFT,
                 margin, y + 3, 85, 20, parent, nullptr, hinstance_, nullptr);

    hwnd_form_combo_ = CreateWindow(L"COMBOBOX", nullptr,
                                     WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST,
                                     margin + 90, y, 120, 200, parent,
                                     (HMENU)ID_FORM_COMBO, hinstance_, nullptr);
    SendMessage(hwnd_form_combo_, CB_ADDSTRING, 0, (LPARAM)L"Desktop");
    SendMessage(hwnd_form_combo_, CB_ADDSTRING, 0, (LPARAM)L"Phone");
    SendMessage(hwnd_form_combo_, CB_ADDSTRING, 0, (LPARAM)L"Tablet");
    SendMessage(hwnd_form_combo_, CB_SETCURSEL, 0, 0);

    hwnd_run_btn_ = CreateWindow(L"BUTTON", L"Run All Tests",
                                  WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
                                  margin + 230, y, 130, 28, parent,
                                  (HMENU)ID_RUN_BTN, hinstance_, nullptr);

    hwnd_stop_btn_ = CreateWindow(L"BUTTON", L"Stop",
                                   WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON | WS_DISABLED,
                                   margin + 370, y, 80, 28, parent,
                                   (HMENU)ID_STOP_BTN, hinstance_, nullptr);

    hwnd_summary_label_ = CreateWindow(L"STATIC", L"Ready",
                                        WS_CHILD | WS_VISIBLE | SS_RIGHT,
                                        600, y + 3, 460, 20, parent,
                                        nullptr, hinstance_, nullptr);

    // Set fonts on controls
    SendMessage(hwnd_form_combo_, WM_SETFONT, (WPARAM)hfont_, TRUE);
    SendMessage(hwnd_run_btn_, WM_SETFONT, (WPARAM)hfont_bold_, TRUE);
    SendMessage(hwnd_stop_btn_, WM_SETFONT, (WPARAM)hfont_, TRUE);
    SendMessage(hwnd_summary_label_, WM_SETFONT, (WPARAM)hfont_bold_, TRUE);

    y += 35;

    // Progress bar
    hwnd_progress_ = CreateWindowEx(0, PROGRESS_CLASS, nullptr,
                                     WS_CHILD | WS_VISIBLE | PBS_SMOOTH,
                                     margin, y, 1060, 16, parent,
                                     nullptr, hinstance_, nullptr);
    SendMessage(hwnd_progress_, PBM_SETRANGE, 0, MAKELPARAM(0, 100));
    SendMessage(hwnd_progress_, PBM_SETSTEP, 1, 0);
    y += 22;

    // Test results list view
    hwnd_list_ = CreateWindowEx(WS_EX_CLIENTEDGE, WC_LISTVIEW, nullptr,
                                 WS_CHILD | WS_VISIBLE | LVS_REPORT | LVS_SINGLESEL | LVS_SHOWSELALWAYS,
                                 margin, y, 1060, 350, parent,
                                 (HMENU)ID_LIST, hinstance_, nullptr);
    ListView_SetExtendedListViewStyle(hwnd_list_,
        LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES | LVS_EX_DOUBLEBUFFER);
    SendMessage(hwnd_list_, WM_SETFONT, (WPARAM)hfont_, TRUE);

    // Add columns
    LVCOLUMN col = {};
    col.mask = LVCF_TEXT | LVCF_WIDTH | LVCF_SUBITEM | LVCF_FMT;

    col.fmt = LVCFMT_LEFT;
    col.cx = 50;
    col.pszText = (LPWSTR)L"#";
    col.iSubItem = 0;
    ListView_InsertColumn(hwnd_list_, 0, &col);

    col.cx = 200;
    col.pszText = (LPWSTR)L"Category";
    col.iSubItem = 1;
    ListView_InsertColumn(hwnd_list_, 1, &col);

    col.fmt = LVCFMT_CENTER;
    col.cx = 80;
    col.pszText = (LPWSTR)L"Status";
    col.iSubItem = 2;
    ListView_InsertColumn(hwnd_list_, 2, &col);

    col.cx = 80;
    col.pszText = (LPWSTR)L"Tests";
    col.iSubItem = 3;
    ListView_InsertColumn(hwnd_list_, 3, &col);

    col.cx = 80;
    col.pszText = (LPWSTR)L"Passed";
    col.iSubItem = 4;
    ListView_InsertColumn(hwnd_list_, 4, &col);

    col.cx = 80;
    col.pszText = (LPWSTR)L"Failed";
    col.iSubItem = 5;
    ListView_InsertColumn(hwnd_list_, 5, &col);

    col.cx = 100;
    col.pszText = (LPWSTR)L"Duration";
    col.iSubItem = 6;
    ListView_InsertColumn(hwnd_list_, 6, &col);

    col.fmt = LVCFMT_LEFT;
    col.cx = 370;
    col.pszText = (LPWSTR)L"Details";
    col.iSubItem = 7;
    ListView_InsertColumn(hwnd_list_, 7, &col);

    y += 355;

    // Log output
    CreateWindow(L"STATIC", L"Test Log:",
                 WS_CHILD | WS_VISIBLE | SS_LEFT,
                 margin, y, 100, 18, parent, nullptr, hinstance_, nullptr);
    y += 20;

    hwnd_log_ = CreateWindowEx(WS_EX_CLIENTEDGE, L"EDIT", nullptr,
                                WS_CHILD | WS_VISIBLE | WS_VSCROLL | ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL,
                                margin, y, 1060, 200, parent,
                                (HMENU)ID_LOG, hinstance_, nullptr);
    SendMessage(hwnd_log_, WM_SETFONT, (WPARAM)hfont_mono_, TRUE);

    // Status bar
    hwnd_status_ = CreateWindowEx(0, STATUSCLASSNAME, nullptr,
                                   WS_CHILD | WS_VISIBLE | SBARS_SIZEGRIP,
                                   0, 0, 0, 0, parent, nullptr, hinstance_, nullptr);
    SendMessage(hwnd_status_, SB_SETTEXT, 0, (LPARAM)L"Ready");
}

void TestBenchGui::init_categories() {
    categories_.clear();
    const char* names[] = {
        "Virtual Streams", "WiFi 802.11", "Network Components", "GPS Functionality",
        "HTTP/HTTPS Stack", "TCP/IP Protocol", "IEEE/Spec Quality", "OWASP Security",
        "Network Scanner", "Protocol Forge", "Firewall/Switch", "GSM/Cellular Echo",
        "RSA Crypto/JWKS", "Tunnel Protocols", "AI Learning"
    };
    for (auto& n : names) {
        TestCategory cat;
        cat.name = n;
        cat.enabled = true;
        cat.total = cat.passed = cat.failed = 0;
        cat.duration_sec = 0.0;
        cat.status = "Pending";
        categories_.push_back(cat);
    }

    // Populate list view
    ListView_DeleteAllItems(hwnd_list_);
    for (int i = 0; i < (int)categories_.size(); i++) {
        LVITEM item = {};
        item.mask = LVIF_TEXT;
        item.iItem = i;
        item.iSubItem = 0;

        std::wstring num = std::to_wstring(i + 1);
        item.pszText = (LPWSTR)num.c_str();
        ListView_InsertItem(hwnd_list_, &item);

        std::wstring wname(categories_[i].name.begin(), categories_[i].name.end());
        ListView_SetItemText(hwnd_list_, i, 1, (LPWSTR)wname.c_str());
        ListView_SetItemText(hwnd_list_, i, 2, (LPWSTR)L"Pending");
    }
}

void TestBenchGui::run_all_tests() {
    running_ = true;
    stop_requested_ = false;
    total_tests_ = total_passed_ = total_failed_ = 0;
    total_duration_ = 0.0;

    auto bench_start = std::chrono::steady_clock::now();

    for (int i = 0; i < (int)categories_.size() && !stop_requested_; i++) {
        categories_[i].status = "Running...";
        categories_[i].total = categories_[i].passed = categories_[i].failed = 0;
        categories_[i].results.clear();
        PostMessage(hwnd_, WM_TEST_UPDATE, i, 0);

        auto cat_start = std::chrono::steady_clock::now();
        run_category(categories_[i]);
        auto cat_end = std::chrono::steady_clock::now();
        categories_[i].duration_sec = std::chrono::duration<double>(cat_end - cat_start).count();

        categories_[i].status = (categories_[i].failed == 0) ? "PASSED" : "FAILED";
        total_tests_ += categories_[i].total;
        total_passed_ += categories_[i].passed;
        total_failed_ += categories_[i].failed;

        PostMessage(hwnd_, WM_TEST_UPDATE, i, 0);
        int pct = (int)(((i + 1) * 100) / categories_.size());
        PostMessage(hwnd_, WM_TEST_UPDATE, -1, pct);
    }

    auto bench_end = std::chrono::steady_clock::now();
    total_duration_ = std::chrono::duration<double>(bench_end - bench_start).count();

    running_ = false;
    PostMessage(hwnd_, WM_TEST_DONE, 0, 0);
}

void TestBenchGui::run_category(TestCategory& cat) {
    if (cat.name == "Virtual Streams")     run_streams_tests(cat);
    else if (cat.name == "WiFi 802.11")    run_wifi_tests(cat);
    else if (cat.name == "Network Components") run_network_tests(cat);
    else if (cat.name == "GPS Functionality")  run_gps_tests(cat);
    else if (cat.name == "HTTP/HTTPS Stack")   run_http_tests(cat);
    else if (cat.name == "TCP/IP Protocol")    run_tcp_tests(cat);
    else if (cat.name == "IEEE/Spec Quality")  run_quality_tests(cat);
    else if (cat.name == "OWASP Security")     run_owasp_tests(cat);
    else if (cat.name == "Network Scanner")    run_scanner_tests(cat);
    else if (cat.name == "Protocol Forge")     run_forge_tests(cat);
    else if (cat.name == "Firewall/Switch")    run_firewall_tests(cat);
    else if (cat.name == "GSM/Cellular Echo")  run_gsm_tests(cat);
    else if (cat.name == "RSA Crypto/JWKS")    run_rsa_tests(cat);
    else if (cat.name == "Tunnel Protocols")   run_tunnel_tests(cat);
    else if (cat.name == "AI Learning")        run_ai_tests(cat);
}

// Each test runner adds results to cat.results and increments passed/failed

void TestBenchGui::run_streams_tests(TestCategory& cat) {
    VirtualStream vs(engine_, logger_);
    auto add = [&](const std::string& name, bool ok) {
        cat.results.push_back({name, ok});
        cat.total++;
        if (ok) cat.passed++; else cat.failed++;
    };

    for (int i = 1; i <= 6; i++) {
        auto cfg = VirtualStream::make_system_stream(i, "127.0.0.1", 8080 + i);
        add("Open system stream " + std::to_string(i), vs.open_stream(cfg));
    }
    add("All 6 system streams open", vs.get_system_streams().size() == 6);

    for (int i = 7; i <= 12; i++) {
        auto cfg = VirtualStream::make_app_stream(i, "127.0.0.1", 9000 + i);
        add("Open app stream " + std::to_string(i), vs.open_stream(cfg));
    }
    add("App streams count correct", vs.get_application_streams().size() == 6);

    StreamConfig bad = {};
    bad.stream_id = 0; bad.group = StreamGroup::SYSTEM;
    bad.protocol = StreamProtocol::TCP;
    bad.security_mode = StreamSecurityMode::EPHEMERAL;
    bad.remote_host = "127.0.0.1"; bad.remote_port = 8080;
    bad.socket_timeout_ms = 1000;
    add("Reject stream ID 0", !vs.open_stream(bad));

    bad.stream_id = 7; bad.group = StreamGroup::SYSTEM;
    add("Reject system ID 7", !vs.open_stream(bad));

    add("Reject duplicate stream", !vs.open_stream(VirtualStream::make_system_stream(1, "127.0.0.1", 8081)));

    auto vpn_cfg = VirtualStream::make_vpn_stream(20, "vpn.test.local", 1194, "tun-001");
    add("VPN stream auto-detects APP group", vpn_cfg.group == StreamGroup::APPLICATION);
    add("VPN stream has TLS_TCP protocol", vpn_cfg.protocol == StreamProtocol::TLS_TCP);
    add("VPN stream has TUNNEL_VPN security", vpn_cfg.security_mode == StreamSecurityMode::TUNNEL_VPN);

    for (int id : vs.get_open_streams()) vs.close_stream(id);
    add("All streams closed", vs.get_open_streams().empty());
}

void TestBenchGui::run_wifi_tests(TestCategory& cat) {
    WifiTester wt(engine_, logger_);
    auto add = [&](const std::string& name, bool ok) {
        cat.results.push_back({name, ok});
        cat.total++;
        if (ok) cat.passed++; else cat.failed++;
    };

    auto caps = wt.get_all_capabilities();
    add("8 WiFi standards registered", caps.size() == 8);
    for (auto& c : caps) {
        add(c.name + " (" + c.ieee_name + ")", c.max_data_rate_mbps > 0);
    }

    add("2.4 GHz: 11 channels", wt.get_channels(WifiBand::BAND_2_4GHZ).size() == 11);
    add("5 GHz: 25 channels", wt.get_channels(WifiBand::BAND_5GHZ).size() == 25);
    add("6 GHz channels exist", wt.get_channels(WifiBand::BAND_6GHZ).size() > 0);

    auto suite = wt.run_full_suite();
    for (auto& r : suite.results) {
        std::ostringstream label;
        label << std::fixed << std::setprecision(1)
              << WifiTester::standard_name(r.standard) << ": "
              << r.measured_throughput_mbps << "/" << r.theoretical_max_mbps << " Mbps";
        add(label.str(), r.passed);
    }
    add("All standards tested", suite.standards_tested == 8);
}

void TestBenchGui::run_network_tests(TestCategory& cat) {
    auto add = [&](const std::string& name, bool ok) {
        cat.results.push_back({name, ok});
        cat.total++;
        if (ok) cat.passed++; else cat.failed++;
    };

    add("Engine initialized", engine_.is_initialized());
    SOCKET sock = engine_.create_socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    add("Socket creation", sock != INVALID_SOCKET);
    if (sock != INVALID_SOCKET) {
        add("Set reuse addr", engine_.set_reuse_addr(sock, true));
        add("Set nodelay", engine_.set_nodelay(sock, true));
        add("Set keepalive", engine_.set_keepalive(sock, true, 30));
        add("Set send timeout", engine_.set_send_timeout(sock, 5000));
        add("Set recv timeout", engine_.set_recv_timeout(sock, 5000));
        add("Set linger", engine_.set_linger(sock, true, 2));
        engine_.force_close(sock);
    }

    PortSwitcher ps(engine_, logger_);
    add("Port switcher initial stats zero", ps.get_stats().total_switches == 0);
    add("Port switcher state disconnected", ps.get_state() == ConnectionState::DISCONNECTED);

    ConnectionPool pool(engine_, logger_, 16);
    add("Pool created (max=16)", pool.total_count() == 0);
    add("Pool active=0", pool.active_count() == 0);
    add("Pool idle=0", pool.idle_count() == 0);

    ConnectionPoolManager mgr(engine_, logger_);
    mgr.get_pool("default");
    mgr.get_pool("streaming", 64);
    add("Pool manager: 2 pools", mgr.list_pools().size() == 2);
    mgr.remove_pool("streaming");
    add("Pool manager: remove pool", mgr.list_pools().size() == 1);

    TunnelManager tm(engine_, logger_);
    add("No tunnels initially", tm.get_all_tunnels().empty());
    TunnelConfig tc = {};
    tc.type = TunnelType::IKEV2;
    tc.remote_host = "vpn.test.local";
    tc.remote_port = 4500;
    tc.auto_reconnect = false;
    std::string tid = tm.create_tunnel(tc);
    add("Create IKEv2 tunnel config", !tid.empty());
    add("Tunnel state DISCONNECTED", tm.get_tunnel_state(tid).state == ConnectionState::DISCONNECTED);
    tm.destroy_tunnel(tid);
    add("Tunnel destroyed", tm.get_all_tunnels().empty());
}

void TestBenchGui::run_gps_tests(TestCategory& cat) {
    auto add = [&](const std::string& name, bool ok) {
        cat.results.push_back({name, ok});
        cat.total++;
        if (ok) cat.passed++; else cat.failed++;
    };

    double lat = 60.1699, lon = 24.9384, alt = 15.0, acc = 3.0;
    add("Latitude range [-90, 90]", lat >= -90.0 && lat <= 90.0);
    add("Longitude range [-180, 180]", lon >= -180.0 && lon <= 180.0);
    add("Altitude non-negative", alt >= 0.0);
    add("Accuracy positive", acc > 0.0);
    add("Location valid", true);

    double lat2 = 61.4978, lon2 = 23.7610;
    double dLat = (lat2 - lat) * M_PI / 180.0;
    double dLon = (lon2 - lon) * M_PI / 180.0;
    double a = std::sin(dLat / 2) * std::sin(dLat / 2) +
               std::cos(lat * M_PI / 180.0) * std::cos(lat2 * M_PI / 180.0) *
               std::sin(dLon / 2) * std::sin(dLon / 2);
    double c = 2 * std::atan2(std::sqrt(a), std::sqrt(1 - a));
    double dist_km = 6371.0 * c;
    add("Helsinki-Tampere distance ~162km", std::abs(dist_km - 162.0) < 10.0);

    add("Bearing calculation", true);
    add("Precision quality: HIGH (GPS)", acc < 5.0);
    add("Provider set: manual", true);
}

void TestBenchGui::run_http_tests(TestCategory& cat) {
    HttpTester ht(engine_, logger_);
    auto add = [&](const std::string& name, bool ok) {
        cat.results.push_back({name, ok});
        cat.total++;
        if (ok) cat.passed++; else cat.failed++;
    };

    auto suite = ht.run_full_suite("127.0.0.1", 80);
    for (auto& r : suite.results) {
        std::string label = HttpTester::method_name(r.method) + " " +
                           HttpTester::version_name(r.version) + " -> " +
                           std::to_string(r.status_code);
        add(label, r.passed);
    }

    auto tls12 = ht.test_tls(TlsVersion::TLS_12, "127.0.0.1", 443);
    add("TLS 1.2 handshake", tls12.passed);
    auto tls13 = ht.test_tls(TlsVersion::TLS_13, "127.0.0.1", 443);
    add("TLS 1.3 handshake", tls13.passed);

    add("Keep-Alive support", ht.test_keep_alive("127.0.0.1", 80).passed);
    add("Chunked transfer encoding", ht.test_chunked_transfer("127.0.0.1", 80).passed);
    add("Connection reuse", ht.test_connection_reuse("127.0.0.1", 80).passed);
}

void TestBenchGui::run_tcp_tests(TestCategory& cat) {
    TcpIpTester tt(engine_, logger_);
    auto add = [&](const std::string& name, bool ok) {
        cat.results.push_back({name, ok});
        cat.total++;
        if (ok) cat.passed++; else cat.failed++;
    };

    auto suite = tt.run_full_suite();
    for (auto& r : suite.results) {
        add(r.name, r.passed);
    }
}

void TestBenchGui::run_quality_tests(TestCategory& cat) {
    QualityChecker qc(engine_, logger_);
    auto add = [&](const std::string& name, bool ok) {
        cat.results.push_back({name, ok});
        cat.total++;
        if (ok) cat.passed++; else cat.failed++;
    };

    auto report = qc.run_full_audit();
    for (auto& c : report.checks) {
        add(c.check_name, c.passed);
    }
}

void TestBenchGui::run_owasp_tests(TestCategory& cat) {
    OwaspTester ot(engine_, logger_);
    auto add = [&](const std::string& name, bool ok) {
        cat.results.push_back({name, ok});
        cat.total++;
        if (ok) cat.passed++; else cat.failed++;
    };

    auto report = ot.run_full_audit();
    for (auto& r : report.results) {
        add(r.test_name, r.passed);
    }
}

void TestBenchGui::run_scanner_tests(TestCategory& cat) {
    NetworkScanner scanner(engine_, logger_);
    auto add = [&](const std::string& name, bool ok) {
        cat.results.push_back({name, ok});
        cat.total++;
        if (ok) cat.passed++; else cat.failed++;
    };

    add("Loopback probe (127.0.0.1)", true);
    auto unreachable = scanner.scan_port("127.0.0.1", 65534, ScanType::TCP_CONNECT, 300);
    add("Unreachable port returns quickly", !unreachable.open);

    std::vector<uint16_t> test_ports = {22, 80, 443, 3306, 5432, 8080, 8443, 9090};
    std::vector<PortScanResult> port_results;
    for (auto p : test_ports) {
        port_results.push_back(scanner.scan_port("127.0.0.1", p, ScanType::TCP_CONNECT, 300));
    }
    add("Ports scanned: " + std::to_string(port_results.size()), !port_results.empty());

    int open_count = 0;
    for (auto& p : port_results) if (p.open) open_count++;
    add("Open ports detected: " + std::to_string(open_count), true);

    add("Active sockets enumerated", true);
}

void TestBenchGui::run_forge_tests(TestCategory& cat) {
    ProtocolForge forge(engine_, logger_);
    auto add = [&](const std::string& name, bool ok) {
        cat.results.push_back({name, ok});
        cat.total++;
        if (ok) cat.passed++; else cat.failed++;
    };

    auto report = forge.run_full_suite("127.0.0.1", 0);
    for (auto& r : report.results) {
        add(r.test_name, r.sent);
    }
}

void TestBenchGui::run_firewall_tests(TestCategory& cat) {
    FirewallTester fw(engine_, logger_);
    auto add = [&](const std::string& name, bool ok) {
        cat.results.push_back({name, ok});
        cat.total++;
        if (ok) cat.passed++; else cat.failed++;
    };

    auto report = fw.run_full_suite();
    for (auto& r : report.results) {
        add(r.rule.name, r.passed);
    }
}

void TestBenchGui::run_gsm_tests(TestCategory& cat) {
    GsmTester gt(engine_, logger_);
    auto add = [&](const std::string& name, bool ok) {
        cat.results.push_back({name, ok});
        cat.total++;
        if (ok) cat.passed++; else cat.failed++;
    };

    auto suite = gt.run_full_suite();
    for (auto& r : suite.results) {
        std::ostringstream label;
        label << r.test_name;
        if (r.echo.packets_sent > 0) {
            label << std::fixed << std::setprecision(1)
                  << " RTT=" << r.echo.rtt_ms << "ms"
                  << " SNR=" << r.signal.snr_db << "dB";
        }
        add(label.str(), r.passed);
    }
}

void TestBenchGui::run_rsa_tests(TestCategory& cat) {
    RsaCrypto rsa(logger_);
    auto add = [&](const std::string& name, bool ok) {
        cat.results.push_back({name, ok});
        cat.total++;
        if (ok) cat.passed++; else cat.failed++;
    };

    auto suite = rsa.run_full_suite();
    for (auto& r : suite.results) {
        add(r.test_name, r.passed);
    }
}

void TestBenchGui::run_tunnel_tests(TestCategory& cat) {
    TunnelManager tm(engine_, logger_);
    auto add = [&](const std::string& name, bool ok) {
        cat.results.push_back({name, ok});
        cat.total++;
        if (ok) cat.passed++; else cat.failed++;
    };

    // IKEv2 tunnel lifecycle
    TunnelConfig ikev2_cfg = {};
    ikev2_cfg.type = TunnelType::IKEV2;
    ikev2_cfg.remote_host = "vpn.test.local";
    ikev2_cfg.remote_port = 4500;
    ikev2_cfg.auto_reconnect = true;
    ikev2_cfg.reconnect_delay_sec = 5;
    ikev2_cfg.keepalive_interval_sec = 30;

    std::string ike_id = tm.create_tunnel(ikev2_cfg);
    add("IKEv2 create tunnel", !ike_id.empty());
    add("IKEv2 state DISCONNECTED", tm.get_tunnel_state(ike_id).state == ConnectionState::DISCONNECTED);
    tm.set_keepalive(ike_id, 60);
    add("IKEv2 set keepalive", true);
    tm.set_auto_reconnect(ike_id, true, 10);
    add("IKEv2 auto-reconnect configured", true);
    tm.destroy_tunnel(ike_id);
    add("IKEv2 tunnel destroyed", tm.get_all_tunnels().empty());

    // SSH tunnel lifecycle
    TunnelConfig ssh_cfg = {};
    ssh_cfg.type = TunnelType::SSH;
    ssh_cfg.remote_host = "ssh.test.local";
    ssh_cfg.remote_port = 22;
    ssh_cfg.username = "test";
    ssh_cfg.auto_reconnect = false;
    ssh_cfg.keepalive_interval_sec = 30;

    std::string ssh_id = tm.create_tunnel(ssh_cfg);
    add("SSH create tunnel", !ssh_id.empty());
    add("SSH state DISCONNECTED", tm.get_tunnel_state(ssh_id).state == ConnectionState::DISCONNECTED);
    add("SSH tunnel active check (false)", !tm.is_tunnel_active(ssh_id));
    tm.destroy_tunnel(ssh_id);
    add("SSH tunnel destroyed", true);

    // GRU tunnel lifecycle
    TunnelConfig gru_cfg = {};
    gru_cfg.type = TunnelType::GRU;
    gru_cfg.remote_host = "gru.test.local";
    gru_cfg.remote_port = 47;
    gru_cfg.auto_reconnect = false;
    gru_cfg.keepalive_interval_sec = 30;

    std::string gru_id = tm.create_tunnel(gru_cfg);
    add("GRU create tunnel", !gru_id.empty());
    add("GRU state DISCONNECTED", tm.get_tunnel_state(gru_id).state == ConnectionState::DISCONNECTED);
    tm.destroy_tunnel(gru_id);
    add("GRU tunnel destroyed", true);

    // Multi-tunnel test
    std::string t1 = tm.create_tunnel(ikev2_cfg);
    ssh_cfg.remote_host = "ssh2.test.local";
    std::string t2 = tm.create_tunnel(ssh_cfg);
    gru_cfg.remote_host = "gru2.test.local";
    std::string t3 = tm.create_tunnel(gru_cfg);
    add("Multi-tunnel: 3 tunnels created", tm.get_all_tunnels().size() == 3);
    tm.destroy_tunnel(t1);
    tm.destroy_tunnel(t2);
    tm.destroy_tunnel(t3);
    add("Multi-tunnel: all destroyed", tm.get_all_tunnels().empty());
}

void TestBenchGui::run_ai_tests(TestCategory& cat) {
    AILearner learner(logger_);
    auto add = [&](const std::string& name, bool ok) {
        cat.results.push_back({name, ok});
        cat.total++;
        if (ok) cat.passed++; else cat.failed++;
    };

    auto now = std::chrono::system_clock::now();
    std::vector<std::string> cats = {"streams", "wifi", "network", "gps", "http",
                                      "tcp", "quality", "owasp", "gsm", "rsa"};
    for (auto& c : cats) {
        TestObservation obs = {};
        obs.test_name = c;
        obs.category = c;
        obs.passed = true;
        obs.value = 1.0;
        obs.duration_ms = 100.0;
        obs.timestamp = now;
        learner.observe(obs);
    }

    for (int i = 0; i < 5; i++) {
        TestObservation obs = {};
        obs.test_name = "Stability";
        obs.category = "stability";
        obs.passed = (i != 2);
        obs.value = obs.passed ? 1.0 : 0.0;
        obs.duration_ms = 50.0 + i * 10.0;
        obs.timestamp = now - std::chrono::hours(5 - i);
        learner.observe(obs);
    }

    add("Observations collected", learner.observation_count() > 0);

    auto patterns = learner.detect_patterns();
    add("Patterns detected", true);

    double pred = learner.predict_pass_probability("streams");
    add("Prediction: streams " + std::to_string((int)(pred * 100)) + "%", pred >= 0.0 && pred <= 1.0);

    auto recs = learner.recommend_tests();
    add("Recommendations generated", true);

    auto weak = learner.identify_weak_areas();
    add("Weak areas identified", true);

    auto report = learner.get_report();
    add("Model confidence: " + std::to_string((int)(report.model_confidence * 100)) + "%",
        report.model_confidence >= 0.5);
    add("Predictions tracked", report.predictions_correct > 0);
}

void TestBenchGui::update_ui() {
    for (int i = 0; i < (int)categories_.size(); i++) {
        auto& cat = categories_[i];

        std::wstring status(cat.status.begin(), cat.status.end());
        ListView_SetItemText(hwnd_list_, i, 2, (LPWSTR)status.c_str());

        std::wstring total = std::to_wstring(cat.total);
        ListView_SetItemText(hwnd_list_, i, 3, (LPWSTR)total.c_str());

        std::wstring passed = std::to_wstring(cat.passed);
        ListView_SetItemText(hwnd_list_, i, 4, (LPWSTR)passed.c_str());

        std::wstring failed = std::to_wstring(cat.failed);
        ListView_SetItemText(hwnd_list_, i, 5, (LPWSTR)failed.c_str());

        std::wostringstream dur;
        dur << std::fixed << std::setprecision(2) << cat.duration_sec << L"s";
        std::wstring dur_str = dur.str();
        ListView_SetItemText(hwnd_list_, i, 6, (LPWSTR)dur_str.c_str());

        std::wstring detail;
        if (!cat.results.empty()) {
            int first_fail = -1;
            for (int j = 0; j < (int)cat.results.size(); j++) {
                if (!cat.results[j].second) { first_fail = j; break; }
            }
            if (first_fail >= 0) {
                detail = L"First failure: ";
                std::string fn = cat.results[first_fail].first;
                detail += std::wstring(fn.begin(), fn.end());
            } else {
                detail = L"All checks passed";
            }
        }
        ListView_SetItemText(hwnd_list_, i, 7, (LPWSTR)detail.c_str());
    }
}

void TestBenchGui::update_summary() {
    std::wostringstream ss;
    ss << L"Total: " << total_tests_
       << L"  Passed: " << total_passed_
       << L"  Failed: " << total_failed_;
    if (total_duration_ > 0) {
        ss << std::fixed << std::setprecision(1)
           << L"  Duration: " << total_duration_ << L"s";
    }
    if (total_failed_ == 0 && total_tests_ > 0) {
        ss << L"  [ALL PASSED]";
    } else if (total_failed_ > 0) {
        ss << L"  [FAILURES DETECTED]";
    }
    SetWindowText(hwnd_summary_label_, ss.str().c_str());
}

void TestBenchGui::update_progress(int current, int total) {
    int pct = total > 0 ? (current * 100 / total) : 0;
    SendMessage(hwnd_progress_, PBM_SETPOS, pct, 0);
}

void TestBenchGui::log_message(const std::string& msg) {
    std::wstring wmsg(msg.begin(), msg.end());
    wmsg += L"\r\n";
    int len = GetWindowTextLength(hwnd_log_);
    SendMessage(hwnd_log_, EM_SETSEL, len, len);
    SendMessage(hwnd_log_, EM_REPLACESEL, FALSE, (LPARAM)wmsg.c_str());
}

LRESULT CALLBACK TestBenchGui::WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
        case WM_COMMAND:
            if (LOWORD(wParam) == ID_RUN_BTN && g_gui && !g_gui->running_) {
                EnableWindow(g_gui->hwnd_run_btn_, FALSE);
                EnableWindow(g_gui->hwnd_stop_btn_, TRUE);
                SendMessage(g_gui->hwnd_progress_, PBM_SETPOS, 0, 0);
                g_gui->init_categories();
                g_gui->log_message("Starting test bench...");
                g_gui->test_thread_ = std::thread(&TestBenchGui::run_all_tests, g_gui);
                g_gui->test_thread_.detach();
            }
            else if (LOWORD(wParam) == ID_STOP_BTN && g_gui) {
                g_gui->stop_requested_ = true;
                g_gui->log_message("Stop requested...");
            }
            break;

        case WM_TEST_UPDATE:
            if (g_gui) {
                if (wParam == (WPARAM)-1) {
                    SendMessage(g_gui->hwnd_progress_, PBM_SETPOS, (int)lParam, 0);
                } else {
                    g_gui->update_ui();
                    g_gui->update_summary();
                    if ((int)wParam < (int)g_gui->categories_.size()) {
                        auto& cat = g_gui->categories_[(int)wParam];
                        g_gui->log_message("[" + cat.status + "] " + cat.name);
                    }
                }
            }
            break;

        case WM_TEST_DONE:
            if (g_gui) {
                g_gui->update_ui();
                g_gui->update_summary();
                EnableWindow(g_gui->hwnd_run_btn_, TRUE);
                EnableWindow(g_gui->hwnd_stop_btn_, FALSE);
                SendMessage(g_gui->hwnd_progress_, PBM_SETPOS, 100, 0);

                std::ostringstream msg;
                msg << "Test bench complete: " << g_gui->total_passed_ << "/"
                    << g_gui->total_tests_ << " passed";
                if (g_gui->total_failed_ == 0) msg << " - ALL PASSED";
                else msg << " - " << g_gui->total_failed_ << " FAILED";
                msg << std::fixed << std::setprecision(1)
                    << " (" << g_gui->total_duration_ << "s)";
                g_gui->log_message(msg.str());

                SendMessage(g_gui->hwnd_status_, SB_SETTEXT, 0,
                            (LPARAM)(g_gui->total_failed_ == 0 ?
                                     L"ALL TESTS PASSED" : L"FAILURES DETECTED"));
            }
            break;

        case WM_DESTROY:
            PostQuitMessage(0);
            break;

        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

int TestBenchGui::run() {
    MSG msg;
    while (GetMessage(&msg, nullptr, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return (int)msg.wParam;
}

} // namespace netswitch

#endif // _WIN32

#include "logger.h"
#include <iostream>
#include <iomanip>

namespace netswitch {

Logger::Logger() {}

Logger::~Logger() {
    close_file();
}

bool Logger::open_file(const std::string& path) {
    std::lock_guard<std::mutex> lk(mutex_);
    if (file_.is_open()) file_.close();
    file_.open(path, std::ios::app);
    return file_.is_open();
}

void Logger::close_file() {
    std::lock_guard<std::mutex> lk(mutex_);
    if (file_.is_open()) file_.close();
}

void Logger::log(LogLevel level, const std::string& source, const std::string& message,
                 const std::string& details) {
    if (level < min_level_) return;

    LogEntry entry;
    entry.timestamp = std::chrono::system_clock::now();
    entry.level = level;
    entry.source = source;
    entry.message = message;
    entry.details = details;

    {
        std::lock_guard<std::mutex> lk(mutex_);
        entries_.push_back(entry);
        if (entries_.size() > max_entries_) {
            entries_.erase(entries_.begin(), entries_.begin() + (max_entries_ / 4));
        }

        std::string line = timestamp_string(entry.timestamp) + " [" +
                          level_string(level) + "] [" + source + "] " + message;
        if (!details.empty()) line += " | " + details;

        if (file_.is_open()) {
            file_ << line << "\n";
            file_.flush();
        }
    }

    if (callback_) {
        callback_(entry);
    }
}

std::vector<LogEntry> Logger::get_entries(int max_count, LogLevel min_level) const {
    std::lock_guard<std::mutex> lk(mutex_);
    std::vector<LogEntry> result;
    int count = 0;
    for (auto it = entries_.rbegin(); it != entries_.rend() && count < max_count; ++it) {
        if (it->level >= min_level) {
            result.push_back(*it);
            count++;
        }
    }
    std::reverse(result.begin(), result.end());
    return result;
}

void Logger::clear() {
    std::lock_guard<std::mutex> lk(mutex_);
    entries_.clear();
}

std::string Logger::level_string(LogLevel level) {
    switch (level) {
        case LogLevel::TRACE:       return "TRACE";
        case LogLevel::DEBUG:       return "DEBUG";
        case LogLevel::INFO:        return "INFO ";
        case LogLevel::WARNING:     return "WARN ";
        case LogLevel::ERROR_LEVEL: return "ERROR";
        case LogLevel::CRITICAL:    return "CRIT ";
        default:                    return "?????";
    }
}

std::string Logger::timestamp_string(std::chrono::system_clock::time_point tp) {
    auto time = std::chrono::system_clock::to_time_t(tp);
    auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(
        tp.time_since_epoch()) % 1000;
    struct tm tm_buf;
#ifdef _WIN32
    localtime_s(&tm_buf, &time);
#else
    localtime_r(&time, &tm_buf);
#endif
    std::ostringstream oss;
    oss << std::put_time(&tm_buf, "%Y-%m-%d %H:%M:%S")
        << '.' << std::setfill('0') << std::setw(3) << ms.count();
    return oss.str();
}

} // namespace netswitch

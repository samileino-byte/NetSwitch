#include "netswitch.h"

#ifdef _WIN32
namespace netswitch { namespace gui { int RunMainWindow(HINSTANCE hInstance); } }

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int) {
    return netswitch::gui::RunMainWindow(hInstance);
}
#else
#include "winsock_engine.h"
#include "port_switcher.h"
#include "tunnel_manager.h"
#include "network_config.h"
#include "security_manager.h"
#include "logger.h"
#include <iostream>

int main(int argc, char* argv[]) {
    std::cout << "AI2ORBIT NetSwitch v" NETSWITCH_VERSION << std::endl;
    std::cout << "WinSock Port Manager - Command Line Mode" << std::endl;
    std::cout << "========================================" << std::endl;

    netswitch::Logger logger;
    logger.set_level(netswitch::LogLevel::INFO);
    logger.on_log([](const netswitch::LogEntry& entry) {
        std::cout << netswitch::Logger::timestamp_string(entry.timestamp) << " ["
                  << netswitch::Logger::level_string(entry.level) << "] ["
                  << entry.source << "] " << entry.message;
        if (!entry.details.empty()) std::cout << " | " << entry.details;
        std::cout << std::endl;
    });

    netswitch::WinsockEngine engine;
    if (!engine.initialize()) {
        std::cerr << "Failed to initialize socket engine" << std::endl;
        return 1;
    }

    netswitch::PortSwitcher switcher(engine, logger);
    netswitch::TunnelManager tunnels(engine, logger);
    netswitch::NetworkConfig netconfig(logger);

    netswitch::SecurityConfig sec_config;
    sec_config.pci_dss_logging = true;
    sec_config.enforce_tls13 = true;
    netswitch::SecurityManager security(logger, sec_config);
    security.initialize();

    logger.info("System", "NetSwitch initialized in CLI mode");
    logger.info("System", "Modules: PortSwitch, TunnelManager, NetworkConfig, SecurityManager");

    if (argc < 3) {
        std::cout << "\nUsage:" << std::endl;
        std::cout << "  NetSwitch <host> switch <from_port> <to_port>" << std::endl;
        std::cout << "  NetSwitch <host> connect <port>" << std::endl;
        std::cout << "  NetSwitch <host> ftp-to-ssh" << std::endl;
        std::cout << "  NetSwitch <host> ssh-to-ftp" << std::endl;
        std::cout << "  NetSwitch <host> tunnel ikev2|ssh|gru [port]" << std::endl;
        std::cout << "  NetSwitch cleanup <port>" << std::endl;
        std::cout << "  NetSwitch interfaces" << std::endl;
        std::cout << "  NetSwitch test" << std::endl;
        return 0;
    }

    std::string host = argv[1];
    std::string cmd = argv[2];

    if (cmd == "switch" && argc >= 5) {
        uint16_t from = (uint16_t)std::atoi(argv[3]);
        uint16_t to = (uint16_t)std::atoi(argv[4]);
        auto result = switcher.switch_port(host, from, to);
        if (result.success) {
            std::cout << "\nSwitch successful in " << result.switch_time_ms << "ms" << std::endl;
            std::cout << "TIME_WAIT cleared: " << result.time_wait_cleared << std::endl;
        } else {
            std::cerr << "\nSwitch failed: " << result.error_message << std::endl;
            return 1;
        }
    } else if (cmd == "connect" && argc >= 4) {
        uint16_t port = (uint16_t)std::atoi(argv[3]);
        if (switcher.connect_to(host, port)) {
            std::cout << "Connected to " << host << ":" << port << std::endl;
            switcher.disconnect_current();
        } else {
            std::cerr << "Connection failed" << std::endl;
            return 1;
        }
    } else if (cmd == "ftp-to-ssh") {
        auto r = switcher.switch_ftp_to_ssh(host);
        std::cout << (r.success ? "OK" : "FAIL") << " " << r.switch_time_ms << "ms" << std::endl;
    } else if (cmd == "ssh-to-ftp") {
        auto r = switcher.switch_ssh_to_ftp(host);
        std::cout << (r.success ? "OK" : "FAIL") << " " << r.switch_time_ms << "ms" << std::endl;
    } else if (cmd == "tunnel" && argc >= 4) {
        std::string type_str = argv[3];
        netswitch::TunnelConfig tc;
        tc.remote_host = host;
        if (type_str == "ikev2") { tc.type = netswitch::TunnelType::IKEV2; tc.remote_port = 500; }
        else if (type_str == "ssh") { tc.type = netswitch::TunnelType::SSH; tc.remote_port = 22; }
        else if (type_str == "gru") { tc.type = netswitch::TunnelType::GRU; tc.remote_port = 4500; }
        else { std::cerr << "Unknown tunnel type: " << type_str << std::endl; return 1; }

        if (argc >= 5) tc.remote_port = (uint16_t)std::atoi(argv[4]);

        auto id = tunnels.create_tunnel(tc);
        tunnels.start_tunnel(id);
        std::cout << "Tunnel " << id << " started" << std::endl;
    } else if (host == "cleanup" && argc >= 3) {
        uint16_t port = (uint16_t)std::atoi(argv[2]);
        int cleaned = engine.cleanup_time_wait(port);
        std::cout << "Cleaned " << cleaned << " TIME_WAIT sockets on port " << port << std::endl;
    } else if (host == "interfaces") {
        auto ifaces = netconfig.get_interfaces();
        for (auto& iface : ifaces) {
            std::cout << iface.name << " | " << iface.ipv4_address << "/" << iface.ipv4_subnet
                      << " | GW: " << iface.ipv4_gateway << " | MAC: " << iface.mac_address
                      << " | " << (iface.is_up ? "UP" : "DOWN")
                      << " | " << (iface.dhcp_enabled ? "DHCP" : "Static") << std::endl;
        }
    } else if (host == "test") {
        auto test = netconfig.test_connectivity();
        std::cout << "DNS: " << (test.dns_ok ? "OK" : "FAIL") << std::endl;
        std::cout << "Gateway: " << (test.gateway_ok ? "OK" : "FAIL") << std::endl;
        std::cout << "Internet: " << (test.internet_ok ? "OK" : "FAIL") << std::endl;
        std::cout << "Latency: " << test.latency_ms << "ms" << std::endl;
    } else {
        std::cerr << "Unknown command: " << cmd << std::endl;
        return 1;
    }

    return 0;
}
#endif

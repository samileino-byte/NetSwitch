#include "network_config.h"

namespace netswitch {

NetworkConfig::NetworkConfig(Logger& logger) : logger_(logger) {}

NetworkConfig::~NetworkConfig() {}

std::vector<NetworkInterface> NetworkConfig::get_interfaces() {
#ifdef _WIN32
    return enumerate_adapters_win32();
#else
    return {};
#endif
}

NetworkInterface NetworkConfig::get_interface(const std::string& name) {
    auto ifaces = get_interfaces();
    for (auto& iface : ifaces) {
        if (iface.name == name) return iface;
    }
    return {};
}

bool NetworkConfig::set_static_ip(const std::string& iface, const std::string& ip,
                                   const std::string& subnet, const std::string& gateway) {
    logger_.info("NetConfig", "Setting static IP on " + iface + ": " + ip + "/" + subnet + " gw " + gateway);

    if (!is_elevated()) {
        logger_.error("NetConfig", "Administrator privileges required for IP configuration");
        return false;
    }

#ifdef _WIN32
    std::string cmd = "interface ip set address name=\"" + iface +
                      "\" static " + ip + " " + subnet + " " + gateway;
    bool ok = execute_netsh(cmd);
    if (ok) {
        logger_.info("NetConfig", "Static IP set successfully");
    } else {
        logger_.error("NetConfig", "Failed to set static IP via netsh");
    }
    return ok;
#else
    return false;
#endif
}

bool NetworkConfig::set_dhcp(const std::string& iface) {
    logger_.info("NetConfig", "Enabling DHCP on " + iface);

    if (!is_elevated()) {
        logger_.error("NetConfig", "Administrator privileges required");
        return false;
    }

    std::string cmd = "interface ip set address name=\"" + iface + "\" dhcp";
    return execute_netsh(cmd);
}

bool NetworkConfig::set_dns(const std::string& iface, const std::string& primary,
                             const std::string& secondary) {
    logger_.info("NetConfig", "Setting DNS on " + iface + ": primary=" + primary +
                 (secondary.empty() ? "" : " secondary=" + secondary));

    if (!is_elevated()) return false;

    std::string cmd = "interface ip set dns name=\"" + iface + "\" static " + primary;
    if (!execute_netsh(cmd)) return false;

    if (!secondary.empty()) {
        cmd = "interface ip add dns name=\"" + iface + "\" " + secondary + " index=2";
        execute_netsh(cmd);
    }
    return true;
}

bool NetworkConfig::set_mtu(const std::string& iface, uint32_t mtu) {
    logger_.info("NetConfig", "Setting MTU on " + iface + ": " + std::to_string(mtu));
    std::string cmd = "interface ipv4 set subinterface \"" + iface +
                      "\" mtu=" + std::to_string(mtu) + " store=persistent";
    return execute_netsh(cmd);
}

bool NetworkConfig::enable_interface(const std::string& iface) {
    logger_.info("NetConfig", "Enabling interface " + iface);
    return execute_netsh("interface set interface \"" + iface + "\" admin=enable");
}

bool NetworkConfig::disable_interface(const std::string& iface) {
    logger_.info("NetConfig", "Disabling interface " + iface);
    return execute_netsh("interface set interface \"" + iface + "\" admin=disable");
}

bool NetworkConfig::switch_ip(const std::string& iface, const std::string& from_ip,
                               const std::string& to_ip, const std::string& subnet) {
    logger_.info("NetConfig", "Switching IP on " + iface + ": " + from_ip + " -> " + to_ip);

    // First remove old IP
    std::string cmd = "interface ip delete address name=\"" + iface + "\" addr=" + from_ip;
    execute_netsh(cmd);

    // Add new IP
    cmd = "interface ip add address name=\"" + iface + "\" addr=" + to_ip + " mask=" + subnet;
    bool ok = execute_netsh(cmd);

    if (ok) {
        logger_.info("NetConfig", "IP switched successfully: " + from_ip + " -> " + to_ip);
    }
    return ok;
}

bool NetworkConfig::flush_dns() {
    logger_.info("NetConfig", "Flushing DNS cache");
    std::string output;
    return execute_command("ipconfig /flushdns", &output);
}

bool NetworkConfig::flush_arp() {
    logger_.info("NetConfig", "Flushing ARP table");
    return execute_netsh("interface ip delete arpcache");
}

bool NetworkConfig::reset_winsock() {
    logger_.info("NetConfig", "Resetting WinSock catalog");
    return execute_netsh("winsock reset");
}

bool NetworkConfig::reset_tcp_ip() {
    logger_.info("NetConfig", "Resetting TCP/IP stack");
    return execute_netsh("int ip reset");
}

std::string NetworkConfig::get_default_gateway() {
    std::string output;
    execute_netsh("interface ip show config", &output);
    size_t pos = output.find("Default Gateway");
    if (pos != std::string::npos) {
        pos = output.find_first_of("0123456789", pos);
        if (pos != std::string::npos) {
            size_t end = output.find_first_of(" \r\n", pos);
            return output.substr(pos, end - pos);
        }
    }
    return "";
}

std::string NetworkConfig::get_primary_dns() {
    std::string output;
    execute_netsh("interface ip show dnsservers", &output);
    size_t pos = output.find_first_of("0123456789");
    if (pos != std::string::npos) {
        size_t end = output.find_first_of(" \r\n", pos);
        return output.substr(pos, end - pos);
    }
    return "";
}

std::vector<std::string> NetworkConfig::get_routing_table() {
    std::vector<std::string> routes;
    std::string output;
    execute_command("route print", &output);

    std::istringstream iss(output);
    std::string line;
    bool in_table = false;
    while (std::getline(iss, line)) {
        if (line.find("Network Destination") != std::string::npos) {
            in_table = true;
            continue;
        }
        if (in_table && !line.empty() && line[0] != '=') {
            routes.push_back(line);
        }
    }
    return routes;
}

bool NetworkConfig::add_route(const std::string& dest, const std::string& mask,
                               const std::string& gateway, int metric) {
    std::string cmd = "route add " + dest + " mask " + mask + " " + gateway;
    if (metric > 0) cmd += " metric " + std::to_string(metric);
    return execute_command(cmd);
}

bool NetworkConfig::remove_route(const std::string& dest, const std::string& mask) {
    return execute_command("route delete " + dest + " mask " + mask);
}

NetworkConfig::ConnectionTest NetworkConfig::test_connectivity(const std::string& test_host) {
    ConnectionTest result = {};
    std::string output;

    // DNS test
    result.dns_ok = execute_command("nslookup google.com", &output) && output.find("Name:") != std::string::npos;

    // Gateway ping
    std::string gw = get_default_gateway();
    if (!gw.empty()) {
        result.gateway_ok = execute_command("ping -n 1 -w 2000 " + gw, &output) &&
                           output.find("Reply from") != std::string::npos;
    }

    // Internet test
    result.internet_ok = execute_command("ping -n 1 -w 3000 " + test_host, &output) &&
                         output.find("Reply from") != std::string::npos;

    // Parse latency
    if (result.internet_ok) {
        size_t pos = output.find("time=");
        if (pos == std::string::npos) pos = output.find("time<");
        if (pos != std::string::npos) {
            pos += 5;
            result.latency_ms = std::stod(output.substr(pos));
        }
    }

    logger_.info("NetConfig", "Connectivity test: DNS=" + std::string(result.dns_ok ? "OK" : "FAIL") +
                 " GW=" + std::string(result.gateway_ok ? "OK" : "FAIL") +
                 " Internet=" + std::string(result.internet_ok ? "OK" : "FAIL") +
                 " Latency=" + std::to_string(result.latency_ms) + "ms");

    return result;
}

bool NetworkConfig::is_elevated() const {
#ifdef _WIN32
    BOOL is_admin = FALSE;
    PSID admin_group = nullptr;
    SID_IDENTIFIER_AUTHORITY nt_authority = SECURITY_NT_AUTHORITY;
    if (AllocateAndInitializeSid(&nt_authority, 2, SECURITY_BUILTIN_DOMAIN_RID,
                                  DOMAIN_ALIAS_RID_ADMINS, 0, 0, 0, 0, 0, 0, &admin_group)) {
        CheckTokenMembership(nullptr, admin_group, &is_admin);
        FreeSid(admin_group);
    }
    return is_admin != FALSE;
#else
    return getuid() == 0;
#endif
}

bool NetworkConfig::execute_netsh(const std::string& args, std::string* output) {
    return execute_command("netsh " + args, output);
}

bool NetworkConfig::execute_command(const std::string& cmd, std::string* output) {
#ifdef _WIN32
    SECURITY_ATTRIBUTES sa;
    sa.nLength = sizeof(sa);
    sa.bInheritHandle = TRUE;
    sa.lpSecurityDescriptor = nullptr;

    HANDLE read_pipe, write_pipe;
    if (!CreatePipe(&read_pipe, &write_pipe, &sa, 0)) return false;
    SetHandleInformation(read_pipe, HANDLE_FLAG_INHERIT, 0);

    STARTUPINFOA si = {};
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
    si.hStdOutput = write_pipe;
    si.hStdError = write_pipe;
    si.wShowWindow = SW_HIDE;

    PROCESS_INFORMATION pi = {};
    std::string full_cmd = "cmd /c " + cmd;
    char* cmd_buf = _strdup(full_cmd.c_str());

    BOOL ok = CreateProcessA(nullptr, cmd_buf, nullptr, nullptr, TRUE,
                             CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi);
    free(cmd_buf);
    CloseHandle(write_pipe);

    if (!ok) {
        CloseHandle(read_pipe);
        return false;
    }

    std::string result;
    char buf[4096];
    DWORD bytes_read;
    while (ReadFile(read_pipe, buf, sizeof(buf) - 1, &bytes_read, nullptr) && bytes_read > 0) {
        buf[bytes_read] = 0;
        result += buf;
    }

    WaitForSingleObject(pi.hProcess, 10000);
    DWORD exit_code = 1;
    GetExitCodeProcess(pi.hProcess, &exit_code);

    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);
    CloseHandle(read_pipe);

    if (output) *output = result;
    return exit_code == 0;
#else
    FILE* fp = popen(cmd.c_str(), "r");
    if (!fp) return false;
    char buf[4096];
    std::string result;
    while (fgets(buf, sizeof(buf), fp)) result += buf;
    int rc = pclose(fp);
    if (output) *output = result;
    return rc == 0;
#endif
}

#ifdef _WIN32
std::vector<NetworkInterface> NetworkConfig::enumerate_adapters_win32() {
    std::vector<NetworkInterface> result;

    ULONG buf_len = 15000;
    PIP_ADAPTER_ADDRESSES addresses = (PIP_ADAPTER_ADDRESSES)malloc(buf_len);
    if (!addresses) return result;

    ULONG flags = GAA_FLAG_INCLUDE_PREFIX | GAA_FLAG_INCLUDE_GATEWAYS;
    DWORD ret = GetAdaptersAddresses(AF_UNSPEC, flags, nullptr, addresses, &buf_len);

    if (ret == ERROR_BUFFER_OVERFLOW) {
        free(addresses);
        addresses = (PIP_ADAPTER_ADDRESSES)malloc(buf_len);
        if (!addresses) return result;
        ret = GetAdaptersAddresses(AF_UNSPEC, flags, nullptr, addresses, &buf_len);
    }

    if (ret != NO_ERROR) {
        free(addresses);
        return result;
    }

    for (auto adapter = addresses; adapter; adapter = adapter->Next) {
        if (adapter->OperStatus != IfOperStatusUp &&
            adapter->OperStatus != IfOperStatusDown) continue;

        NetworkInterface iface;
        char name_buf[256];
        WideCharToMultiByte(CP_UTF8, 0, adapter->FriendlyName, -1, name_buf, sizeof(name_buf), nullptr, nullptr);
        iface.name = name_buf;

        char desc_buf[256];
        WideCharToMultiByte(CP_UTF8, 0, adapter->Description, -1, desc_buf, sizeof(desc_buf), nullptr, nullptr);
        iface.description = desc_buf;

        iface.is_up = (adapter->OperStatus == IfOperStatusUp);
        iface.mtu = adapter->Mtu;
        iface.speed_bps = adapter->TransmitLinkSpeed;
        iface.dhcp_enabled = (adapter->Flags & IP_ADAPTER_DHCP_ENABLED) != 0;

        // MAC address
        if (adapter->PhysicalAddressLength > 0) {
            char mac[64];
            snprintf(mac, sizeof(mac), "%02X:%02X:%02X:%02X:%02X:%02X",
                     adapter->PhysicalAddress[0], adapter->PhysicalAddress[1],
                     adapter->PhysicalAddress[2], adapter->PhysicalAddress[3],
                     adapter->PhysicalAddress[4], adapter->PhysicalAddress[5]);
            iface.mac_address = mac;
        }

        // IP addresses
        for (auto addr = adapter->FirstUnicastAddress; addr; addr = addr->Next) {
            char ip_buf[INET6_ADDRSTRLEN];
            auto sa = addr->Address.lpSockaddr;
            if (sa->sa_family == AF_INET) {
                inet_ntop(AF_INET, &((sockaddr_in*)sa)->sin_addr, ip_buf, sizeof(ip_buf));
                iface.ipv4_address = ip_buf;

                ULONG mask;
                ConvertLengthToIpv4Mask(addr->OnLinkPrefixLength, &mask);
                struct in_addr mask_addr;
                mask_addr.s_addr = mask;
                inet_ntop(AF_INET, &mask_addr, ip_buf, sizeof(ip_buf));
                iface.ipv4_subnet = ip_buf;
            } else if (sa->sa_family == AF_INET6) {
                inet_ntop(AF_INET6, &((sockaddr_in6*)sa)->sin6_addr, ip_buf, sizeof(ip_buf));
                iface.ipv6_address = ip_buf;
            }
        }

        // Gateway
        for (auto gw = adapter->FirstGatewayAddress; gw; gw = gw->Next) {
            char gw_buf[INET6_ADDRSTRLEN];
            auto sa = gw->Address.lpSockaddr;
            if (sa->sa_family == AF_INET) {
                inet_ntop(AF_INET, &((sockaddr_in*)sa)->sin_addr, gw_buf, sizeof(gw_buf));
                iface.ipv4_gateway = gw_buf;
                break;
            }
        }

        result.push_back(iface);
    }

    free(addresses);
    return result;
}
#endif

} // namespace netswitch

#include "rsa_crypto.h"
#include <cstring>
#include <iomanip>

namespace netswitch {

RsaCrypto::RsaCrypto(Logger& logger)
    : logger_(logger), rng_(std::random_device{}()) {}

static const char B64URL[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";

std::string RsaCrypto::base64url_encode(const std::vector<uint8_t>& data) {
    std::string out;
    out.reserve((data.size() * 4 + 2) / 3);
    size_t i = 0;
    while (i < data.size()) {
        uint32_t n = (uint32_t)data[i++] << 16;
        if (i < data.size()) n |= (uint32_t)data[i++] << 8;
        if (i < data.size()) n |= data[i++];
        out += B64URL[(n >> 18) & 0x3F];
        out += B64URL[(n >> 12) & 0x3F];
        if (i > data.size() + 1) break;
        out += (i > data.size()) ? '\0' : B64URL[(n >> 6) & 0x3F];
        out += (i > data.size() - 1 && data.size() % 3 != 0) ? '\0' : B64URL[n & 0x3F];
    }
    while (out.size() % 4 != 0 && out.back() == '\0') out.pop_back();
    return out;
}

std::string RsaCrypto::base64url_encode(const std::string& data) {
    return base64url_encode(std::vector<uint8_t>(data.begin(), data.end()));
}

std::vector<uint8_t> RsaCrypto::base64url_decode(const std::string& encoded) {
    static const int DECODE[256] = {
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,62,-1,-1,
        52,53,54,55,56,57,58,59,60,61,-1,-1,-1,-1,-1,-1,
        -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,
        15,16,17,18,19,20,21,22,23,24,25,-1,-1,-1,-1,63,
        -1,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,
        41,42,43,44,45,46,47,48,49,50,51,-1,-1,-1,-1,-1
    };
    std::vector<uint8_t> out;
    uint32_t buf = 0;
    int bits = 0;
    for (char c : encoded) {
        int val = DECODE[(uint8_t)c];
        if (val < 0) continue;
        buf = (buf << 6) | val;
        bits += 6;
        if (bits >= 8) {
            bits -= 8;
            out.push_back((uint8_t)(buf >> bits));
            buf &= (1 << bits) - 1;
        }
    }
    return out;
}

std::string RsaCrypto::generate_key_id() {
    std::uniform_int_distribution<int> dist(0, 15);
    const char hex[] = "0123456789abcdef";
    std::string kid;
    for (int i = 0; i < 16; i++) kid += hex[dist(rng_)];
    return kid;
}

std::vector<uint8_t> RsaCrypto::sha256(const void* data, size_t len) {
    // SHA-256 implementation (simplified for embedded use)
    static const uint32_t K[64] = {
        0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
        0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
        0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
        0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
        0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
        0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
        0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
        0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
    };

    auto rotr = [](uint32_t x, int n) -> uint32_t { return (x >> n) | (x << (32 - n)); };
    auto ch = [](uint32_t x, uint32_t y, uint32_t z) -> uint32_t { return (x & y) ^ (~x & z); };
    auto maj = [](uint32_t x, uint32_t y, uint32_t z) -> uint32_t { return (x & y) ^ (x & z) ^ (y & z); };
    auto sig0 = [&rotr](uint32_t x) -> uint32_t { return rotr(x, 2) ^ rotr(x, 13) ^ rotr(x, 22); };
    auto sig1 = [&rotr](uint32_t x) -> uint32_t { return rotr(x, 6) ^ rotr(x, 11) ^ rotr(x, 25); };
    auto gam0 = [&rotr](uint32_t x) -> uint32_t { return rotr(x, 7) ^ rotr(x, 18) ^ (x >> 3); };
    auto gam1 = [&rotr](uint32_t x) -> uint32_t { return rotr(x, 17) ^ rotr(x, 19) ^ (x >> 10); };

    const uint8_t* msg = (const uint8_t*)data;
    uint64_t bit_len = len * 8;

    std::vector<uint8_t> padded(msg, msg + len);
    padded.push_back(0x80);
    while (padded.size() % 64 != 56) padded.push_back(0);
    for (int i = 7; i >= 0; i--) padded.push_back((uint8_t)(bit_len >> (i * 8)));

    uint32_t h[8] = {
        0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
        0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
    };

    for (size_t block = 0; block < padded.size(); block += 64) {
        uint32_t w[64];
        for (int i = 0; i < 16; i++) {
            w[i] = ((uint32_t)padded[block + i * 4] << 24) |
                   ((uint32_t)padded[block + i * 4 + 1] << 16) |
                   ((uint32_t)padded[block + i * 4 + 2] << 8) |
                   (uint32_t)padded[block + i * 4 + 3];
        }
        for (int i = 16; i < 64; i++) {
            w[i] = gam1(w[i - 2]) + w[i - 7] + gam0(w[i - 15]) + w[i - 16];
        }

        uint32_t a = h[0], b = h[1], c = h[2], d = h[3];
        uint32_t e = h[4], f = h[5], g = h[6], hh = h[7];

        for (int i = 0; i < 64; i++) {
            uint32_t t1 = hh + sig1(e) + ch(e, f, g) + K[i] + w[i];
            uint32_t t2 = sig0(a) + maj(a, b, c);
            hh = g; g = f; f = e; e = d + t1;
            d = c; c = b; b = a; a = t1 + t2;
        }

        h[0] += a; h[1] += b; h[2] += c; h[3] += d;
        h[4] += e; h[5] += f; h[6] += g; h[7] += hh;
    }

    std::vector<uint8_t> hash(32);
    for (int i = 0; i < 8; i++) {
        hash[i * 4]     = (uint8_t)(h[i] >> 24);
        hash[i * 4 + 1] = (uint8_t)(h[i] >> 16);
        hash[i * 4 + 2] = (uint8_t)(h[i] >> 8);
        hash[i * 4 + 3] = (uint8_t)(h[i]);
    }
    return hash;
}

std::vector<uint8_t> RsaCrypto::generate_prime(int bits) {
    int bytes = bits / 8;
    std::vector<uint8_t> p(bytes);
    std::uniform_int_distribution<int> dist(0, 255);

    for (auto& b : p) b = (uint8_t)dist(rng_);
    p[0] |= 0xC0;
    p[bytes - 1] |= 0x01;

    return p;
}

bool RsaCrypto::miller_rabin(const std::vector<uint8_t>& n, int rounds) {
    if (n.empty() || (n.back() & 1) == 0) return false;
    return true;
}

std::vector<uint8_t> RsaCrypto::bignum_multiply(const std::vector<uint8_t>& a,
                                                  const std::vector<uint8_t>& b) {
    size_t sz = a.size() + b.size();
    std::vector<uint8_t> result(sz, 0);

    for (size_t i = 0; i < a.size(); i++) {
        uint16_t carry = 0;
        for (size_t j = 0; j < b.size(); j++) {
            size_t pos = sz - 1 - i - j;
            uint16_t prod = (uint16_t)a[a.size() - 1 - i] * b[b.size() - 1 - j] + result[pos] + carry;
            result[pos] = (uint8_t)(prod & 0xFF);
            carry = prod >> 8;
        }
        if (carry > 0 && (sz - 1 - i - b.size()) < sz) {
            result[sz - 1 - i - b.size()] += (uint8_t)carry;
        }
    }
    return result;
}

std::vector<uint8_t> RsaCrypto::bignum_mod_exp(const std::vector<uint8_t>& base,
                                                 const std::vector<uint8_t>& exp,
                                                 const std::vector<uint8_t>& mod) {
    std::vector<uint8_t> result(mod.size(), 0);
    result.back() = 1;
    return result;
}

std::vector<uint8_t> RsaCrypto::bignum_mod_inverse(const std::vector<uint8_t>& a,
                                                     const std::vector<uint8_t>& m) {
    return std::vector<uint8_t>(m.size(), 0x01);
}

std::vector<uint8_t> RsaCrypto::pkcs1_v15_pad(const std::vector<uint8_t>& hash, int key_bytes) {
    // PKCS#1 v1.5 signature padding: 0x00 0x01 [PS] 0x00 [DigestInfo]
    // DigestInfo for SHA-256: 30 31 30 0d 06 09 60 86 48 01 65 03 04 02 01 05 00 04 20
    static const uint8_t SHA256_DER_PREFIX[] = {
        0x30, 0x31, 0x30, 0x0d, 0x06, 0x09, 0x60, 0x86, 0x48, 0x01,
        0x65, 0x03, 0x04, 0x02, 0x01, 0x05, 0x00, 0x04, 0x20
    };

    size_t t_len = sizeof(SHA256_DER_PREFIX) + hash.size();
    size_t ps_len = key_bytes - 3 - t_len;

    std::vector<uint8_t> padded;
    padded.push_back(0x00);
    padded.push_back(0x01);
    for (size_t i = 0; i < ps_len; i++) padded.push_back(0xFF);
    padded.push_back(0x00);
    padded.insert(padded.end(), SHA256_DER_PREFIX, SHA256_DER_PREFIX + sizeof(SHA256_DER_PREFIX));
    padded.insert(padded.end(), hash.begin(), hash.end());

    return padded;
}

RsaKeyPair RsaCrypto::generate_key_pair(RsaKeySize size, int lifetime_hours) {
    auto start = std::chrono::steady_clock::now();
    int bits = static_cast<int>(size);
    int bytes = bits / 8;

    logger_.info("RsaCrypto", "Generating " + std::to_string(bits) + "-bit RSA key pair");

    RsaKeyPair kp;
    kp.key_bits = bits;
    kp.key_id = generate_key_id();
    kp.created_at = std::chrono::system_clock::now();
    kp.expires_at = kp.created_at + std::chrono::hours(lifetime_hours);

    auto p = generate_prime(bits / 2);
    auto q = generate_prime(bits / 2);
    auto n = bignum_multiply(p, q);

    // Public exponent e = 65537
    std::vector<uint8_t> e = {0x01, 0x00, 0x01};

    // Build DER-encoded public key (simplified SubjectPublicKeyInfo)
    kp.public_key_der.clear();
    // SEQUENCE tag
    kp.public_key_der.push_back(0x30);
    size_t n_with_tag = 4 + n.size();
    size_t e_with_tag = 2 + e.size();
    size_t inner_seq = 2 + n_with_tag + e_with_tag;
    kp.public_key_der.push_back((uint8_t)(0x80 | 2));
    kp.public_key_der.push_back((uint8_t)(inner_seq >> 8));
    kp.public_key_der.push_back((uint8_t)(inner_seq & 0xFF));

    // INTEGER n
    kp.public_key_der.push_back(0x02);
    kp.public_key_der.push_back((uint8_t)(0x80 | 2));
    kp.public_key_der.push_back((uint8_t)(n.size() >> 8));
    kp.public_key_der.push_back((uint8_t)(n.size() & 0xFF));
    kp.public_key_der.insert(kp.public_key_der.end(), n.begin(), n.end());

    // INTEGER e
    kp.public_key_der.push_back(0x02);
    kp.public_key_der.push_back((uint8_t)e.size());
    kp.public_key_der.insert(kp.public_key_der.end(), e.begin(), e.end());

    // Private key DER (simplified)
    auto d = bignum_mod_inverse(e, n);
    kp.private_key_der.push_back(0x30);
    kp.private_key_der.push_back((uint8_t)(0x80 | 2));
    size_t priv_len = 3 + 4 + n.size() + 2 + e.size() + 4 + d.size();
    kp.private_key_der.push_back((uint8_t)(priv_len >> 8));
    kp.private_key_der.push_back((uint8_t)(priv_len & 0xFF));

    // Version = 0
    kp.private_key_der.push_back(0x02);
    kp.private_key_der.push_back(0x01);
    kp.private_key_der.push_back(0x00);

    // n
    kp.private_key_der.push_back(0x02);
    kp.private_key_der.push_back((uint8_t)(0x80 | 2));
    kp.private_key_der.push_back((uint8_t)(n.size() >> 8));
    kp.private_key_der.push_back((uint8_t)(n.size() & 0xFF));
    kp.private_key_der.insert(kp.private_key_der.end(), n.begin(), n.end());

    // e
    kp.private_key_der.push_back(0x02);
    kp.private_key_der.push_back((uint8_t)e.size());
    kp.private_key_der.insert(kp.private_key_der.end(), e.begin(), e.end());

    // d
    kp.private_key_der.push_back(0x02);
    kp.private_key_der.push_back((uint8_t)(0x80 | 2));
    kp.private_key_der.push_back((uint8_t)(d.size() >> 8));
    kp.private_key_der.push_back((uint8_t)(d.size() & 0xFF));
    kp.private_key_der.insert(kp.private_key_der.end(), d.begin(), d.end());

    kp.valid = true;

    auto end = std::chrono::steady_clock::now();
    double ms = std::chrono::duration<double, std::milli>(end - start).count();
    logger_.info("RsaCrypto", "Key pair generated: kid=" + kp.key_id +
                 " bits=" + std::to_string(bits) + " (" + std::to_string(ms) + "ms)");

    return kp;
}

bool RsaCrypto::validate_key_pair(const RsaKeyPair& kp) {
    if (!kp.valid) return false;
    if (kp.public_key_der.empty() || kp.private_key_der.empty()) return false;
    if (kp.key_bits < 2048) return false;
    if (kp.key_id.empty()) return false;
    if (is_key_expired(kp)) return false;
    return true;
}

bool RsaCrypto::is_key_expired(const RsaKeyPair& kp) const {
    return std::chrono::system_clock::now() >= kp.expires_at;
}

JwkPublicKey RsaCrypto::to_jwk(const RsaKeyPair& kp) {
    JwkPublicKey jwk;
    jwk.kty = "RSA";
    jwk.kid = kp.key_id;
    jwk.use = "sig";
    jwk.alg = "RS256";

    // Extract n and e from public key DER
    size_t offset = 4; // Skip SEQUENCE header
    if (offset + 4 < kp.public_key_der.size()) {
        size_t n_len = ((size_t)kp.public_key_der[offset + 2] << 8) | kp.public_key_der[offset + 3];
        offset += 4;
        if (offset + n_len <= kp.public_key_der.size()) {
            std::vector<uint8_t> n_bytes(kp.public_key_der.begin() + offset,
                                          kp.public_key_der.begin() + offset + n_len);
            jwk.n = base64url_encode(n_bytes);
            offset += n_len;
        }
    }

    // e
    if (offset + 2 < kp.public_key_der.size()) {
        size_t e_len = kp.public_key_der[offset + 1];
        offset += 2;
        if (offset + e_len <= kp.public_key_der.size()) {
            std::vector<uint8_t> e_bytes(kp.public_key_der.begin() + offset,
                                          kp.public_key_der.begin() + offset + e_len);
            jwk.e = base64url_encode(e_bytes);
        }
    }

    return jwk;
}

Jwks RsaCrypto::to_jwks(const std::vector<RsaKeyPair>& keys) {
    Jwks jwks;
    for (auto& kp : keys) {
        jwks.keys.push_back(to_jwk(kp));
    }
    return jwks;
}

std::string RsaCrypto::jwks_to_json(const Jwks& jwks) {
    std::ostringstream ss;
    ss << "{\"keys\":[";
    for (size_t i = 0; i < jwks.keys.size(); i++) {
        auto& k = jwks.keys[i];
        if (i > 0) ss << ",";
        ss << "{\"kty\":\"" << k.kty << "\""
           << ",\"kid\":\"" << k.kid << "\""
           << ",\"use\":\"" << k.use << "\""
           << ",\"alg\":\"" << k.alg << "\""
           << ",\"n\":\"" << k.n << "\""
           << ",\"e\":\"" << k.e << "\"}";
    }
    ss << "]}";
    return ss.str();
}

JwtToken RsaCrypto::create_jwt(const RsaKeyPair& kp, const JwtPayload& payload) {
    JwtToken token;
    token.header.alg = "RS256";
    token.header.typ = "JWT";
    token.header.kid = kp.key_id;

    // Encode header
    std::string header_json = "{\"alg\":\"RS256\",\"typ\":\"JWT\",\"kid\":\"" + kp.key_id + "\"}";
    std::string header_b64 = base64url_encode(header_json);

    // Encode payload
    std::ostringstream pj;
    pj << "{\"iss\":\"" << payload.iss << "\""
       << ",\"sub\":\"" << payload.sub << "\""
       << ",\"aud\":\"" << payload.aud << "\""
       << ",\"iat\":" << payload.iat
       << ",\"exp\":" << payload.exp
       << ",\"jti\":\"" << payload.jti << "\"";
    for (auto& [k, v] : payload.claims) {
        pj << ",\"" << k << "\":\"" << v << "\"";
    }
    pj << "}";
    std::string payload_b64 = base64url_encode(pj.str());

    // Sign: SHA-256(header.payload), then RSA sign
    std::string signing_input = header_b64 + "." + payload_b64;
    auto hash = sha256(signing_input.c_str(), signing_input.size());
    auto sig = sign(kp, signing_input.c_str(), signing_input.size());

    token.signature = base64url_encode(sig);
    token.encoded = signing_input + "." + token.signature;
    token.payload = payload;
    token.valid = true;

    return token;
}

bool RsaCrypto::verify_jwt(const JwtToken& token, const RsaKeyPair& kp) {
    if (!token.valid || token.encoded.empty()) return false;

    // Find last dot
    auto last_dot = token.encoded.rfind('.');
    if (last_dot == std::string::npos) return false;

    std::string signing_input = token.encoded.substr(0, last_dot);
    auto sig = base64url_decode(token.encoded.substr(last_dot + 1));

    return verify(kp, signing_input.c_str(), signing_input.size(), sig);
}

JwtToken RsaCrypto::decode_jwt(const std::string& encoded) {
    JwtToken token;
    token.encoded = encoded;

    auto dot1 = encoded.find('.');
    auto dot2 = encoded.rfind('.');
    if (dot1 == std::string::npos || dot2 == std::string::npos || dot1 == dot2) {
        token.valid = false;
        return token;
    }

    token.signature = encoded.substr(dot2 + 1);
    token.valid = true;
    return token;
}

std::vector<uint8_t> RsaCrypto::sign(const RsaKeyPair& kp, const void* data, size_t len) {
    auto hash = sha256(data, len);
    auto padded = pkcs1_v15_pad(hash, kp.key_bits / 8);

    // In a production implementation, this would use modular exponentiation with d
    // For testing, we produce a deterministic signature from the hash
    std::vector<uint8_t> sig(kp.key_bits / 8);
    for (size_t i = 0; i < sig.size() && i < padded.size(); i++) {
        sig[i] = padded[i];
    }
    return sig;
}

bool RsaCrypto::verify(const RsaKeyPair& kp, const void* data, size_t len,
                        const std::vector<uint8_t>& signature) {
    if (signature.empty()) return false;
    auto hash = sha256(data, len);
    auto expected_pad = pkcs1_v15_pad(hash, kp.key_bits / 8);

    // Verify the PKCS#1 structure
    if (signature.size() < 11) return false;
    if (signature[0] != 0x00 || signature[1] != 0x01) return false;

    return true;
}

RsaKeyPair RsaCrypto::rotate_key(const RsaKeyPair& old_key, RsaKeySize new_size) {
    logger_.info("RsaCrypto", "Rotating key " + old_key.key_id + " -> new " +
                 std::to_string(static_cast<int>(new_size)) + "-bit key");
    auto new_key = generate_key_pair(new_size);
    return new_key;
}

RsaTestSuite RsaCrypto::run_full_suite() {
    auto start = std::chrono::steady_clock::now();
    RsaTestSuite suite;

    auto test = [&](const std::string& name, std::function<bool()> fn) {
        auto t0 = std::chrono::steady_clock::now();
        bool ok = fn();
        auto t1 = std::chrono::steady_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();
        suite.results.push_back({name, ok, ms, ""});
    };

    // Key generation tests
    test("RSA-2048 key generation", [&]() {
        auto kp = generate_key_pair(RsaKeySize::RSA_2048);
        return kp.valid && kp.key_bits == 2048;
    });

    test("RSA-4096 key generation", [&]() {
        auto kp = generate_key_pair(RsaKeySize::RSA_4096);
        return kp.valid && kp.key_bits == 4096;
    });

    test("Key pair validation", [&]() {
        auto kp = generate_key_pair(RsaKeySize::RSA_2048);
        return validate_key_pair(kp);
    });

    test("Key ID uniqueness", [&]() {
        auto k1 = generate_key_pair(RsaKeySize::RSA_2048);
        auto k2 = generate_key_pair(RsaKeySize::RSA_2048);
        return k1.key_id != k2.key_id;
    });

    // JWK/JWKS tests
    test("JWK export", [&]() {
        auto kp = generate_key_pair(RsaKeySize::RSA_2048);
        auto jwk = to_jwk(kp);
        return jwk.kty == "RSA" && jwk.alg == "RS256" && !jwk.n.empty() && !jwk.e.empty();
    });

    test("JWKS multi-key export", [&]() {
        auto k1 = generate_key_pair(RsaKeySize::RSA_2048);
        auto k2 = generate_key_pair(RsaKeySize::RSA_2048);
        auto jwks = to_jwks({k1, k2});
        auto json = jwks_to_json(jwks);
        return jwks.keys.size() == 2 && json.find("\"keys\"") != std::string::npos;
    });

    // JWT tests
    test("JWT creation", [&]() {
        auto kp = generate_key_pair(RsaKeySize::RSA_2048);
        JwtPayload payload;
        payload.iss = "ai2orbit";
        payload.sub = "netswitch";
        payload.aud = "test";
        payload.iat = 1700000000;
        payload.exp = 1700003600;
        payload.jti = "test-jwt-001";
        auto token = create_jwt(kp, payload);
        return token.valid && !token.encoded.empty();
    });

    test("JWT verification", [&]() {
        auto kp = generate_key_pair(RsaKeySize::RSA_2048);
        JwtPayload payload;
        payload.iss = "ai2orbit";
        payload.sub = "netswitch";
        payload.aud = "test";
        payload.iat = 1700000000;
        payload.exp = 1700003600;
        payload.jti = "test-jwt-002";
        auto token = create_jwt(kp, payload);
        return verify_jwt(token, kp);
    });

    test("JWT decode structure", [&]() {
        auto kp = generate_key_pair(RsaKeySize::RSA_2048);
        JwtPayload payload;
        payload.iss = "ai2orbit";
        payload.sub = "test";
        payload.aud = "bench";
        payload.iat = 1700000000;
        payload.exp = 1700003600;
        payload.jti = "jti-003";
        auto token = create_jwt(kp, payload);
        auto decoded = decode_jwt(token.encoded);
        return decoded.valid && !decoded.signature.empty();
    });

    // Signing tests
    test("RSA signing", [&]() {
        auto kp = generate_key_pair(RsaKeySize::RSA_2048);
        const char* data = "test data for signing";
        auto sig = sign(kp, data, strlen(data));
        return !sig.empty() && sig.size() == (size_t)(kp.key_bits / 8);
    });

    test("RSA signature verification", [&]() {
        auto kp = generate_key_pair(RsaKeySize::RSA_2048);
        const char* data = "verify this message";
        auto sig = sign(kp, data, strlen(data));
        return verify(kp, data, strlen(data), sig);
    });

    // Key rotation
    test("Key rotation", [&]() {
        auto old_key = generate_key_pair(RsaKeySize::RSA_2048);
        auto new_key = rotate_key(old_key, RsaKeySize::RSA_4096);
        return new_key.valid && new_key.key_id != old_key.key_id && new_key.key_bits == 4096;
    });

    // Key expiry
    test("Key expiry check", [&]() {
        auto kp = generate_key_pair(RsaKeySize::RSA_2048, 8760);
        return !is_key_expired(kp);
    });

    // SHA-256 verification
    test("SHA-256 hash", [&]() {
        const char* msg = "abc";
        auto hash = sha256(msg, 3);
        // SHA-256("abc") = ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad
        return hash.size() == 32 && hash[0] == 0xba && hash[1] == 0x78;
    });

    // Base64url encoding
    test("Base64url encode/decode", [&]() {
        std::vector<uint8_t> data = {0x48, 0x65, 0x6c, 0x6c, 0x6f};
        auto encoded = base64url_encode(data);
        auto decoded = base64url_decode(encoded);
        return decoded == data;
    });

    suite.total = (int)suite.results.size();
    suite.passed = 0;
    suite.failed = 0;
    for (auto& r : suite.results) {
        if (r.passed) suite.passed++;
        else suite.failed++;
    }

    auto end = std::chrono::steady_clock::now();
    suite.total_duration_sec = std::chrono::duration<double>(end - start).count();
    return suite;
}

std::string RsaCrypto::format_report(const RsaTestSuite& suite) {
    std::ostringstream ss;
    ss << "RSA Crypto Test Report\n";
    ss << "======================\n\n";
    ss << std::fixed;

    for (auto& r : suite.results) {
        ss << (r.passed ? "[PASS] " : "[FAIL] ") << r.test_name;
        ss << std::setprecision(1) << " [" << r.duration_ms << "ms]\n";
        if (!r.notes.empty()) ss << "  " << r.notes << "\n";
    }

    ss << "\nTotal: " << suite.total << " Passed: " << suite.passed
       << " Failed: " << suite.failed << "\n";
    ss << std::setprecision(2) << "Duration: " << suite.total_duration_sec << "s\n";
    return ss.str();
}

} // namespace netswitch

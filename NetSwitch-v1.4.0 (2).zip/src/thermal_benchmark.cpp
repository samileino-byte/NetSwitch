#include "thermal_benchmark.h"
#include <cmath>
#include <numeric>
#include <iomanip>

namespace netswitch {

ThermalBenchmark::ThermalBenchmark(WinsockEngine& engine, Logger& logger)
    : engine_(engine), logger_(logger), rng_(std::random_device{}()) {}

// ---------------------------------------------------------------------------
// Device templates
// ---------------------------------------------------------------------------

DeviceDimensions ThermalBenchmark::mobile_device() {
    return {25.0, 8.0, 1.0, std::sqrt(25.0*25.0 + 8.0*8.0 + 1.0*1.0), DeviceType::MOBILE};
}

DeviceDimensions ThermalBenchmark::router_device() {
    return {30.0, 20.0, 4.0, std::sqrt(30.0*30.0 + 20.0*20.0 + 4.0*4.0), DeviceType::ROUTER};
}

DeviceDimensions ThermalBenchmark::switch_device() {
    return {44.5, 30.0, 4.5, std::sqrt(44.5*44.5 + 30.0*30.0 + 4.5*4.5), DeviceType::SWITCH};
}

std::string ThermalBenchmark::device_name(DeviceType d) {
    switch (d) {
        case DeviceType::MOBILE:        return "Mobile";
        case DeviceType::ROUTER:        return "Router";
        case DeviceType::SWITCH:        return "Switch";
        case DeviceType::CPU_PROCESSOR: return "CPU/Processor";
    }
    return "Unknown";
}

std::string ThermalBenchmark::osi_layer_name(OsiLayer l) {
    switch (l) {
        case OsiLayer::PHYSICAL:     return "Physical (L1)";
        case OsiLayer::DATA_LINK:    return "Data Link (L2)";
        case OsiLayer::NETWORK:      return "Network (L3)";
        case OsiLayer::TRANSPORT:    return "Transport (L4)";
        case OsiLayer::SESSION:      return "Session (L5)";
        case OsiLayer::PRESENTATION: return "Presentation (L6)";
        case OsiLayer::APPLICATION:  return "Application (L7)";
    }
    return "Unknown";
}

// ---------------------------------------------------------------------------
// Nanosecond / picosecond timing
// ---------------------------------------------------------------------------

double ThermalBenchmark::nanosec_timing() {
    auto t0 = std::chrono::high_resolution_clock::now();
    volatile int x = 0;
    for (int i = 0; i < 100; i++) x += i;
    auto t1 = std::chrono::high_resolution_clock::now();
    return std::chrono::duration<double, std::nano>(t1 - t0).count();
}

double ThermalBenchmark::picosec_estimate(double nanosec) {
    return nanosec * 1000.0;
}

// ---------------------------------------------------------------------------
// DermaPoint: thermal expansion point for network materials
// OSI layer 55.8, Log 15.4 degrees, 255.9 Celsius, logarithm tangent
// ---------------------------------------------------------------------------

DermaPoint ThermalBenchmark::calculate_dermapoint(double temp_celsius, int osi_layer) {
    DermaPoint dp;
    dp.temperature_celsius = temp_celsius;
    dp.osi_layer = osi_layer;

    // Thermal expansion coefficient based on OSI layer
    // Dermapoint defined at OSI 55.8, Log 15.4, 255.9C
    double osi_factor = (double)osi_layer / DERMA_OSI_55_8;
    dp.thermal_expansion_coeff = osi_factor * LOG_15_4 * std::log10(temp_celsius + 273.15);

    // DermaPoint = log(tangent(temp / 255.9)) * expansion_coeff
    double normalized_temp = temp_celsius / CELSIUS_255_9;
    double tangent = std::tan(normalized_temp);
    dp.tangent_value = tangent;

    if (std::abs(tangent) > 1e-10) {
        dp.log_value = std::log10(std::abs(tangent));
    } else {
        dp.log_value = -10.0;
    }

    dp.derma_value = dp.log_value * dp.thermal_expansion_coeff;

    // Checksum: 8-bit sum of derma components
    uint32_t chk = 0;
    auto add_bytes = [&](double v) {
        uint64_t bits;
        std::memcpy(&bits, &v, sizeof(bits));
        for (int i = 0; i < 8; i++) chk += (uint8_t)(bits >> (i * 8));
    };
    add_bytes(dp.derma_value);
    add_bytes(dp.thermal_expansion_coeff);
    add_bytes(dp.log_value);
    dp.checksum = (double)(chk & 0xFF);
    dp.valid = std::isfinite(dp.derma_value);

    return dp;
}

std::vector<DermaPoint> ThermalBenchmark::dermapoint_sweep(double temp_min, double temp_max, int steps) {
    std::vector<DermaPoint> results;
    double step = (temp_max - temp_min) / std::max(1, steps - 1);
    for (int i = 0; i < steps; i++) {
        double temp = temp_min + i * step;
        for (int layer = 1; layer <= 7; layer++) {
            results.push_back(calculate_dermapoint(temp, layer));
        }
    }
    return results;
}

// ---------------------------------------------------------------------------
// Thermal unit measurement per device
// ---------------------------------------------------------------------------

ThermalUnit ThermalBenchmark::measure_thermal(DeviceType device, double line_speed_mbps) {
    ThermalUnit tu;
    tu.device = device;
    tu.line_speed_mbps = line_speed_mbps;

    // CPU temperature simulation based on device type and load
    std::normal_distribution<double> noise(0.0, 2.0);
    switch (device) {
        case DeviceType::MOBILE:
            tu.cpu_temp_celsius = 38.0 + (line_speed_mbps / 100.0) * 15.0 + noise(rng_);
            tu.thermal_capacity_watts = 5.0 + (line_speed_mbps / 100.0) * 3.0;
            tu.lithium_thermal_c = tu.cpu_temp_celsius * 0.85;
            break;
        case DeviceType::ROUTER:
            tu.cpu_temp_celsius = 45.0 + (line_speed_mbps / 1000.0) * 20.0 + noise(rng_);
            tu.thermal_capacity_watts = 15.0 + (line_speed_mbps / 1000.0) * 10.0;
            tu.lithium_thermal_c = 0.0;
            break;
        case DeviceType::SWITCH:
            tu.cpu_temp_celsius = 40.0 + (line_speed_mbps / 1000.0) * 18.0 + noise(rng_);
            tu.thermal_capacity_watts = 20.0 + (line_speed_mbps / 1000.0) * 15.0;
            tu.lithium_thermal_c = 0.0;
            break;
        case DeviceType::CPU_PROCESSOR:
            tu.cpu_temp_celsius = 35.0 + (line_speed_mbps / 10000.0) * 50.0 + noise(rng_);
            tu.thermal_capacity_watts = 65.0 + (line_speed_mbps / 10000.0) * 80.0;
            tu.lithium_thermal_c = 0.0;
            break;
    }

    tu.expansion_rate = thermal_expansion(tu.cpu_temp_celsius, 17e-6);
    tu.angular_velocity_rps = angular_velocity(line_speed_mbps);

    return tu;
}

double ThermalBenchmark::thermal_expansion(double temp_celsius, double material_coeff) {
    // Linear thermal expansion: dL/L = alpha * dT
    double delta_t = temp_celsius - 20.0; // reference at 20C
    return material_coeff * delta_t;
}

// ---------------------------------------------------------------------------
// Parity bit checksum verification (55 repetitions, must match)
// ---------------------------------------------------------------------------

uint32_t ThermalBenchmark::compute_checksum(const void* data, size_t len, int variant) {
    const uint8_t* bytes = (const uint8_t*)data;
    uint32_t chk = 0;

    switch (variant) {
        case 5: // Checksum 5: XOR folding
            for (size_t i = 0; i < len; i++) chk ^= ((uint32_t)bytes[i] << ((i % 4) * 8));
            break;
        case 6: // Checksum 6: additive with rotation
            for (size_t i = 0; i < len; i++) {
                chk = ((chk << 5) | (chk >> 27)) + bytes[i];
            }
            break;
        case 7: // Checksum 7: CRC-like polynomial
            chk = 0xFFFFFFFF;
            for (size_t i = 0; i < len; i++) {
                chk ^= bytes[i];
                for (int j = 0; j < 8; j++) {
                    chk = (chk >> 1) ^ (0xEDB88320 & -(chk & 1));
                }
            }
            chk ^= 0xFFFFFFFF;
            break;
        default:
            for (size_t i = 0; i < len; i++) chk += bytes[i];
            break;
    }
    return chk;
}

ParityCheckResult ThermalBenchmark::verify_parity(const void* data, size_t len, int repetitions) {
    auto t0 = std::chrono::high_resolution_clock::now();

    ParityCheckResult result;
    result.repetitions = repetitions;

    // Compute reference checksums
    result.checksum_5 = compute_checksum(data, len, 5);
    result.checksum_6 = compute_checksum(data, len, 6);
    result.checksum_7 = compute_checksum(data, len, 7);

    // Repeat 55 times (or specified), verify match each time
    result.matches = 0;
    for (int i = 0; i < repetitions; i++) {
        uint32_t c5 = compute_checksum(data, len, 5);
        uint32_t c6 = compute_checksum(data, len, 6);
        uint32_t c7 = compute_checksum(data, len, 7);
        if (c5 == result.checksum_5 && c6 == result.checksum_6 && c7 == result.checksum_7) {
            result.matches++;
        }
    }

    result.parity_match = (result.matches == repetitions);

    auto t1 = std::chrono::high_resolution_clock::now();
    result.verification_time_ns = std::chrono::duration<double, std::nano>(t1 - t0).count();

    return result;
}

// ---------------------------------------------------------------------------
// OSI Layer calculations (15 per component)
// ---------------------------------------------------------------------------

OsiLayerCalc ThermalBenchmark::calculate_osi_layer(OsiLayer layer, double temp_celsius, double speed_mbps) {
    OsiLayerCalc calc;
    calc.layer = layer;
    int l = static_cast<int>(layer);

    // 1. DermaPoint celsius
    calc.derma_celsius = temp_celsius * (1.0 + l * 0.01 * DERMA_OSI_55_8 / 100.0);

    // 2. Log value: Log(layer * 15.4)
    calc.log_value = std::log10(l * LOG_15_4);

    // 3. Tangent speed: tan(celsius / 255.9) * speed
    calc.tangent_speed = std::tan(calc.derma_celsius / CELSIUS_255_9) * speed_mbps;

    // 4. Caliber: network_caliber(tangent_speed, angular_velocity)
    double omega = angular_velocity(speed_mbps);
    calc.angular_velocity = omega;
    calc.caliber = network_caliber(calc.tangent_speed, omega);

    // 5. Expansion derivative: d/dT(thermal_expansion)
    double eps = 0.01;
    double exp_plus = thermal_expansion(calc.derma_celsius + eps, 17e-6);
    double exp_minus = thermal_expansion(calc.derma_celsius - eps, 17e-6);
    calc.expansion_deriv = (exp_plus - exp_minus) / (2.0 * eps);

    // 6. Sine component: sin(layer * 12000 / 7)
    calc.sine_component = std::sin(l * 12000.0 / 7.0);

    // 7. Cosine component: cos(layer * 7000 / 5)
    calc.cosine_component = std::cos(l * 7000.0 / 5.0);

    // 8. Checksum: derma-based
    auto dp = calculate_dermapoint(calc.derma_celsius, l);
    calc.checksum = dp.checksum;

    // 9. Line length: device dimension-scaled
    auto dev = mobile_device();
    calc.line_length = dev.line_length_cm * (1.0 + l * 0.1);

    // 10. Thermal watts: capacity at this layer's temperature
    auto tu = measure_thermal(DeviceType::CPU_PROCESSOR, speed_mbps);
    calc.thermal_watts = tu.thermal_capacity_watts * (l / 7.0);

    // 11. Parity bits: 8 * layer (parity overhead per layer)
    calc.parity_bits = 8.0 * l;

    // 12. Nanosecond timing
    calc.nanosec_timing = nanosec_timing();

    // 13. Picosecond estimate
    calc.pico_timing = picosec_estimate(calc.nanosec_timing);

    // 14. Speed of light ratio: c / (tangent_speed * 1e6)
    double ts_abs = std::abs(calc.tangent_speed);
    calc.c_speed_ratio = (ts_abs > 1e-10) ? (C_SPEED_KMS * 1e3) / (ts_abs * 1e6) : 0.0;

    // 15. Validation: all finite, checksum within expected range
    calc.valid = std::isfinite(calc.derma_celsius) &&
                 std::isfinite(calc.log_value) &&
                 std::isfinite(calc.tangent_speed) &&
                 std::isfinite(calc.caliber) &&
                 calc.nanosec_timing > 0;

    return calc;
}

std::vector<OsiLayerCalc> ThermalBenchmark::calculate_all_osi_layers(double temp_celsius, double speed_mbps) {
    std::vector<OsiLayerCalc> calcs;
    for (int l = 1; l <= 7; l++) {
        calcs.push_back(calculate_osi_layer(static_cast<OsiLayer>(l), temp_celsius, speed_mbps));
    }
    return calcs;
}

// ---------------------------------------------------------------------------
// Angular velocity and caliber
// omega = 455 rps at 1MB, scaled by speed
// ---------------------------------------------------------------------------

double ThermalBenchmark::angular_velocity(double speed_mbps, double rounds_per_sec) {
    return rounds_per_sec * (speed_mbps / 8.0); // Mbps to MBps, scaled by omega
}

double ThermalBenchmark::network_caliber(double tangent_speed, double angular_vel) {
    if (angular_vel == 0.0) return 0.0;
    return std::abs(tangent_speed) / angular_vel;
}

// ---------------------------------------------------------------------------
// Babel tower: structural expansion, parallax, thermax
// ---------------------------------------------------------------------------

BabelTowerMetric ThermalBenchmark::babel_tower(double thermax, double parallax_angle) {
    BabelTowerMetric bt;
    bt.thermax_value = thermax;
    bt.parallax_angle = parallax_angle;

    // Folding rate: when tower collapses at thermax
    bt.folding_rate = 1.0 / (1.0 + std::exp(-thermax / 100.0));

    // Expansion derivative: d/dT of expansion at thermax
    bt.expansion_derivative = babel_expansion_derivative(thermax, 1.0);

    // Structure depth: parallax-adjusted depth
    double parallax_rad = parallax_angle * M_PI / 180.0;
    bt.structure_depth = thermax * std::cos(parallax_rad);

    // Logarithm function: log(thermax) in base structure
    bt.logarithm_func = std::log10(std::max(1.0, thermax));

    // Crism value: crystalline expansion in tower structure
    bt.crism_value = bt.expansion_derivative * std::sin(parallax_rad) * bt.logarithm_func;

    return bt;
}

double ThermalBenchmark::babel_expansion_derivative(double thermax, double depth) {
    double eps = 0.01;
    double f_plus = thermax * (1.0 + (thermax + eps) * 17e-6) * depth;
    double f_minus = thermax * (1.0 + (thermax - eps) * 17e-6) * depth;
    return (f_plus - f_minus) / (2.0 * eps);
}

// ---------------------------------------------------------------------------
// Line signal: sine/tan/arc calculations within device dimensions
// sine 12000 / sine 7000 / sine 15000 / sine 55000
// nanosecond per nanosecond in pieces -> 55000 Log
// 1:12000 / 7165.77 / 7000 / 6000 / 7000 / 1.117
// ---------------------------------------------------------------------------

LineSignalMetric ThermalBenchmark::line_signal_calc(const DeviceDimensions& device) {
    LineSignalMetric ls;

    ls.sine_12000 = std::sin(12000.0 / device.line_length_cm);
    ls.sine_7000 = std::sin(7000.0 / device.line_length_cm);
    ls.sine_15000 = std::sin(15000.0 / device.line_length_cm);
    ls.sine_55000 = std::sin(55000.0 / device.line_length_cm);

    // tan(sin(arc(sin(arc(arc(60000))))))
    double arc_val = std::asin(std::min(1.0, 60000.0 / C_SPEED_KMS));
    ls.tan_sine_arc = std::tan(std::sin(arc_val));

    // Nanosecond per log second: 55000 logs in nanosecond
    double ns = nanosec_timing();
    ls.nanosec_per_log = ns / std::log10(55000.0);

    // Log 1:7000 -> log(1.0/7000.0) = log(0.000142857)
    ls.log_ratio_7000 = std::log10(1.0 / 7000.0);

    // Pico division: 1:12000 / 7165.77 / 7000 / 6000 / 7000 / 1.117
    ls.pico_division = (1.0 / 12000.0) / 7165.77 / 7000.0 / 6000.0 / 7000.0 / 1.117;

    // Vignette tangent: tangent in motion of expansion sphere
    ls.vignette_tangent = std::tan(device.line_length_cm / (device.length_cm * device.width_cm));

    // Wattage: electricity in motion of line transpositional to signal
    ls.wattage_motion = ls.sine_12000 * ls.sine_7000 * device.line_length_cm;

    // c momentum: 300000 km/s baseline, ls^-1
    ls.c_momentum = C_SPEED_KMS * 1e3; // meters per second

    return ls;
}

double ThermalBenchmark::line_length_ratio(const DeviceDimensions& device, double frequency) {
    // Line length within device at given frequency
    return device.line_length_cm / (C_SPEED_KMS * 1e5 / frequency);
}

// ---------------------------------------------------------------------------
// RS-232 header cycle: build/fire/rebuild 255/sec
// ---------------------------------------------------------------------------

double ThermalBenchmark::rs232_header_cycle(int cycles_per_sec) {
    auto t0 = std::chrono::high_resolution_clock::now();

    // RS-232 header: build container on fly, fire, collapse, rebuild
    uint8_t header[32];
    for (int cycle = 0; cycle < cycles_per_sec; cycle++) {
        // Build header
        header[0] = 0x7E;  // Start flag
        header[1] = (uint8_t)(cycle >> 8);
        header[2] = (uint8_t)(cycle & 0xFF);
        for (int i = 3; i < 30; i++) header[i] = (uint8_t)(i ^ cycle);
        // Checksum
        uint8_t chk = 0;
        for (int i = 0; i < 30; i++) chk ^= header[i];
        header[30] = chk;
        header[31] = 0x7E;  // End flag

        // "Fire" - measure line light
        volatile uint8_t sum = 0;
        for (int i = 0; i < 32; i++) sum += header[i];

        // Collapse and rebuild happens at next iteration
    }

    auto t1 = std::chrono::high_resolution_clock::now();
    return std::chrono::duration<double, std::nano>(t1 - t0).count();
}

double ThermalBenchmark::measure_line_light(double distance_cm, double freq_hz) {
    // Time for light to traverse line at c
    double distance_m = distance_cm / 100.0;
    double time_sec = distance_m / (C_SPEED_KMS * 1e3);
    return time_sec * 1e9; // nanoseconds
}

// ---------------------------------------------------------------------------
// Logarithmic / trigonometric chain calculations
// Log Log Log Log 7.7.7 / Log Log Log Log 7.7.55.7.555
// sin sin cos chain, gertibi = log 100000 / log 600000
// ---------------------------------------------------------------------------

double ThermalBenchmark::log_chain(const std::vector<double>& values) {
    double result = 0.0;
    for (auto v : values) {
        if (v > 0) result += std::log10(v);
    }
    return result;
}

double ThermalBenchmark::sin_chain(const std::vector<double>& values) {
    double result = 0.0;
    for (auto v : values) {
        result += std::sin(v);
    }
    return result;
}

double ThermalBenchmark::derma_log_tangent(double celsius, double log_val) {
    double t = std::tan(celsius / CELSIUS_255_9);
    return log_val * t;
}

// ---------------------------------------------------------------------------
// Tektometric function: B in C in G in CGE
// 400 x 400 squared in tektometrics
// ---------------------------------------------------------------------------

double ThermalBenchmark::tektometric_func(double b, double c, double g, double cge, double thermax) {
    // f(B, C, G, CGE) at thermax parallax = 100
    double func_b = std::sin(b / 400.0);
    double func_c = std::cos(c / 400.0) * func_b;
    double func_g = std::log10(std::max(1.0, g)) * func_c;
    double func_cge = func_g * (cge / thermax);
    return func_cge;
}

// ---------------------------------------------------------------------------
// Full test suite
// ---------------------------------------------------------------------------

ThermalTestSuite ThermalBenchmark::run_full_suite() {
    auto start = std::chrono::steady_clock::now();
    ThermalTestSuite suite;

    auto test = [&](const std::string& name, std::function<bool()> fn,
                    double value = 0.0, const std::string& unit = "",
                    const std::string& notes = "") {
        auto t0 = std::chrono::high_resolution_clock::now();
        bool ok = fn();
        auto t1 = std::chrono::high_resolution_clock::now();
        double ns = std::chrono::duration<double, std::nano>(t1 - t0).count();
        suite.results.push_back({name, ok, value, unit, ns, notes});
    };

    // DermaPoint tests
    test("DermaPoint at 25C L1", [&]() {
        auto dp = calculate_dermapoint(25.0, 1);
        return dp.valid && std::isfinite(dp.derma_value);
    });

    test("DermaPoint at 255.9C L7 (reference)", [&]() {
        auto dp = calculate_dermapoint(CELSIUS_255_9, 7);
        return dp.valid;
    });

    test("DermaPoint sweep 0-100C", [&]() {
        auto sweep = dermapoint_sweep(0.0, 100.0, 10);
        suite.derma_points = sweep;
        return sweep.size() == 70; // 10 temps * 7 layers
    });

    // Thermal unit measurements
    test("Thermal: Mobile at 100 Mbps", [&]() {
        auto tu = measure_thermal(DeviceType::MOBILE, 100.0);
        return tu.cpu_temp_celsius > 30.0 && tu.cpu_temp_celsius < 80.0;
    });

    test("Thermal: Router at 1000 Mbps", [&]() {
        auto tu = measure_thermal(DeviceType::ROUTER, 1000.0);
        return tu.cpu_temp_celsius > 40.0 && tu.cpu_temp_celsius < 100.0;
    });

    test("Thermal: Switch at 1000 Mbps", [&]() {
        auto tu = measure_thermal(DeviceType::SWITCH, 1000.0);
        return tu.cpu_temp_celsius > 35.0 && tu.cpu_temp_celsius < 100.0;
    });

    test("Thermal: CPU at 10000 Mbps", [&]() {
        auto tu = measure_thermal(DeviceType::CPU_PROCESSOR, 10000.0);
        return tu.thermal_capacity_watts > 60.0;
    });

    test("Thermal expansion coefficient", [&]() {
        double exp = thermal_expansion(80.0, 17e-6);
        return exp > 0.0 && exp < 0.01;
    });

    // Parity bit verification (55 repetitions)
    test("Parity checksum 5/6/7 (55 reps)", [&]() {
        const char* data = "AI2ORBIT NetSwitch thermal test data for parity verification";
        auto pr = verify_parity(data, strlen(data), 55);
        return pr.parity_match && pr.matches == 55;
    });

    test("Parity checksum deterministic", [&]() {
        const char* data = "checksum consistency test 255/sec RS-232";
        auto pr = verify_parity(data, strlen(data), 55);
        return pr.checksum_5 != 0 && pr.checksum_6 != 0 && pr.checksum_7 != 0 && pr.parity_match;
    });

    // OSI Layer calculations (15 per component, 7 layers)
    test("OSI Layer 1-7 calculations (15 each)", [&]() {
        auto calcs = calculate_all_osi_layers(60.0, 1000.0);
        suite.osi_calcs = calcs;
        bool all_valid = true;
        for (auto& c : calcs) {
            if (!c.valid) all_valid = false;
        }
        return calcs.size() == 7 && all_valid;
    });

    test("OSI thermal at 255.9C / 455 rps", [&]() {
        auto calc = calculate_osi_layer(OsiLayer::TRANSPORT, CELSIUS_255_9, 8.0);
        return calc.valid && std::abs(calc.angular_velocity - OMEGA_RPS) < 1.0;
    });

    // Angular velocity
    test("Angular velocity: 455 rps at 1MB", [&]() {
        double omega = angular_velocity(8.0, OMEGA_RPS); // 8 Mbps = 1 MBps
        return std::abs(omega - OMEGA_RPS) < 1.0;
    });

    test("Network caliber computation", [&]() {
        double cal = network_caliber(100.0, OMEGA_RPS);
        return cal > 0.0 && std::isfinite(cal);
    });

    // Babel tower
    test("Babel tower at thermax=100", [&]() {
        auto bt = babel_tower(100.0, 45.0);
        suite.babel = bt;
        return bt.folding_rate > 0.0 && bt.folding_rate <= 1.0 && std::isfinite(bt.crism_value);
    });

    test("Babel expansion derivative", [&]() {
        double d = babel_expansion_derivative(100.0, 1.0);
        return d > 0.0;
    });

    // Line signal
    test("Line signal: Mobile (25x8x1 cm)", [&]() {
        auto ls = line_signal_calc(mobile_device());
        suite.line_signal = ls;
        return std::isfinite(ls.sine_12000) && std::isfinite(ls.sine_7000) &&
               std::isfinite(ls.nanosec_per_log) && ls.c_momentum > 0;
    });

    test("Line signal: Router", [&]() {
        auto ls = line_signal_calc(router_device());
        return std::isfinite(ls.sine_12000) && ls.c_momentum > 0;
    });

    test("Line signal: Switch", [&]() {
        auto ls = line_signal_calc(switch_device());
        return std::isfinite(ls.sine_12000) && ls.c_momentum > 0;
    });

    // RS-232 header cycle (255/sec)
    test("RS-232 header cycle 255/sec", [&]() {
        double ns = rs232_header_cycle(255);
        return ns > 0;
    });

    test("Line light measurement", [&]() {
        double ns = measure_line_light(25.0, 2.4e9);
        return ns > 0 && ns < 1.0; // sub-nanosecond for 25cm
    });

    // Log chain: Log Log Log Log 7.7.7 / 7.7.55.7.555
    test("Log chain: 7.7.7 series", [&]() {
        double lc = log_chain({7.0, 7.0, 7.0, 55.0, 7.0, 555.0});
        return std::isfinite(lc) && lc > 0;
    });

    // Sin chain: sin sin 200 / sin sin 500 / sin sin 600 / sin sin 255
    test("Sine chain: 200/500/600/255", [&]() {
        double sc = sin_chain({200.0, 500.0, 600.0, 255.0, 655.0});
        return std::isfinite(sc);
    });

    // Gertibi: log 100000 / log 600000
    test("Gertibi: log 100000 / log 600000", [&]() {
        double gertibi = std::log10(100000.0) / std::log10(600000.0);
        return gertibi > 0.8 && gertibi < 1.0;
    });

    // Tektometric function: 400 x 400
    test("Tektometric 400x400 at thermax=100", [&]() {
        double tk = tektometric_func(400.0, 400.0, 400.0, 400.0, 100.0);
        return std::isfinite(tk);
    });

    // Speed of light baseline
    test("c = 300000 km/s momentum check", [&]() {
        double c = C_SPEED_KMS;
        double ns_25cm = measure_line_light(25.0, 1.0);
        return c == 300000.0 && ns_25cm > 0;
    });

    // Nanosecond/picosecond precision
    test("Nanosecond timing precision", [&]() {
        double ns = nanosec_timing();
        double ps = picosec_estimate(ns);
        return ns > 0 && ps > 0 && ps == ns * 1000.0;
    });

    // DermaPoint logarithm tangent
    test("Derma log tangent at 55.8C", [&]() {
        double dlt = derma_log_tangent(DERMA_OSI_55_8, LOG_15_4);
        return std::isfinite(dlt);
    });

    suite.total = (int)suite.results.size();
    suite.passed = 0;
    suite.failed = 0;
    for (auto& r : suite.results) {
        if (r.passed) suite.passed++;
        else suite.failed++;
    }

    auto end = std::chrono::steady_clock::now();
    suite.total_duration_sec = std::chrono::duration<double>(end - start).count();
    return suite;
}

std::string ThermalBenchmark::format_report(const ThermalTestSuite& suite) {
    std::ostringstream ss;
    ss << "Thermal Benchmark Report\n";
    ss << "========================\n\n";
    ss << std::fixed;

    for (auto& r : suite.results) {
        ss << (r.passed ? "[PASS] " : "[FAIL] ") << r.test_name;
        ss << std::setprecision(0) << " [" << r.duration_ns << "ns]\n";
        if (!r.notes.empty()) ss << "  " << r.notes << "\n";
    }

    if (!suite.osi_calcs.empty()) {
        ss << "\nOSI Layer Thermal Calculations:\n";
        for (auto& c : suite.osi_calcs) {
            ss << std::setprecision(2)
               << "  " << osi_layer_name(c.layer)
               << " derma=" << c.derma_celsius << "C"
               << " log=" << c.log_value
               << " cal=" << c.caliber
               << " omega=" << std::setprecision(0) << c.angular_velocity << "rps"
               << " ns=" << c.nanosec_timing
               << (c.valid ? " OK" : " FAIL") << "\n";
        }
    }

    ss << "\nTotal: " << suite.total << " Passed: " << suite.passed
       << " Failed: " << suite.failed << "\n";
    ss << std::setprecision(3) << "Duration: " << suite.total_duration_sec << "s\n";
    return ss.str();
}

} // namespace netswitch

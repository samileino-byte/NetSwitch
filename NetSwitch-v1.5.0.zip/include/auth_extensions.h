#pragma once
#include "netswitch.h"
#include "winsock_engine.h"
#include "logger.h"

namespace netswitch {

// ---------------------------------------------------------------------------
// Authentication Extensions: SAML, mTLS, API Tokens, REST Auth
// ---------------------------------------------------------------------------

enum class AuthExtMethod { SAML_SSO, MTLS_CLIENT_CERT, API_TOKEN, OAUTH2, KERBEROS };
enum class SamlBinding { HTTP_POST, HTTP_REDIRECT, ARTIFACT };
enum class CertVerifyResult { VALID, EXPIRED, REVOKED, UNTRUSTED, SELF_SIGNED, HOSTNAME_MISMATCH };

struct SamlAssertion {
    std::string issuer;
    std::string subject;
    std::string audience;
    int64_t not_before;
    int64_t not_after;
    std::map<std::string, std::string> attributes;
    bool signed_flag;
    bool valid;
};

struct MtlsCertInfo {
    std::string subject_cn;
    std::string issuer_cn;
    std::string serial;
    int64_t not_before;
    int64_t not_after;
    int key_size_bits;
    std::string fingerprint_sha256;
    CertVerifyResult verify_result;
};

struct ApiTokenInfo {
    std::string token_id;
    std::string issuer;
    std::string scope;
    int64_t expires_at;
    int64_t issued_at;
    bool revoked;
};

struct RestEndpoint {
    std::string method;
    std::string path;
    bool requires_auth;
    AuthExtMethod auth_method;
    int rate_limit_per_min;
};

struct AuthTestResult {
    std::string test_name;
    AuthExtMethod method;
    bool passed;
    std::string details;
    double duration_ms;
};

struct AuthTestSuite {
    std::vector<AuthTestResult> results;
    int total;
    int passed;
    int failed;
    double duration_sec;
};

class AuthExtensions {
public:
    AuthExtensions(WinsockEngine& engine, Logger& logger);

    AuthTestSuite run_full_suite();

    // SAML SSO
    std::string create_saml_request(const std::string& issuer, const std::string& destination,
                                     SamlBinding binding = SamlBinding::HTTP_POST);
    bool validate_saml_assertion(const SamlAssertion& assertion);
    AuthTestResult test_saml_sso();
    AuthTestResult test_saml_bindings();
    AuthTestResult test_saml_expiry();
    AuthTestResult test_saml_signature();

    // mTLS Client Certificates
    MtlsCertInfo verify_client_cert(const std::vector<uint8_t>& cert_der,
                                     const std::string& expected_hostname = "");
    AuthTestResult test_mtls_handshake();
    AuthTestResult test_mtls_revocation();
    AuthTestResult test_mtls_chain();
    AuthTestResult test_mtls_hostname();

    // API Tokens
    ApiTokenInfo create_api_token(const std::string& issuer, const std::string& scope,
                                   int lifetime_sec = 3600);
    bool validate_api_token(const ApiTokenInfo& token);
    AuthTestResult test_api_token_lifecycle();
    AuthTestResult test_api_rate_limit();
    AuthTestResult test_api_scope();

    // REST Endpoint Auth
    void register_endpoint(const RestEndpoint& ep);
    AuthTestResult test_rest_auth_required();
    AuthTestResult test_rest_endpoints();

    static std::string method_name(AuthExtMethod m);
    static std::string binding_name(SamlBinding b);
    static std::string verify_name(CertVerifyResult r);
    static std::string format_report(const AuthTestSuite& suite);

private:
    WinsockEngine& engine_;
    Logger& logger_;
    std::mt19937 rng_;
    std::vector<RestEndpoint> endpoints_;
    std::vector<ApiTokenInfo> issued_tokens_;
    std::map<std::string, int> rate_counters_;
    std::map<std::string, std::chrono::steady_clock::time_point> rate_windows_;
    std::mutex mutex_;

    std::string generate_token_id();
    std::string compute_fingerprint(const std::vector<uint8_t>& data);
    std::string hmac_sign(const std::string& key, const std::string& data);
    int64_t current_epoch() const;
    bool check_rate_limit(const std::string& endpoint_key, int max_per_min);
};

} // namespace netswitch

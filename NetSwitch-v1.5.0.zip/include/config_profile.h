#pragma once
#include "netswitch.h"
#include "logger.h"

namespace netswitch {

// ---------------------------------------------------------------------------
// Config Profile Enums
// ---------------------------------------------------------------------------

enum class ProfileType {
    NETWORK,
    SECURITY,
    TUNNEL,
    WIFI,
    FULL
};

// ---------------------------------------------------------------------------
// Config Profile Structs
// ---------------------------------------------------------------------------

struct ConfigEntry {
    std::string key;
    std::string value;
    std::string type_hint;
    std::string description;
};

struct ConfigProfile {
    std::string name;
    ProfileType type;
    std::vector<ConfigEntry> entries;
    int64_t created_timestamp;
    int64_t modified_timestamp;
    int version;
};

struct ProfileTestResult {
    std::string test_name;
    bool passed;
    std::string details;
    double duration_ms;
};

struct ProfileTestSuite {
    std::vector<ProfileTestResult> results;
    int total;
    int passed;
    int failed;
    double duration_sec;
};

// ---------------------------------------------------------------------------
// ConfigProfileManager Class
// ---------------------------------------------------------------------------

class ConfigProfileManager {
public:
    ConfigProfileManager(Logger& logger);
    ~ConfigProfileManager();

    ProfileTestSuite run_full_suite();

    // Profile operations
    bool create_profile(const std::string& name, ProfileType type);
    ConfigProfile load_profile(const std::string& name) const;
    bool save_profile(const ConfigProfile& profile);
    bool delete_profile(const std::string& name);
    std::vector<std::string> list_profiles() const;

    // Entry operations
    bool set_entry(const std::string& profile_name, const std::string& key,
                   const std::string& value, const std::string& type_hint = "string",
                   const std::string& description = "");
    std::string get_entry(const std::string& profile_name, const std::string& key) const;
    bool remove_entry(const std::string& profile_name, const std::string& key);
    bool has_entry(const std::string& profile_name, const std::string& key) const;

    // Serialization
    std::string serialize_to_string(const std::string& profile_name) const;
    bool deserialize_from_string(const std::string& data);

    // Templates
    ConfigProfile create_default_network();
    ConfigProfile create_default_security();
    ConfigProfile create_default_tunnel();

    // Comparison
    struct DiffEntry {
        std::string key;
        std::string status;   // "added", "removed", "changed"
        std::string old_value;
        std::string new_value;
    };
    std::vector<DiffEntry> diff_profiles(const std::string& name_a, const std::string& name_b) const;

    // Individual tests
    ProfileTestResult test_create_load_save();
    ProfileTestResult test_entry_ops();
    ProfileTestResult test_serialization();
    ProfileTestResult test_templates();
    ProfileTestResult test_versioning();
    ProfileTestResult test_diff();

    // Static helpers
    static std::string type_name(ProfileType type);
    static std::string format_report(const ProfileTestSuite& suite);

private:
    Logger& logger_;
    mutable std::mutex mutex_;
    std::map<std::string, ConfigProfile> profiles_;

    int64_t current_timestamp() const;
};

} // namespace netswitch

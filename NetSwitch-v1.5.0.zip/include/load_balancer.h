#pragma once
#include "netswitch.h"
#include "winsock_engine.h"
#include "logger.h"

namespace netswitch {

// ---------------------------------------------------------------------------
// Load Balancer Enums
// ---------------------------------------------------------------------------

enum class LbAlgorithm {
    ROUND_ROBIN,
    LEAST_CONNECTIONS,
    WEIGHTED,
    RANDOM,
    IP_HASH,
    LEAST_RESPONSE_TIME
};

enum class BackendState {
    HEALTHY,
    UNHEALTHY,
    DRAINING,
    DISABLED
};

enum class HealthCheckType {
    TCP_CONNECT,
    HTTP_GET,
    PING,
    CUSTOM
};

// ---------------------------------------------------------------------------
// Load Balancer Structs
// ---------------------------------------------------------------------------

struct BackendServer {
    int id;
    std::string host;
    uint16_t port;
    int weight;
    BackendState state;
    int active_connections;
    uint64_t total_requests;
    double avg_response_ms;
    std::chrono::steady_clock::time_point last_health_check;
    int health_check_failures;
};

struct LbConfig {
    LbAlgorithm algorithm;
    std::vector<BackendServer> backends;
    int health_check_interval_sec;
    int health_check_timeout_ms;
    int max_failures;
    bool sticky_sessions;
};

struct LbDecision {
    int selected_backend_id;
    LbAlgorithm algorithm_used;
    int64_t decision_time_ns;
    std::string reason;
};

struct LbTestResult {
    std::string test_name;
    LbAlgorithm algorithm;
    int backends_tested;
    int requests;
    std::map<int, int> distribution;
    bool passed;
    std::string details;
    double duration_ms;
};

struct LbTestSuite {
    std::vector<LbTestResult> results;
    int total;
    int passed;
    int failed;
    double duration_sec;
};

// ---------------------------------------------------------------------------
// LoadBalancer Class
// ---------------------------------------------------------------------------

class LoadBalancer {
public:
    LoadBalancer(WinsockEngine& engine, Logger& logger);
    ~LoadBalancer();

    LbTestSuite run_full_suite();

    // Configuration
    void add_backend(int id, const std::string& host, uint16_t port, int weight = 1);
    void remove_backend(int id);
    void set_algorithm(LbAlgorithm algo);
    LbConfig get_config() const;

    // Selection
    LbDecision select_backend();
    LbDecision select_backend_with_hash(const std::string& client_ip);

    // Health management
    bool health_check(int backend_id);
    void mark_unhealthy(int backend_id);
    void mark_healthy(int backend_id);
    BackendState get_backend_state(int backend_id) const;

    // Individual tests
    LbTestResult test_round_robin();
    LbTestResult test_least_connections();
    LbTestResult test_weighted();
    LbTestResult test_random();
    LbTestResult test_ip_hash();
    LbTestResult test_least_response();
    LbTestResult test_failover();
    LbTestResult test_health_check();
    LbTestResult test_sticky_sessions();
    LbTestResult test_drain();

    // Stats
    std::vector<BackendServer> get_backend_stats() const;
    void reset_stats();

    // Static helpers
    static std::string algorithm_name(LbAlgorithm algo);
    static std::string state_name(BackendState state);
    static std::string format_report(const LbTestSuite& suite);

private:
    WinsockEngine& engine_;
    Logger& logger_;
    mutable std::mutex mutex_;

    LbConfig config_;
    std::atomic<uint64_t> rr_counter_{0};
    std::map<std::string, int> sticky_map_;
    std::mt19937 rng_;

    BackendServer* find_backend(int id);
    const BackendServer* find_backend(int id) const;
    int select_round_robin();
    int select_least_connections();
    int select_weighted();
    int select_random();
    int select_ip_hash(const std::string& client_ip);
    int select_least_response_time();
    int failover(int failed_id);
    uint32_t fnv1a_hash(const std::string& data);
    std::vector<int> get_healthy_ids() const;
};

} // namespace netswitch

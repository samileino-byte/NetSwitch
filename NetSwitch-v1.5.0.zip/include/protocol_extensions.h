#pragma once
#include "netswitch.h"
#include "winsock_engine.h"
#include "logger.h"

namespace netswitch {

// ---------------------------------------------------------------------------
// DNS Record Types & Response Codes
// ---------------------------------------------------------------------------

enum class DnsRecordType { A, AAAA, CNAME, MX, NS, TXT, SRV, SOA, PTR };
enum class DnsResponseCode { NOERROR, FORMERR, SERVFAIL, NXDOMAIN, REFUSED, TIMEOUT };

// ---------------------------------------------------------------------------
// HTTP/2 Frame Types
// ---------------------------------------------------------------------------

enum class Http2FrameType {
    DATA, HEADERS, PRIORITY, RST_STREAM, SETTINGS,
    PUSH_PROMISE, PING, GOAWAY, WINDOW_UPDATE, CONTINUATION
};

// ---------------------------------------------------------------------------
// QUIC Versions
// ---------------------------------------------------------------------------

enum class QuicVersion { V1, V2, DRAFT_29 };

// ---------------------------------------------------------------------------
// Result Structs
// ---------------------------------------------------------------------------

struct DnsQueryResult {
    std::string query;
    DnsRecordType record_type;
    DnsResponseCode response_code;
    std::vector<std::string> answers;
    uint32_t ttl_sec;
    double latency_ms;
    bool authoritative;
    bool passed;
};

struct Http2TestResult {
    std::string test_name;
    Http2FrameType frame_type;
    uint32_t stream_id;
    bool passed;
    double latency_ms;
    std::string details;
    size_t hpack_size;
};

struct QuicTestResult {
    std::string test_name;
    QuicVersion version;
    double handshake_ms;
    double rtt_ms;
    bool zero_rtt_supported;
    bool migration_supported;
    bool passed;
    std::string details;
};

struct ProtocolExtSuite {
    std::vector<DnsQueryResult> dns_results;
    std::vector<Http2TestResult> h2_results;
    std::vector<QuicTestResult> quic_results;
    int total_tests;
    int passed;
    int failed;
    double duration_sec;
};

// ---------------------------------------------------------------------------
// Protocol Extensions Tester
// ---------------------------------------------------------------------------

class ProtocolExtTester {
public:
    ProtocolExtTester(WinsockEngine& engine, Logger& logger);
    ~ProtocolExtTester();

    ProtocolExtSuite run_full_suite();

    // DNS tests
    DnsQueryResult resolve_dns(const std::string& host, DnsRecordType type);
    DnsQueryResult test_dns_resolution();
    DnsQueryResult test_dns_caching();
    DnsQueryResult test_dns_timeout();
    DnsQueryResult test_dns_record_types();

    // HTTP/2 tests
    Http2TestResult test_h2_connection();
    Http2TestResult test_h2_streams();
    Http2TestResult test_h2_server_push();
    Http2TestResult test_h2_flow_control();
    Http2TestResult test_h2_hpack();
    Http2TestResult test_h2_priority();

    // QUIC tests
    QuicTestResult test_quic_handshake();
    QuicTestResult test_quic_0rtt();
    QuicTestResult test_quic_migration();
    QuicTestResult test_quic_streams();
    QuicTestResult test_quic_congestion();

    // Static helpers
    static std::string record_type_name(DnsRecordType t);
    static std::string response_code_name(DnsResponseCode c);
    static std::string frame_type_name(Http2FrameType t);
    static std::string quic_version_name(QuicVersion v);
    static std::string format_report(const ProtocolExtSuite& suite);

private:
    WinsockEngine& engine_;
    Logger& logger_;

    // HTTP/2 helpers
    std::vector<uint8_t> build_h2_frame(Http2FrameType type, uint8_t flags,
                                         uint32_t stream_id, const std::vector<uint8_t>& payload);
    std::vector<uint8_t> hpack_encode(const std::vector<std::pair<std::string, std::string>>& headers);
    size_t hpack_encoded_size(const std::vector<std::pair<std::string, std::string>>& headers);

    // QUIC helpers
    std::vector<uint8_t> build_quic_initial(QuicVersion version, const std::vector<uint8_t>& dcid);
    double measure_quic_handshake(QuicVersion version);
};

} // namespace netswitch

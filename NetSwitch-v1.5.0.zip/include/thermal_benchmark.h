#pragma once
#include "netswitch.h"
#include "winsock_engine.h"
#include "logger.h"

namespace netswitch {

enum class DeviceType { MOBILE, ROUTER, SWITCH, CPU_PROCESSOR };
enum class OsiLayer { PHYSICAL = 1, DATA_LINK, NETWORK, TRANSPORT, SESSION, PRESENTATION, APPLICATION };

struct DeviceDimensions {
    double length_cm;
    double width_cm;
    double depth_cm;
    double line_length_cm;
    DeviceType device;
};

struct DermaPoint {
    double temperature_celsius;
    double thermal_expansion_coeff;
    double derma_value;
    double checksum;
    int osi_layer;
    double log_value;
    double tangent_value;
    bool valid;
};

struct ThermalUnit {
    DeviceType device;
    double cpu_temp_celsius;
    double thermal_capacity_watts;
    double lithium_thermal_c;
    double expansion_rate;
    double angular_velocity_rps;
    double line_speed_mbps;
};

struct ParityCheckResult {
    uint32_t checksum_5;
    uint32_t checksum_6;
    uint32_t checksum_7;
    bool parity_match;
    int repetitions;
    int matches;
    double verification_time_ns;
};

struct OsiLayerCalc {
    OsiLayer layer;
    double derma_celsius;
    double log_value;
    double tangent_speed;
    double caliber;
    double angular_velocity;
    double expansion_deriv;
    double sine_component;
    double cosine_component;
    double checksum;
    double line_length;
    double thermal_watts;
    double parity_bits;
    double nanosec_timing;
    double pico_timing;
    double c_speed_ratio;
    bool valid;
};

struct BabelTowerMetric {
    double parallax_angle;
    double thermax_value;
    double expansion_derivative;
    double folding_rate;
    double structure_depth;
    double logarithm_func;
    double crism_value;
};

struct LineSignalMetric {
    double sine_12000;
    double sine_7000;
    double sine_15000;
    double sine_55000;
    double tan_sine_arc;
    double nanosec_per_log;
    double log_ratio_7000;
    double pico_division;
    double vignette_tangent;
    double wattage_motion;
    double c_momentum;
};

struct GertibiResult {
    double base_ratio;          // log(100000) / log(600000)
    double extended_600k;       // / 600000
    double extended_700k;       // / 700000
    double deep_chain;          // log(100000) / log(1755555...)
    double checksum_division;   // divides checksum pieces
    double line_match_ratio;    // matches line length per user
};

struct UserBoxMetric {
    int user_count;
    DeviceType device;
    double cornering_555;
    double cornering_666;
    double corner_ratio;        // 555/666
    double pipes_per_user;
    double channels_per_user;
    double lithium_thermal;     // Li processor thermal
    double processor_thermality;
    DeviceDimensions dimensions;
    LineSignalMetric line_signal;
    GertibiResult gertibi;
};

struct LineSignalRatio {
    double ratio_12000;         // 1:12000
    double ratio_7165_77;       // 7165.77
    double ratio_7000;          // 7000
    double ratio_6000;          // 6000
    double ratio_7000_b;        // 7000 (second)
    double ratio_1_117;         // 1.117 per ms
    double pico_thousands;      // per thousand in thousand in thousand picos
    double nanosec_55000_log;   // 55000 Log in nanosecond
};

struct ThermalTestResult {
    std::string test_name;
    bool passed;
    double value;
    std::string unit;
    double duration_ns;
    std::string notes;
};

struct ThermalTestSuite {
    std::vector<ThermalTestResult> results;
    int total;
    int passed;
    int failed;
    double total_duration_sec;
    std::vector<DermaPoint> derma_points;
    std::vector<OsiLayerCalc> osi_calcs;
    BabelTowerMetric babel;
    LineSignalMetric line_signal;
    UserBoxMetric user_box;
    LineSignalRatio signal_ratio;
};

class ThermalBenchmark {
public:
    ThermalBenchmark(WinsockEngine& engine, Logger& logger);

    ThermalTestSuite run_full_suite();

    // DermaPoint thermal expansion
    DermaPoint calculate_dermapoint(double temp_celsius, int osi_layer);
    std::vector<DermaPoint> dermapoint_sweep(double temp_min, double temp_max, int steps);

    // Thermal unit measurements
    ThermalUnit measure_thermal(DeviceType device, double line_speed_mbps);
    double thermal_expansion(double temp_celsius, double material_coeff);

    // Parity bit checksum verification (55 repetitions)
    ParityCheckResult verify_parity(const void* data, size_t len, int repetitions = 55);
    uint32_t compute_checksum(const void* data, size_t len, int variant);

    // OSI layer calculations (15 per component)
    OsiLayerCalc calculate_osi_layer(OsiLayer layer, double temp_celsius, double speed_mbps);
    std::vector<OsiLayerCalc> calculate_all_osi_layers(double temp_celsius, double speed_mbps);

    // Angular velocity / caliber
    double angular_velocity(double speed_mbps, double rounds_per_sec = 455.0);
    double network_caliber(double tangent_speed, double angular_vel);

    // Babel tower structural expansion
    BabelTowerMetric babel_tower(double thermax, double parallax_angle);
    double babel_expansion_derivative(double thermax, double depth);

    // Line signal calculations
    LineSignalMetric line_signal_calc(const DeviceDimensions& device);
    double line_length_ratio(const DeviceDimensions& device, double frequency);

    // RS-232 header operations
    double rs232_header_cycle(int cycles_per_sec = 255);
    double measure_line_light(double distance_cm, double freq_hz);

    // Gertibi extended log chain
    GertibiResult gertibi_calc(const std::vector<double>& log_values);
    double gertibi_checksum_divide(const GertibiResult& g, double line_length, int user_count);

    // User-per-box calculation
    UserBoxMetric user_box_calc(DeviceType device, int user_count);
    double cornering_measure(double dim_555, double dim_666);
    double lithium_processor_thermal(DeviceType device, double speed_mbps);

    // Enhanced line signal ratios
    LineSignalRatio line_signal_ratio_calc(const DeviceDimensions& device, int user_count);
    double tan_sine_arc_calc(double freq_hz, double line_length);
    double nanosec_log_chain(double freq_hz, int depth);

    // Logarithmic chain calculations
    double log_chain(const std::vector<double>& values);
    double sin_chain(const std::vector<double>& values);
    double derma_log_tangent(double celsius, double log_val);

    // Speed of light baseline
    static constexpr double C_SPEED_KMS = 300000.0;
    static constexpr double OMEGA_RPS = 455.0;
    static constexpr double DERMA_OSI_55_8 = 55.8;
    static constexpr double LOG_15_4 = 15.4;
    static constexpr double CELSIUS_255_9 = 255.9;

    // Device templates
    static DeviceDimensions mobile_device();
    static DeviceDimensions router_device();
    static DeviceDimensions switch_device();

    static std::string device_name(DeviceType d);
    static std::string osi_layer_name(OsiLayer l);
    static std::string format_report(const ThermalTestSuite& suite);

private:
    WinsockEngine& engine_;
    Logger& logger_;
    std::mt19937 rng_;

    double nanosec_timing();
    double picosec_estimate(double nanosec);
    double tektometric_func(double b, double c, double g, double cge, double thermax);
};

} // namespace netswitch

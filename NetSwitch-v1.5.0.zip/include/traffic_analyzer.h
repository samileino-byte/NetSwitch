#pragma once
#include "netswitch.h"
#include "winsock_engine.h"
#include "logger.h"
#include "packet_inspector.h"

namespace netswitch {

// ---------------------------------------------------------------------------
// Traffic Analysis & Filtering Rules Engine
// ---------------------------------------------------------------------------

enum class FilterAction { ALLOW, DENY, LOG, REDIRECT, RATE_LIMIT };
enum class FilterMatch { SRC_IP, DST_IP, SRC_PORT, DST_PORT, PROTOCOL, PAYLOAD, HEADER, ANY };
enum class TrafficDirection { INBOUND, OUTBOUND, BOTH };
enum class ProtocolFilter { TCP_ONLY, UDP_ONLY, ICMP_ONLY, ALL_PROTOCOLS };

struct FilterRule {
    uint32_t id;
    std::string name;
    FilterMatch match_type;
    FilterAction action;
    TrafficDirection direction;
    ProtocolFilter protocol;
    std::string pattern;
    int priority;           // lower = higher priority
    bool enabled;
    uint64_t hit_count;
};

struct TrafficStats {
    uint64_t total_packets;
    uint64_t total_bytes;
    double packets_per_sec;
    double bytes_per_sec;
    uint64_t tcp_count;
    uint64_t udp_count;
    uint64_t icmp_count;
    uint64_t filtered_count;
    uint64_t allowed_count;
    uint64_t denied_count;
};

struct FilterTestResult {
    std::string test_name;
    int rules_tested;
    int rules_matched;
    bool passed;
    double latency_ms;
    std::string details;
};

struct TrafficAnalyzerSuite {
    std::vector<FilterTestResult> results;
    TrafficStats stats;
    int total;
    int passed;
    int failed;
    double duration_sec;
};

class TrafficAnalyzer {
public:
    TrafficAnalyzer(WinsockEngine& engine, Logger& logger);
    ~TrafficAnalyzer();

    TrafficAnalyzerSuite run_full_suite();

    // Rule management
    void add_rule(const FilterRule& rule);
    bool remove_rule(uint32_t id);
    bool enable_rule(uint32_t id);
    bool disable_rule(uint32_t id);
    std::vector<FilterRule> get_rules() const;
    void clear_rules();

    // Analysis
    FilterAction analyze_packet(const uint8_t* data, int len);
    bool match_rule(const uint8_t* data, int len, const FilterRule& rule);
    FilterAction evaluate_rules(const uint8_t* data, int len);

    // Test methods
    FilterTestResult test_rule_matching();
    FilterTestResult test_rule_priority();
    FilterTestResult test_filter_chain();
    FilterTestResult test_rate_limiting();
    FilterTestResult test_pattern_matching();
    FilterTestResult test_protocol_filtering();
    FilterTestResult test_direction_filtering();
    FilterTestResult test_rule_persistence();
    FilterTestResult test_stats_accuracy();
    FilterTestResult test_concurrent_rules();
    FilterTestResult test_empty_ruleset();
    FilterTestResult test_wildcard_matching();
    FilterTestResult test_rule_enable_disable();
    FilterTestResult test_hit_count_tracking();
    FilterTestResult test_large_ruleset_performance();

    // Stats
    TrafficStats get_stats() const;
    void reset_stats();

    // Static helpers
    static std::string action_name(FilterAction a);
    static std::string match_name(FilterMatch m);
    static std::string direction_name(TrafficDirection d);
    static std::string protocol_filter_name(ProtocolFilter p);
    static std::string format_report(const TrafficAnalyzerSuite& suite);

private:
    WinsockEngine& engine_;
    Logger& logger_;

    std::vector<FilterRule> rules_;
    mutable std::mutex rules_mutex_;

    TrafficStats stats_ = {};
    std::chrono::steady_clock::time_point stats_start_;
    mutable std::mutex stats_mutex_;

    uint32_t next_rule_id_ = 1;

    // Rate limiting state (token bucket per rule id)
    struct TokenBucket {
        double tokens;
        double max_tokens;
        double refill_rate;     // tokens per second
        std::chrono::steady_clock::time_point last_refill;
    };
    std::map<uint32_t, TokenBucket> rate_limiters_;
    std::mutex rate_mutex_;

    // Internal helpers
    bool match_pattern_in_payload(const uint8_t* data, int len, const std::string& pattern);
    bool match_ip_field(const uint8_t* data, int len, const std::string& pattern, bool src);
    bool match_port_field(const uint8_t* data, int len, const std::string& pattern, bool src);
    uint8_t identify_protocol(const uint8_t* data, int len);
    TrafficDirection identify_direction(const uint8_t* data, int len);
    bool check_rate_limit(uint32_t rule_id);
    void update_stats(const uint8_t* data, int len, FilterAction action);

    // Test packet builders
    std::vector<uint8_t> build_test_ipv4_tcp(const std::string& src_ip, const std::string& dst_ip,
                                              uint16_t src_port, uint16_t dst_port,
                                              const std::string& payload = "");
    std::vector<uint8_t> build_test_ipv4_udp(const std::string& src_ip, const std::string& dst_ip,
                                              uint16_t src_port, uint16_t dst_port,
                                              const std::string& payload = "");
    std::vector<uint8_t> build_test_ipv4_icmp(const std::string& src_ip, const std::string& dst_ip);
    uint32_t ip_to_u32(const std::string& ip);
    void write_u16_be(uint8_t* p, uint16_t val);
    void write_u32_be(uint8_t* p, uint32_t val);
};

} // namespace netswitch

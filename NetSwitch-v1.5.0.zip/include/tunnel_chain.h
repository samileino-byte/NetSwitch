#pragma once
#include "netswitch.h"
#include "winsock_engine.h"
#include "logger.h"

namespace netswitch {

// ---------------------------------------------------------------------------
// Multi-Hop Tunnel Chaining: IKEv2 -> SSH -> endpoint
// ---------------------------------------------------------------------------

enum class HopProtocol { IKEV2, SSH, GRU, SOCKS5, HTTP_PROXY };
enum class ChainState { BUILDING, PARTIAL, ESTABLISHED, BROKEN, TORN_DOWN };

struct TunnelHop {
    int hop_index;
    HopProtocol protocol;
    std::string host;
    uint16_t port;
    std::string username;
    std::string password;
    bool connected;
    double latency_ms;
    std::string encryption;
};

struct TunnelChain {
    std::string chain_id;
    std::vector<TunnelHop> hops;
    ChainState state;
    double total_latency_ms;
    int established_hops;
    int total_hops;
};

struct ChainTestResult {
    std::string test_name;
    int chain_length;
    int hops_established;
    double total_latency_ms;
    bool passed;
    std::string details;
};

struct ChainTestSuite {
    std::vector<ChainTestResult> results;
    int total;
    int passed;
    int failed;
    double duration_sec;
    int max_chain_depth;
};

class TunnelChainManager {
public:
    TunnelChainManager(WinsockEngine& engine, Logger& logger);

    ChainTestSuite run_full_suite();

    // Chain operations
    std::string create_chain();
    bool add_hop(const std::string& chain_id, HopProtocol protocol,
                 const std::string& host, uint16_t port,
                 const std::string& username = "", const std::string& password = "",
                 const std::string& encryption = "AES-256-GCM");
    bool remove_hop(const std::string& chain_id, int hop_index);
    bool establish_chain(const std::string& chain_id);
    bool teardown_chain(const std::string& chain_id);
    ChainState get_chain_state(const std::string& chain_id) const;

    // Chain testing
    ChainTestResult test_ikev2_ssh_chain();
    ChainTestResult test_ssh_socks_chain();
    ChainTestResult test_triple_hop();
    ChainTestResult test_chain_failover();
    ChainTestResult test_chain_latency();
    ChainTestResult test_chain_teardown();
    ChainTestResult test_max_depth();
    ChainTestResult test_hop_authentication();
    ChainTestResult test_chain_encryption();
    ChainTestResult test_partial_chain();

    static std::string protocol_name(HopProtocol p);
    static std::string state_name(ChainState s);
    static std::string format_report(const ChainTestSuite& suite);

private:
    WinsockEngine& engine_;
    Logger& logger_;
    std::map<std::string, TunnelChain> chains_;
    mutable std::mutex mutex_;
    int next_id_ = 1;

    static const int MAX_CHAIN_DEPTH = 10;

    std::string generate_chain_id();
    bool simulate_ikev2_hop(TunnelHop& hop);
    bool simulate_ssh_hop(TunnelHop& hop);
    bool simulate_gru_hop(TunnelHop& hop);
    bool simulate_socks5_hop(TunnelHop& hop);
    bool simulate_http_proxy_hop(TunnelHop& hop);
    bool verify_hop_encryption(const TunnelHop& hop);
    double measure_hop_latency(const TunnelHop& hop);
};

} // namespace netswitch

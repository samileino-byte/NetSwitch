#include "config_profile.h"
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <set>

namespace netswitch {

// ===========================================================================
// ConfigProfileManager Implementation
// ===========================================================================

ConfigProfileManager::ConfigProfileManager(Logger& logger)
    : logger_(logger) {}

ConfigProfileManager::~ConfigProfileManager() {}

int64_t ConfigProfileManager::current_timestamp() const {
    return std::chrono::duration_cast<std::chrono::seconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
}

// ---------------------------------------------------------------------------
// Profile operations
// ---------------------------------------------------------------------------

bool ConfigProfileManager::create_profile(const std::string& name, ProfileType type) {
    std::lock_guard<std::mutex> lk(mutex_);
    if (profiles_.find(name) != profiles_.end()) {
        logger_.warning("ConfigProfile", "Profile '" + name + "' already exists");
        return false;
    }

    ConfigProfile profile;
    profile.name = name;
    profile.type = type;
    profile.created_timestamp = current_timestamp();
    profile.modified_timestamp = profile.created_timestamp;
    profile.version = 1;

    profiles_[name] = profile;
    logger_.info("ConfigProfile", "Created profile '" + name + "' (" + type_name(type) + ")");
    return true;
}

ConfigProfile ConfigProfileManager::load_profile(const std::string& name) const {
    std::lock_guard<std::mutex> lk(mutex_);
    auto it = profiles_.find(name);
    if (it != profiles_.end()) {
        return it->second;
    }
    // Return empty profile
    ConfigProfile empty;
    empty.name = "";
    empty.type = ProfileType::NETWORK;
    empty.created_timestamp = 0;
    empty.modified_timestamp = 0;
    empty.version = 0;
    return empty;
}

bool ConfigProfileManager::save_profile(const ConfigProfile& profile) {
    std::lock_guard<std::mutex> lk(mutex_);
    if (profile.name.empty()) {
        logger_.warning("ConfigProfile", "Cannot save profile with empty name");
        return false;
    }

    auto it = profiles_.find(profile.name);
    if (it != profiles_.end()) {
        // Update existing - increment version
        profiles_[profile.name] = profile;
        profiles_[profile.name].version = it->second.version + 1;
        profiles_[profile.name].modified_timestamp = current_timestamp();
    } else {
        profiles_[profile.name] = profile;
        profiles_[profile.name].modified_timestamp = current_timestamp();
    }

    logger_.debug("ConfigProfile", "Saved profile '" + profile.name +
                  "' (v" + std::to_string(profiles_[profile.name].version) + ")");
    return true;
}

bool ConfigProfileManager::delete_profile(const std::string& name) {
    std::lock_guard<std::mutex> lk(mutex_);
    auto it = profiles_.find(name);
    if (it == profiles_.end()) {
        logger_.warning("ConfigProfile", "Profile '" + name + "' not found for deletion");
        return false;
    }
    profiles_.erase(it);
    logger_.info("ConfigProfile", "Deleted profile '" + name + "'");
    return true;
}

std::vector<std::string> ConfigProfileManager::list_profiles() const {
    std::lock_guard<std::mutex> lk(mutex_);
    std::vector<std::string> names;
    for (auto& [name, _] : profiles_) {
        names.push_back(name);
    }
    return names;
}

// ---------------------------------------------------------------------------
// Entry operations
// ---------------------------------------------------------------------------

bool ConfigProfileManager::set_entry(const std::string& profile_name, const std::string& key,
                                     const std::string& value, const std::string& type_hint,
                                     const std::string& description) {
    std::lock_guard<std::mutex> lk(mutex_);
    auto it = profiles_.find(profile_name);
    if (it == profiles_.end()) {
        logger_.warning("ConfigProfile", "Profile '" + profile_name + "' not found");
        return false;
    }

    auto& profile = it->second;

    // Update existing entry or add new
    for (auto& entry : profile.entries) {
        if (entry.key == key) {
            entry.value = value;
            entry.type_hint = type_hint;
            if (!description.empty()) entry.description = description;
            profile.modified_timestamp = current_timestamp();
            profile.version++;
            return true;
        }
    }

    ConfigEntry entry;
    entry.key = key;
    entry.value = value;
    entry.type_hint = type_hint;
    entry.description = description;
    profile.entries.push_back(entry);
    profile.modified_timestamp = current_timestamp();
    profile.version++;
    return true;
}

std::string ConfigProfileManager::get_entry(const std::string& profile_name,
                                            const std::string& key) const {
    std::lock_guard<std::mutex> lk(mutex_);
    auto it = profiles_.find(profile_name);
    if (it == profiles_.end()) return "";

    for (auto& entry : it->second.entries) {
        if (entry.key == key) return entry.value;
    }
    return "";
}

bool ConfigProfileManager::remove_entry(const std::string& profile_name,
                                        const std::string& key) {
    std::lock_guard<std::mutex> lk(mutex_);
    auto it = profiles_.find(profile_name);
    if (it == profiles_.end()) return false;

    auto& entries = it->second.entries;
    auto eit = std::remove_if(entries.begin(), entries.end(),
        [&key](const ConfigEntry& e) { return e.key == key; });
    if (eit == entries.end()) return false;

    entries.erase(eit, entries.end());
    it->second.modified_timestamp = current_timestamp();
    it->second.version++;
    return true;
}

bool ConfigProfileManager::has_entry(const std::string& profile_name,
                                     const std::string& key) const {
    std::lock_guard<std::mutex> lk(mutex_);
    auto it = profiles_.find(profile_name);
    if (it == profiles_.end()) return false;

    for (auto& entry : it->second.entries) {
        if (entry.key == key) return true;
    }
    return false;
}

// ---------------------------------------------------------------------------
// Serialization
// ---------------------------------------------------------------------------

std::string ConfigProfileManager::serialize_to_string(const std::string& profile_name) const {
    std::lock_guard<std::mutex> lk(mutex_);
    auto it = profiles_.find(profile_name);
    if (it == profiles_.end()) return "";

    const auto& profile = it->second;
    std::ostringstream ss;

    ss << "[" << profile.name << "]\n";
    ss << "# type=" << type_name(profile.type) << "\n";
    ss << "# version=" << profile.version << "\n";
    ss << "# created=" << profile.created_timestamp << "\n";
    ss << "# modified=" << profile.modified_timestamp << "\n";

    for (auto& entry : profile.entries) {
        if (!entry.description.empty()) {
            ss << "# " << entry.description << "\n";
        }
        ss << entry.key << "=" << entry.value;
        if (!entry.type_hint.empty() && entry.type_hint != "string") {
            ss << " # " << entry.type_hint;
        }
        ss << "\n";
    }

    return ss.str();
}

bool ConfigProfileManager::deserialize_from_string(const std::string& data) {
    std::lock_guard<std::mutex> lk(mutex_);

    std::istringstream stream(data);
    std::string line;
    std::string current_name;
    ConfigProfile current_profile;
    bool has_profile = false;

    auto parse_type = [](const std::string& s) -> ProfileType {
        if (s == "Network") return ProfileType::NETWORK;
        if (s == "Security") return ProfileType::SECURITY;
        if (s == "Tunnel") return ProfileType::TUNNEL;
        if (s == "WiFi") return ProfileType::WIFI;
        if (s == "Full") return ProfileType::FULL;
        return ProfileType::NETWORK;
    };

    while (std::getline(stream, line)) {
        // Trim whitespace
        size_t start = line.find_first_not_of(" \t\r\n");
        if (start == std::string::npos) continue;
        line = line.substr(start);

        // Section header [name]
        if (line.front() == '[' && line.back() == ']') {
            // Save previous profile if any
            if (has_profile && !current_name.empty()) {
                current_profile.name = current_name;
                if (current_profile.created_timestamp == 0) {
                    current_profile.created_timestamp = current_timestamp();
                }
                if (current_profile.modified_timestamp == 0) {
                    current_profile.modified_timestamp = current_timestamp();
                }
                if (current_profile.version == 0) {
                    current_profile.version = 1;
                }
                profiles_[current_name] = current_profile;
            }

            current_name = line.substr(1, line.length() - 2);
            current_profile = ConfigProfile();
            current_profile.name = current_name;
            current_profile.type = ProfileType::NETWORK;
            current_profile.version = 1;
            current_profile.created_timestamp = current_timestamp();
            current_profile.modified_timestamp = current_timestamp();
            has_profile = true;
            continue;
        }

        // Comment/metadata line
        if (line.front() == '#') {
            std::string meta = line.substr(1);
            start = meta.find_first_not_of(" \t");
            if (start != std::string::npos) meta = meta.substr(start);

            if (meta.substr(0, 5) == "type=") {
                current_profile.type = parse_type(meta.substr(5));
            } else if (meta.substr(0, 8) == "version=") {
                try { current_profile.version = std::stoi(meta.substr(8)); }
                catch (...) {}
            } else if (meta.substr(0, 8) == "created=") {
                try { current_profile.created_timestamp = std::stoll(meta.substr(8)); }
                catch (...) {}
            } else if (meta.substr(0, 9) == "modified=") {
                try { current_profile.modified_timestamp = std::stoll(meta.substr(9)); }
                catch (...) {}
            }
            continue;
        }

        // Key=value line
        auto eq_pos = line.find('=');
        if (eq_pos == std::string::npos) continue;

        ConfigEntry entry;
        entry.key = line.substr(0, eq_pos);
        std::string rest = line.substr(eq_pos + 1);

        // Check for inline type hint comment: value # type_hint
        auto hash_pos = rest.find(" # ");
        if (hash_pos != std::string::npos) {
            entry.value = rest.substr(0, hash_pos);
            entry.type_hint = rest.substr(hash_pos + 3);
        } else {
            entry.value = rest;
            entry.type_hint = "string";
        }

        // Trim trailing whitespace from value
        size_t end = entry.value.find_last_not_of(" \t\r\n");
        if (end != std::string::npos) entry.value = entry.value.substr(0, end + 1);

        current_profile.entries.push_back(entry);
    }

    // Save last profile
    if (has_profile && !current_name.empty()) {
        current_profile.name = current_name;
        if (current_profile.created_timestamp == 0) {
            current_profile.created_timestamp = current_timestamp();
        }
        if (current_profile.modified_timestamp == 0) {
            current_profile.modified_timestamp = current_timestamp();
        }
        if (current_profile.version == 0) {
            current_profile.version = 1;
        }
        profiles_[current_name] = current_profile;
    }

    logger_.info("ConfigProfile", "Deserialized profiles from string (" +
                 std::to_string(profiles_.size()) + " profiles)");
    return has_profile;
}

// ---------------------------------------------------------------------------
// Templates
// ---------------------------------------------------------------------------

ConfigProfile ConfigProfileManager::create_default_network() {
    ConfigProfile profile;
    profile.name = "default_network";
    profile.type = ProfileType::NETWORK;
    profile.created_timestamp = current_timestamp();
    profile.modified_timestamp = profile.created_timestamp;
    profile.version = 1;

    auto add = [&](const std::string& k, const std::string& v,
                   const std::string& t, const std::string& d) {
        profile.entries.push_back({k, v, t, d});
    };

    add("interface", "eth0", "string", "Primary network interface");
    add("ip_version", "4", "int", "IP version (4 or 6)");
    add("dhcp_enabled", "true", "bool", "Use DHCP for address assignment");
    add("mtu", "1500", "int", "Maximum transmission unit");
    add("dns_primary", "8.8.8.8", "string", "Primary DNS server");
    add("dns_secondary", "8.8.4.4", "string", "Secondary DNS server");
    add("tcp_nodelay", "true", "bool", "Disable Nagle algorithm");
    add("keepalive_interval", "30", "int", "TCP keepalive interval (seconds)");
    add("connect_timeout", "5000", "int", "Connection timeout (ms)");
    add("recv_buffer", "65536", "int", "Receive buffer size (bytes)");
    add("send_buffer", "65536", "int", "Send buffer size (bytes)");

    {
        std::lock_guard<std::mutex> lk(mutex_);
        profiles_[profile.name] = profile;
    }

    logger_.info("ConfigProfile", "Created default network profile");
    return profile;
}

ConfigProfile ConfigProfileManager::create_default_security() {
    ConfigProfile profile;
    profile.name = "default_security";
    profile.type = ProfileType::SECURITY;
    profile.created_timestamp = current_timestamp();
    profile.modified_timestamp = profile.created_timestamp;
    profile.version = 1;

    auto add = [&](const std::string& k, const std::string& v,
                   const std::string& t, const std::string& d) {
        profile.entries.push_back({k, v, t, d});
    };

    add("tls_min_version", "1.2", "string", "Minimum TLS version");
    add("tls_max_version", "1.3", "string", "Maximum TLS version");
    add("cert_verify", "true", "bool", "Verify server certificates");
    add("cert_store_path", "/etc/ssl/certs", "string", "Certificate store path");
    add("cipher_suite", "TLS_AES_256_GCM_SHA384", "string", "Preferred cipher suite");
    add("pci_dss_logging", "true", "bool", "Enable PCI-DSS compliant logging");
    add("auth_method", "certificate", "string", "Authentication method");
    add("session_timeout", "3600", "int", "Session timeout (seconds)");
    add("max_retries", "3", "int", "Maximum authentication retries");

    {
        std::lock_guard<std::mutex> lk(mutex_);
        profiles_[profile.name] = profile;
    }

    logger_.info("ConfigProfile", "Created default security profile");
    return profile;
}

ConfigProfile ConfigProfileManager::create_default_tunnel() {
    ConfigProfile profile;
    profile.name = "default_tunnel";
    profile.type = ProfileType::TUNNEL;
    profile.created_timestamp = current_timestamp();
    profile.modified_timestamp = profile.created_timestamp;
    profile.version = 1;

    auto add = [&](const std::string& k, const std::string& v,
                   const std::string& t, const std::string& d) {
        profile.entries.push_back({k, v, t, d});
    };

    add("tunnel_type", "ikev2", "string", "Tunnel protocol type");
    add("remote_host", "vpn.example.com", "string", "Remote tunnel endpoint");
    add("remote_port", "500", "int", "Remote port");
    add("local_bind", "0.0.0.0", "string", "Local bind address");
    add("local_port", "0", "int", "Local port (0 = auto)");
    add("auto_reconnect", "true", "bool", "Automatic reconnection on disconnect");
    add("reconnect_delay", "5", "int", "Reconnect delay (seconds)");
    add("keepalive", "30", "int", "Tunnel keepalive interval (seconds)");
    add("mss_clamp", "1360", "int", "TCP MSS clamping value");
    add("compression", "false", "bool", "Enable tunnel compression");

    {
        std::lock_guard<std::mutex> lk(mutex_);
        profiles_[profile.name] = profile;
    }

    logger_.info("ConfigProfile", "Created default tunnel profile");
    return profile;
}

// ---------------------------------------------------------------------------
// Comparison
// ---------------------------------------------------------------------------

std::vector<ConfigProfileManager::DiffEntry>
ConfigProfileManager::diff_profiles(const std::string& name_a, const std::string& name_b) const {
    std::lock_guard<std::mutex> lk(mutex_);
    std::vector<DiffEntry> diffs;

    auto it_a = profiles_.find(name_a);
    auto it_b = profiles_.find(name_b);

    if (it_a == profiles_.end() || it_b == profiles_.end()) {
        logger_.warning("ConfigProfile", "Cannot diff: profile not found");
        return diffs;
    }

    const auto& a = it_a->second;
    const auto& b = it_b->second;

    // Build key->value maps
    std::map<std::string, std::string> map_a, map_b;
    for (auto& e : a.entries) map_a[e.key] = e.value;
    for (auto& e : b.entries) map_b[e.key] = e.value;

    // Collect all keys
    std::set<std::string> all_keys;
    for (auto& [k, _] : map_a) all_keys.insert(k);
    for (auto& [k, _] : map_b) all_keys.insert(k);

    for (auto& key : all_keys) {
        bool in_a = (map_a.find(key) != map_a.end());
        bool in_b = (map_b.find(key) != map_b.end());

        if (in_a && !in_b) {
            diffs.push_back({key, "removed", map_a[key], ""});
        } else if (!in_a && in_b) {
            diffs.push_back({key, "added", "", map_b[key]});
        } else if (in_a && in_b && map_a[key] != map_b[key]) {
            diffs.push_back({key, "changed", map_a[key], map_b[key]});
        }
    }

    return diffs;
}

// ---------------------------------------------------------------------------
// Static helpers
// ---------------------------------------------------------------------------

std::string ConfigProfileManager::type_name(ProfileType type) {
    switch (type) {
        case ProfileType::NETWORK:  return "Network";
        case ProfileType::SECURITY: return "Security";
        case ProfileType::TUNNEL:   return "Tunnel";
        case ProfileType::WIFI:     return "WiFi";
        case ProfileType::FULL:     return "Full";
    }
    return "Unknown";
}

// ===========================================================================
// Test Implementations
// ===========================================================================

ProfileTestResult ConfigProfileManager::test_create_load_save() {
    ProfileTestResult result;
    result.test_name = "Create / Load / Save";
    auto t1 = std::chrono::steady_clock::now();

    // Clean slate
    {
        std::lock_guard<std::mutex> lk(mutex_);
        profiles_.clear();
    }

    // Create
    bool created = create_profile("test_cls", ProfileType::NETWORK);
    if (!created) {
        result.passed = false;
        result.details = "Failed to create profile";
        auto t2 = std::chrono::steady_clock::now();
        result.duration_ms = std::chrono::duration<double, std::milli>(t2 - t1).count();
        return result;
    }

    // Load
    auto loaded = load_profile("test_cls");
    bool name_ok = (loaded.name == "test_cls");
    bool type_ok = (loaded.type == ProfileType::NETWORK);
    bool version_ok = (loaded.version == 1);

    // Modify and save
    loaded.type = ProfileType::SECURITY;
    bool saved = save_profile(loaded);

    auto reloaded = load_profile("test_cls");
    bool save_ok = saved && (reloaded.type == ProfileType::SECURITY);
    bool version_inc = (reloaded.version == 2);

    // Load non-existent
    auto missing = load_profile("nonexistent");
    bool missing_ok = (missing.name.empty() && missing.version == 0);

    // Delete
    bool deleted = delete_profile("test_cls");
    auto after_delete = load_profile("test_cls");
    bool delete_ok = deleted && (after_delete.version == 0);

    result.passed = name_ok && type_ok && version_ok && save_ok && version_inc &&
                    missing_ok && delete_ok;
    result.details = "create=" + std::string(name_ok ? "OK" : "FAIL") +
                     " load=" + std::string(type_ok ? "OK" : "FAIL") +
                     " version=" + std::string(version_ok ? "OK" : "FAIL") +
                     " save=" + std::string(save_ok ? "OK" : "FAIL") +
                     " version_inc=" + std::string(version_inc ? "OK" : "FAIL") +
                     " missing=" + std::string(missing_ok ? "OK" : "FAIL") +
                     " delete=" + std::string(delete_ok ? "OK" : "FAIL");

    auto t2 = std::chrono::steady_clock::now();
    result.duration_ms = std::chrono::duration<double, std::milli>(t2 - t1).count();

    logger_.debug("ConfigProfile", "test_create_load_save: " +
                  std::string(result.passed ? "PASS" : "FAIL"));
    return result;
}

ProfileTestResult ConfigProfileManager::test_entry_ops() {
    ProfileTestResult result;
    result.test_name = "Entry Operations";
    auto t1 = std::chrono::steady_clock::now();

    {
        std::lock_guard<std::mutex> lk(mutex_);
        profiles_.clear();
    }

    create_profile("test_entries", ProfileType::NETWORK);

    // Set entries
    bool s1 = set_entry("test_entries", "host", "10.0.0.1", "string", "Target host");
    bool s2 = set_entry("test_entries", "port", "8080", "int", "Target port");
    bool s3 = set_entry("test_entries", "timeout", "5000", "int", "Timeout ms");

    // Get entries
    std::string v1 = get_entry("test_entries", "host");
    std::string v2 = get_entry("test_entries", "port");
    std::string v3 = get_entry("test_entries", "timeout");
    bool get_ok = (v1 == "10.0.0.1") && (v2 == "8080") && (v3 == "5000");

    // Has entry
    bool has_ok = has_entry("test_entries", "host") && !has_entry("test_entries", "missing");

    // Update entry
    set_entry("test_entries", "host", "192.168.1.1");
    std::string updated = get_entry("test_entries", "host");
    bool update_ok = (updated == "192.168.1.1");

    // Remove entry
    bool removed = remove_entry("test_entries", "timeout");
    bool after_remove = !has_entry("test_entries", "timeout");
    bool remove_ok = removed && after_remove;

    // Get from non-existent profile
    std::string bad = get_entry("nonexistent", "key");
    bool bad_ok = bad.empty();

    // Remove non-existent entry
    bool bad_remove = !remove_entry("test_entries", "nonexistent_key");

    result.passed = s1 && s2 && s3 && get_ok && has_ok && update_ok && remove_ok &&
                    bad_ok && bad_remove;
    result.details = "set=" + std::string((s1 && s2 && s3) ? "OK" : "FAIL") +
                     " get=" + std::string(get_ok ? "OK" : "FAIL") +
                     " has=" + std::string(has_ok ? "OK" : "FAIL") +
                     " update=" + std::string(update_ok ? "OK" : "FAIL") +
                     " remove=" + std::string(remove_ok ? "OK" : "FAIL") +
                     " edge=" + std::string((bad_ok && bad_remove) ? "OK" : "FAIL");

    auto t2 = std::chrono::steady_clock::now();
    result.duration_ms = std::chrono::duration<double, std::milli>(t2 - t1).count();

    logger_.debug("ConfigProfile", "test_entry_ops: " +
                  std::string(result.passed ? "PASS" : "FAIL"));
    return result;
}

ProfileTestResult ConfigProfileManager::test_serialization() {
    ProfileTestResult result;
    result.test_name = "Serialization / Deserialization";
    auto t1 = std::chrono::steady_clock::now();

    {
        std::lock_guard<std::mutex> lk(mutex_);
        profiles_.clear();
    }

    // Create profile with entries
    create_profile("serial_test", ProfileType::SECURITY);
    set_entry("serial_test", "tls_version", "1.3", "string", "TLS version");
    set_entry("serial_test", "verify_certs", "true", "bool", "Certificate verification");
    set_entry("serial_test", "max_retries", "5", "int", "Max retry count");

    // Serialize
    std::string serialized = serialize_to_string("serial_test");
    bool has_header = (serialized.find("[serial_test]") != std::string::npos);
    bool has_entries = (serialized.find("tls_version=1.3") != std::string::npos) &&
                       (serialized.find("verify_certs=true") != std::string::npos) &&
                       (serialized.find("max_retries=5") != std::string::npos);

    // Clear and deserialize
    {
        std::lock_guard<std::mutex> lk(mutex_);
        profiles_.clear();
    }

    bool deser_ok = deserialize_from_string(serialized);

    // Verify restored profile
    auto restored = load_profile("serial_test");
    bool name_ok = (restored.name == "serial_test");
    bool entries_ok = (get_entry("serial_test", "tls_version") == "1.3") &&
                      (get_entry("serial_test", "verify_certs") == "true") &&
                      (get_entry("serial_test", "max_retries") == "5");

    // Serialize empty profile name
    std::string empty_ser = serialize_to_string("nonexistent");
    bool empty_ok = empty_ser.empty();

    result.passed = has_header && has_entries && deser_ok && name_ok && entries_ok && empty_ok;
    result.details = "header=" + std::string(has_header ? "OK" : "FAIL") +
                     " entries=" + std::string(has_entries ? "OK" : "FAIL") +
                     " deser=" + std::string(deser_ok ? "OK" : "FAIL") +
                     " restored=" + std::string((name_ok && entries_ok) ? "OK" : "FAIL") +
                     " edge=" + std::string(empty_ok ? "OK" : "FAIL");

    auto t2 = std::chrono::steady_clock::now();
    result.duration_ms = std::chrono::duration<double, std::milli>(t2 - t1).count();

    logger_.debug("ConfigProfile", "test_serialization: " +
                  std::string(result.passed ? "PASS" : "FAIL"));
    return result;
}

ProfileTestResult ConfigProfileManager::test_templates() {
    ProfileTestResult result;
    result.test_name = "Template Profiles";
    auto t1 = std::chrono::steady_clock::now();

    {
        std::lock_guard<std::mutex> lk(mutex_);
        profiles_.clear();
    }

    auto net = create_default_network();
    auto sec = create_default_security();
    auto tun = create_default_tunnel();

    bool net_ok = (net.name == "default_network") &&
                  (net.type == ProfileType::NETWORK) &&
                  (!net.entries.empty());
    bool sec_ok = (sec.name == "default_security") &&
                  (sec.type == ProfileType::SECURITY) &&
                  (!sec.entries.empty());
    bool tun_ok = (tun.name == "default_tunnel") &&
                  (tun.type == ProfileType::TUNNEL) &&
                  (!tun.entries.empty());

    // Verify stored
    auto names = list_profiles();
    bool stored_ok = (names.size() == 3);

    // Verify some specific entries
    bool net_entries = has_entry("default_network", "mtu") &&
                       has_entry("default_network", "dns_primary");
    bool sec_entries = has_entry("default_security", "tls_min_version") &&
                       has_entry("default_security", "cipher_suite");
    bool tun_entries = has_entry("default_tunnel", "tunnel_type") &&
                       has_entry("default_tunnel", "remote_host");

    result.passed = net_ok && sec_ok && tun_ok && stored_ok &&
                    net_entries && sec_entries && tun_entries;
    result.details = "network=" + std::string(net_ok ? "OK" : "FAIL") +
                     "(" + std::to_string(net.entries.size()) + " entries)" +
                     " security=" + std::string(sec_ok ? "OK" : "FAIL") +
                     "(" + std::to_string(sec.entries.size()) + " entries)" +
                     " tunnel=" + std::string(tun_ok ? "OK" : "FAIL") +
                     "(" + std::to_string(tun.entries.size()) + " entries)" +
                     " stored=" + std::string(stored_ok ? "OK" : "FAIL");

    auto t2 = std::chrono::steady_clock::now();
    result.duration_ms = std::chrono::duration<double, std::milli>(t2 - t1).count();

    logger_.debug("ConfigProfile", "test_templates: " +
                  std::string(result.passed ? "PASS" : "FAIL"));
    return result;
}

ProfileTestResult ConfigProfileManager::test_versioning() {
    ProfileTestResult result;
    result.test_name = "Version Tracking";
    auto t1 = std::chrono::steady_clock::now();

    {
        std::lock_guard<std::mutex> lk(mutex_);
        profiles_.clear();
    }

    create_profile("ver_test", ProfileType::NETWORK);

    auto p1 = load_profile("ver_test");
    int v1 = p1.version; // should be 1

    // Each set_entry increments version
    set_entry("ver_test", "key1", "val1");
    auto p2 = load_profile("ver_test");
    int v2 = p2.version; // should be 2

    set_entry("ver_test", "key2", "val2");
    auto p3 = load_profile("ver_test");
    int v3 = p3.version; // should be 3

    // Update existing entry also increments
    set_entry("ver_test", "key1", "updated");
    auto p4 = load_profile("ver_test");
    int v4 = p4.version; // should be 4

    // Remove entry increments
    remove_entry("ver_test", "key2");
    auto p5 = load_profile("ver_test");
    int v5 = p5.version; // should be 5

    // Save profile increments
    auto pmod = load_profile("ver_test");
    save_profile(pmod);
    auto p6 = load_profile("ver_test");
    int v6 = p6.version; // should be 6

    bool monotonic = (v1 < v2) && (v2 < v3) && (v3 < v4) && (v4 < v5) && (v5 < v6);

    result.passed = monotonic && (v1 == 1);
    result.details = "Versions: " + std::to_string(v1) + " -> " + std::to_string(v2) +
                     " -> " + std::to_string(v3) + " -> " + std::to_string(v4) +
                     " -> " + std::to_string(v5) + " -> " + std::to_string(v6) +
                     " (monotonic=" + std::string(monotonic ? "YES" : "NO") + ")";

    auto t2 = std::chrono::steady_clock::now();
    result.duration_ms = std::chrono::duration<double, std::milli>(t2 - t1).count();

    logger_.debug("ConfigProfile", "test_versioning: " +
                  std::string(result.passed ? "PASS" : "FAIL"));
    return result;
}

ProfileTestResult ConfigProfileManager::test_diff() {
    ProfileTestResult result;
    result.test_name = "Profile Diff";
    auto t1 = std::chrono::steady_clock::now();

    {
        std::lock_guard<std::mutex> lk(mutex_);
        profiles_.clear();
    }

    // Create two profiles
    create_profile("diff_a", ProfileType::NETWORK);
    create_profile("diff_b", ProfileType::NETWORK);

    // Profile A: host=10.0.0.1, port=8080, timeout=5000
    set_entry("diff_a", "host", "10.0.0.1");
    set_entry("diff_a", "port", "8080");
    set_entry("diff_a", "timeout", "5000");

    // Profile B: host=10.0.0.2, port=8080, mtu=1500
    set_entry("diff_b", "host", "10.0.0.2");
    set_entry("diff_b", "port", "8080");
    set_entry("diff_b", "mtu", "1500");

    auto diffs = diff_profiles("diff_a", "diff_b");

    // Expected diffs:
    // host: changed (10.0.0.1 -> 10.0.0.2)
    // timeout: removed (in A, not in B)
    // mtu: added (not in A, in B)
    // port: no diff (same value)

    bool has_changed = false, has_removed = false, has_added = false;
    bool no_port_diff = true;

    for (auto& d : diffs) {
        if (d.key == "host" && d.status == "changed" &&
            d.old_value == "10.0.0.1" && d.new_value == "10.0.0.2") {
            has_changed = true;
        }
        if (d.key == "timeout" && d.status == "removed") {
            has_removed = true;
        }
        if (d.key == "mtu" && d.status == "added") {
            has_added = true;
        }
        if (d.key == "port") {
            no_port_diff = false; // port should NOT appear in diff
        }
    }

    bool count_ok = (diffs.size() == 3);

    // Test diff with missing profile
    auto bad_diff = diff_profiles("diff_a", "nonexistent");
    bool edge_ok = bad_diff.empty();

    result.passed = has_changed && has_removed && has_added && no_port_diff &&
                    count_ok && edge_ok;
    result.details = "changed=" + std::string(has_changed ? "OK" : "FAIL") +
                     " removed=" + std::string(has_removed ? "OK" : "FAIL") +
                     " added=" + std::string(has_added ? "OK" : "FAIL") +
                     " no_false_diff=" + std::string(no_port_diff ? "OK" : "FAIL") +
                     " count=" + std::to_string(diffs.size()) +
                     " edge=" + std::string(edge_ok ? "OK" : "FAIL");

    auto t2 = std::chrono::steady_clock::now();
    result.duration_ms = std::chrono::duration<double, std::milli>(t2 - t1).count();

    logger_.debug("ConfigProfile", "test_diff: " +
                  std::string(result.passed ? "PASS" : "FAIL"));
    return result;
}

// ===========================================================================
// Full Test Suite
// ===========================================================================

ProfileTestSuite ConfigProfileManager::run_full_suite() {
    ProfileTestSuite suite;
    suite.total = 0;
    suite.passed = 0;
    suite.failed = 0;

    auto start = std::chrono::steady_clock::now();
    logger_.info("ConfigProfile", "Starting config profile test suite");

    auto run_test = [&](ProfileTestResult (ConfigProfileManager::*fn)()) {
        auto r = (this->*fn)();
        suite.results.push_back(r);
        suite.total++;
        if (r.passed) suite.passed++; else suite.failed++;
        logger_.debug("ConfigProfile", r.test_name + ": " + (r.passed ? "PASS" : "FAIL"));
    };

    run_test(&ConfigProfileManager::test_create_load_save);
    run_test(&ConfigProfileManager::test_entry_ops);
    run_test(&ConfigProfileManager::test_serialization);
    run_test(&ConfigProfileManager::test_templates);
    run_test(&ConfigProfileManager::test_versioning);
    run_test(&ConfigProfileManager::test_diff);

    // Additional edge-case tests

    // Test 7: List profiles
    {
        ProfileTestResult r;
        r.test_name = "List Profiles";
        auto t1 = std::chrono::steady_clock::now();

        {
            std::lock_guard<std::mutex> lk(mutex_);
            profiles_.clear();
        }

        create_profile("alpha", ProfileType::NETWORK);
        create_profile("beta", ProfileType::SECURITY);
        create_profile("gamma", ProfileType::TUNNEL);

        auto names = list_profiles();
        bool count_ok = (names.size() == 3);

        // Names should be in map order (alphabetical)
        bool order_ok = (names.size() == 3 && names[0] == "alpha" &&
                         names[1] == "beta" && names[2] == "gamma");

        r.passed = count_ok && order_ok;
        r.details = "Count=" + std::to_string(names.size()) +
                    " order=" + std::string(order_ok ? "OK" : "FAIL");

        auto t2 = std::chrono::steady_clock::now();
        r.duration_ms = std::chrono::duration<double, std::milli>(t2 - t1).count();
        suite.results.push_back(r);
        suite.total++;
        if (r.passed) suite.passed++; else suite.failed++;
    }

    // Test 8: Duplicate profile creation
    {
        ProfileTestResult r;
        r.test_name = "Duplicate Profile Rejection";
        auto t1 = std::chrono::steady_clock::now();

        {
            std::lock_guard<std::mutex> lk(mutex_);
            profiles_.clear();
        }

        bool first = create_profile("dup_test", ProfileType::NETWORK);
        bool second = create_profile("dup_test", ProfileType::SECURITY);

        // Second should fail, original type should be preserved
        auto loaded = load_profile("dup_test");
        bool type_preserved = (loaded.type == ProfileType::NETWORK);

        r.passed = first && !second && type_preserved;
        r.details = "first=" + std::string(first ? "OK" : "FAIL") +
                    " duplicate_rejected=" + std::string(!second ? "OK" : "FAIL") +
                    " type_preserved=" + std::string(type_preserved ? "OK" : "FAIL");

        auto t2 = std::chrono::steady_clock::now();
        r.duration_ms = std::chrono::duration<double, std::milli>(t2 - t1).count();
        suite.results.push_back(r);
        suite.total++;
        if (r.passed) suite.passed++; else suite.failed++;
    }

    // Test 9: Multi-profile serialization roundtrip
    {
        ProfileTestResult r;
        r.test_name = "Multi-Profile Serialization";
        auto t1 = std::chrono::steady_clock::now();

        {
            std::lock_guard<std::mutex> lk(mutex_);
            profiles_.clear();
        }

        create_profile("mp_net", ProfileType::NETWORK);
        set_entry("mp_net", "mtu", "9000");
        create_profile("mp_sec", ProfileType::SECURITY);
        set_entry("mp_sec", "tls", "1.3");

        std::string s1 = serialize_to_string("mp_net");
        std::string s2 = serialize_to_string("mp_sec");
        std::string combined = s1 + "\n" + s2;

        {
            std::lock_guard<std::mutex> lk(mutex_);
            profiles_.clear();
        }

        bool ok = deserialize_from_string(combined);

        auto names = list_profiles();
        bool both_restored = (names.size() == 2);
        bool val1 = (get_entry("mp_net", "mtu") == "9000");
        bool val2 = (get_entry("mp_sec", "tls") == "1.3");

        r.passed = ok && both_restored && val1 && val2;
        r.details = "deser=" + std::string(ok ? "OK" : "FAIL") +
                    " profiles=" + std::to_string(names.size()) +
                    " values=" + std::string((val1 && val2) ? "OK" : "FAIL");

        auto t2 = std::chrono::steady_clock::now();
        r.duration_ms = std::chrono::duration<double, std::milli>(t2 - t1).count();
        suite.results.push_back(r);
        suite.total++;
        if (r.passed) suite.passed++; else suite.failed++;
    }

    // Test 10: Timestamp tracking
    {
        ProfileTestResult r;
        r.test_name = "Timestamp Tracking";
        auto t1 = std::chrono::steady_clock::now();

        {
            std::lock_guard<std::mutex> lk(mutex_);
            profiles_.clear();
        }

        create_profile("ts_test", ProfileType::NETWORK);
        auto p1 = load_profile("ts_test");
        int64_t created = p1.created_timestamp;
        int64_t modified1 = p1.modified_timestamp;

        bool create_ok = (created > 0) && (created == modified1);

        // Modify entry (timestamps may or may not differ within same second)
        set_entry("ts_test", "key", "val");
        auto p2 = load_profile("ts_test");
        int64_t modified2 = p2.modified_timestamp;

        bool modified_ok = (modified2 >= modified1);
        bool created_unchanged = (p2.created_timestamp == created);

        r.passed = create_ok && modified_ok && created_unchanged;
        r.details = "created=" + std::to_string(created) +
                    " modified_before=" + std::to_string(modified1) +
                    " modified_after=" + std::to_string(modified2) +
                    " create_ok=" + std::string(create_ok ? "OK" : "FAIL") +
                    " modified_ok=" + std::string(modified_ok ? "OK" : "FAIL");

        auto t2 = std::chrono::steady_clock::now();
        r.duration_ms = std::chrono::duration<double, std::milli>(t2 - t1).count();
        suite.results.push_back(r);
        suite.total++;
        if (r.passed) suite.passed++; else suite.failed++;
    }

    auto end = std::chrono::steady_clock::now();
    suite.duration_sec = std::chrono::duration<double>(end - start).count();

    logger_.info("ConfigProfile", "Suite complete: " + std::to_string(suite.passed) + " passed, "
                 + std::to_string(suite.failed) + " failed");
    return suite;
}

// ===========================================================================
// Report Formatting
// ===========================================================================

std::string ConfigProfileManager::format_report(const ProfileTestSuite& suite) {
    std::ostringstream ss;
    ss << "================================================================\n";
    ss << "  Config Profile Manager Test Report\n";
    ss << "================================================================\n\n";
    ss << std::fixed << std::setprecision(2);
    ss << "  Tests: " << suite.total << " total, "
       << suite.passed << " passed, " << suite.failed << " failed\n";
    ss << "  Duration: " << suite.duration_sec << " sec\n\n";

    for (auto& r : suite.results) {
        ss << "  " << (r.passed ? "PASS" : "FAIL") << "  " << r.test_name;
        ss << " (" << r.duration_ms << " ms)\n";
        if (!r.details.empty()) {
            ss << "         " << r.details << "\n";
        }
        ss << "\n";
    }

    ss << "================================================================\n";
    ss << "  RESULT: " << suite.passed << "/" << suite.total << " passed";
    if (suite.failed > 0) ss << " (" << suite.failed << " FAILED)";
    ss << "\n";
    ss << "================================================================\n";
    return ss.str();
}

} // namespace netswitch

#include "load_balancer.h"
#include <sstream>
#include <iomanip>
#include <numeric>
#include <cmath>

namespace netswitch {

// ===========================================================================
// LoadBalancer Implementation
// ===========================================================================

LoadBalancer::LoadBalancer(WinsockEngine& engine, Logger& logger)
    : engine_(engine), logger_(logger),
      rng_(static_cast<unsigned>(std::chrono::steady_clock::now().time_since_epoch().count()))
{
    config_.algorithm = LbAlgorithm::ROUND_ROBIN;
    config_.health_check_interval_sec = 30;
    config_.health_check_timeout_ms = 2000;
    config_.max_failures = 3;
    config_.sticky_sessions = false;
}

LoadBalancer::~LoadBalancer() {}

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

void LoadBalancer::add_backend(int id, const std::string& host, uint16_t port, int weight) {
    std::lock_guard<std::mutex> lk(mutex_);
    // Check if backend already exists
    for (auto& b : config_.backends) {
        if (b.id == id) {
            b.host = host;
            b.port = port;
            b.weight = weight;
            logger_.info("LoadBalancer", "Updated backend " + std::to_string(id) +
                         " -> " + host + ":" + std::to_string(port));
            return;
        }
    }

    BackendServer backend;
    backend.id = id;
    backend.host = host;
    backend.port = port;
    backend.weight = (weight > 0) ? weight : 1;
    backend.state = BackendState::HEALTHY;
    backend.active_connections = 0;
    backend.total_requests = 0;
    backend.avg_response_ms = 0.0;
    backend.last_health_check = std::chrono::steady_clock::now();
    backend.health_check_failures = 0;

    config_.backends.push_back(backend);
    logger_.info("LoadBalancer", "Added backend " + std::to_string(id) +
                 " (" + host + ":" + std::to_string(port) + ", weight=" +
                 std::to_string(weight) + ")");
}

void LoadBalancer::remove_backend(int id) {
    std::lock_guard<std::mutex> lk(mutex_);
    auto it = std::remove_if(config_.backends.begin(), config_.backends.end(),
        [id](const BackendServer& b) { return b.id == id; });
    if (it != config_.backends.end()) {
        config_.backends.erase(it, config_.backends.end());
        logger_.info("LoadBalancer", "Removed backend " + std::to_string(id));
    }
}

void LoadBalancer::set_algorithm(LbAlgorithm algo) {
    std::lock_guard<std::mutex> lk(mutex_);
    config_.algorithm = algo;
    logger_.info("LoadBalancer", "Algorithm set to " + algorithm_name(algo));
}

LbConfig LoadBalancer::get_config() const {
    std::lock_guard<std::mutex> lk(mutex_);
    return config_;
}

// ---------------------------------------------------------------------------
// Backend lookup helpers
// ---------------------------------------------------------------------------

BackendServer* LoadBalancer::find_backend(int id) {
    for (auto& b : config_.backends) {
        if (b.id == id) return &b;
    }
    return nullptr;
}

const BackendServer* LoadBalancer::find_backend(int id) const {
    for (auto& b : config_.backends) {
        if (b.id == id) return &b;
    }
    return nullptr;
}

std::vector<int> LoadBalancer::get_healthy_ids() const {
    std::vector<int> ids;
    for (auto& b : config_.backends) {
        if (b.state == BackendState::HEALTHY) {
            ids.push_back(b.id);
        }
    }
    return ids;
}

// ---------------------------------------------------------------------------
// FNV-1a hash
// ---------------------------------------------------------------------------

uint32_t LoadBalancer::fnv1a_hash(const std::string& data) {
    uint32_t hash = 2166136261u;
    for (unsigned char c : data) {
        hash ^= c;
        hash *= 16777619u;
    }
    return hash;
}

// ---------------------------------------------------------------------------
// Selection algorithms
// ---------------------------------------------------------------------------

int LoadBalancer::select_round_robin() {
    auto healthy = get_healthy_ids();
    if (healthy.empty()) return -1;
    uint64_t idx = rr_counter_.fetch_add(1, std::memory_order_relaxed);
    return healthy[idx % healthy.size()];
}

int LoadBalancer::select_least_connections() {
    int best_id = -1;
    int min_conns = std::numeric_limits<int>::max();
    for (auto& b : config_.backends) {
        if (b.state == BackendState::HEALTHY && b.active_connections < min_conns) {
            min_conns = b.active_connections;
            best_id = b.id;
        }
    }
    return best_id;
}

int LoadBalancer::select_weighted() {
    // Build weighted pool of healthy backends
    std::vector<int> weighted_pool;
    for (auto& b : config_.backends) {
        if (b.state == BackendState::HEALTHY) {
            for (int w = 0; w < b.weight; w++) {
                weighted_pool.push_back(b.id);
            }
        }
    }
    if (weighted_pool.empty()) return -1;

    std::uniform_int_distribution<size_t> dist(0, weighted_pool.size() - 1);
    return weighted_pool[dist(rng_)];
}

int LoadBalancer::select_random() {
    auto healthy = get_healthy_ids();
    if (healthy.empty()) return -1;
    std::uniform_int_distribution<size_t> dist(0, healthy.size() - 1);
    return healthy[dist(rng_)];
}

int LoadBalancer::select_ip_hash(const std::string& client_ip) {
    auto healthy = get_healthy_ids();
    if (healthy.empty()) return -1;
    uint32_t hash = fnv1a_hash(client_ip);
    return healthy[hash % healthy.size()];
}

int LoadBalancer::select_least_response_time() {
    int best_id = -1;
    double min_time = std::numeric_limits<double>::max();
    for (auto& b : config_.backends) {
        if (b.state == BackendState::HEALTHY && b.avg_response_ms < min_time) {
            min_time = b.avg_response_ms;
            best_id = b.id;
        }
    }
    return best_id;
}

int LoadBalancer::failover(int failed_id) {
    // Try next healthy backend after the failed one
    auto healthy = get_healthy_ids();
    if (healthy.empty()) return -1;

    // Find position after failed_id
    for (size_t i = 0; i < healthy.size(); i++) {
        if (healthy[i] != failed_id) {
            return healthy[i];
        }
    }
    return -1;
}

// ---------------------------------------------------------------------------
// Selection (public API)
// ---------------------------------------------------------------------------

LbDecision LoadBalancer::select_backend() {
    std::lock_guard<std::mutex> lk(mutex_);
    LbDecision decision;
    decision.algorithm_used = config_.algorithm;

    auto t1 = std::chrono::steady_clock::now();

    switch (config_.algorithm) {
        case LbAlgorithm::ROUND_ROBIN:
            decision.selected_backend_id = select_round_robin();
            decision.reason = "Round-robin index " + std::to_string(rr_counter_.load());
            break;
        case LbAlgorithm::LEAST_CONNECTIONS:
            decision.selected_backend_id = select_least_connections();
            decision.reason = "Fewest active connections";
            break;
        case LbAlgorithm::WEIGHTED:
            decision.selected_backend_id = select_weighted();
            decision.reason = "Weighted random selection";
            break;
        case LbAlgorithm::RANDOM:
            decision.selected_backend_id = select_random();
            decision.reason = "Random selection";
            break;
        case LbAlgorithm::IP_HASH:
            decision.selected_backend_id = select_random(); // fallback without IP
            decision.reason = "IP hash (no IP provided, random fallback)";
            break;
        case LbAlgorithm::LEAST_RESPONSE_TIME:
            decision.selected_backend_id = select_least_response_time();
            decision.reason = "Lowest average response time";
            break;
    }

    // Failover if selected backend is not healthy
    if (decision.selected_backend_id >= 0) {
        auto* b = find_backend(decision.selected_backend_id);
        if (b && b->state != BackendState::HEALTHY) {
            int alt = failover(decision.selected_backend_id);
            if (alt >= 0) {
                decision.reason += " (failover from " +
                    std::to_string(decision.selected_backend_id) + ")";
                decision.selected_backend_id = alt;
            }
        }
    }

    // Update stats
    if (decision.selected_backend_id >= 0) {
        auto* b = find_backend(decision.selected_backend_id);
        if (b) {
            b->total_requests++;
            b->active_connections++;
        }
    }

    auto t2 = std::chrono::steady_clock::now();
    decision.decision_time_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(t2 - t1).count();

    return decision;
}

LbDecision LoadBalancer::select_backend_with_hash(const std::string& client_ip) {
    std::lock_guard<std::mutex> lk(mutex_);
    LbDecision decision;
    decision.algorithm_used = LbAlgorithm::IP_HASH;

    auto t1 = std::chrono::steady_clock::now();

    // Check sticky sessions first
    if (config_.sticky_sessions) {
        auto it = sticky_map_.find(client_ip);
        if (it != sticky_map_.end()) {
            auto* b = find_backend(it->second);
            if (b && b->state == BackendState::HEALTHY) {
                decision.selected_backend_id = it->second;
                decision.reason = "Sticky session for " + client_ip;
                b->total_requests++;
                b->active_connections++;
                auto t2 = std::chrono::steady_clock::now();
                decision.decision_time_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(t2 - t1).count();
                return decision;
            }
        }
    }

    decision.selected_backend_id = select_ip_hash(client_ip);
    decision.reason = "IP hash for " + client_ip;

    // Store sticky mapping
    if (config_.sticky_sessions && decision.selected_backend_id >= 0) {
        sticky_map_[client_ip] = decision.selected_backend_id;
    }

    // Update stats
    if (decision.selected_backend_id >= 0) {
        auto* b = find_backend(decision.selected_backend_id);
        if (b) {
            b->total_requests++;
            b->active_connections++;
        }
    }

    auto t2 = std::chrono::steady_clock::now();
    decision.decision_time_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(t2 - t1).count();

    return decision;
}

// ---------------------------------------------------------------------------
// Health management
// ---------------------------------------------------------------------------

bool LoadBalancer::health_check(int backend_id) {
    std::lock_guard<std::mutex> lk(mutex_);
    auto* b = find_backend(backend_id);
    if (!b) return false;

    b->last_health_check = std::chrono::steady_clock::now();

    // Attempt TCP connect to verify backend is reachable
    SOCKET sock = engine_.create_socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (sock == INVALID_SOCKET) {
        b->health_check_failures++;
        if (b->health_check_failures >= config_.max_failures) {
            b->state = BackendState::UNHEALTHY;
        }
        return false;
    }

    bool ok = engine_.connect_socket(sock, b->host, b->port, config_.health_check_timeout_ms);
    engine_.force_close(sock);

    if (ok) {
        b->health_check_failures = 0;
        if (b->state == BackendState::UNHEALTHY) {
            b->state = BackendState::HEALTHY;
            logger_.info("LoadBalancer", "Backend " + std::to_string(backend_id) + " recovered");
        }
        return true;
    } else {
        b->health_check_failures++;
        if (b->health_check_failures >= config_.max_failures) {
            b->state = BackendState::UNHEALTHY;
            logger_.warning("LoadBalancer", "Backend " + std::to_string(backend_id) +
                           " marked unhealthy (" + std::to_string(b->health_check_failures) +
                           " failures)");
        }
        return false;
    }
}

void LoadBalancer::mark_unhealthy(int backend_id) {
    std::lock_guard<std::mutex> lk(mutex_);
    auto* b = find_backend(backend_id);
    if (b) {
        b->state = BackendState::UNHEALTHY;
        logger_.warning("LoadBalancer", "Backend " + std::to_string(backend_id) +
                       " manually marked unhealthy");
    }
}

void LoadBalancer::mark_healthy(int backend_id) {
    std::lock_guard<std::mutex> lk(mutex_);
    auto* b = find_backend(backend_id);
    if (b) {
        b->state = BackendState::HEALTHY;
        b->health_check_failures = 0;
        logger_.info("LoadBalancer", "Backend " + std::to_string(backend_id) +
                    " manually marked healthy");
    }
}

BackendState LoadBalancer::get_backend_state(int backend_id) const {
    std::lock_guard<std::mutex> lk(mutex_);
    auto* b = find_backend(backend_id);
    return b ? b->state : BackendState::DISABLED;
}

// ---------------------------------------------------------------------------
// Stats
// ---------------------------------------------------------------------------

std::vector<BackendServer> LoadBalancer::get_backend_stats() const {
    std::lock_guard<std::mutex> lk(mutex_);
    return config_.backends;
}

void LoadBalancer::reset_stats() {
    std::lock_guard<std::mutex> lk(mutex_);
    rr_counter_.store(0, std::memory_order_relaxed);
    sticky_map_.clear();
    for (auto& b : config_.backends) {
        b.active_connections = 0;
        b.total_requests = 0;
        b.avg_response_ms = 0.0;
        b.health_check_failures = 0;
    }
    logger_.debug("LoadBalancer", "Stats reset");
}

// ---------------------------------------------------------------------------
// Static helpers
// ---------------------------------------------------------------------------

std::string LoadBalancer::algorithm_name(LbAlgorithm algo) {
    switch (algo) {
        case LbAlgorithm::ROUND_ROBIN:          return "Round Robin";
        case LbAlgorithm::LEAST_CONNECTIONS:     return "Least Connections";
        case LbAlgorithm::WEIGHTED:              return "Weighted";
        case LbAlgorithm::RANDOM:                return "Random";
        case LbAlgorithm::IP_HASH:               return "IP Hash";
        case LbAlgorithm::LEAST_RESPONSE_TIME:   return "Least Response Time";
    }
    return "Unknown";
}

std::string LoadBalancer::state_name(BackendState state) {
    switch (state) {
        case BackendState::HEALTHY:   return "Healthy";
        case BackendState::UNHEALTHY: return "Unhealthy";
        case BackendState::DRAINING:  return "Draining";
        case BackendState::DISABLED:  return "Disabled";
    }
    return "Unknown";
}

// ===========================================================================
// Test Implementations
// ===========================================================================

LbTestResult LoadBalancer::test_round_robin() {
    LbTestResult result;
    result.test_name = "Round Robin Distribution";
    result.algorithm = LbAlgorithm::ROUND_ROBIN;
    result.requests = 1000;

    auto t1 = std::chrono::steady_clock::now();

    // Setup fresh backends
    {
        std::lock_guard<std::mutex> lk(mutex_);
        config_.backends.clear();
        config_.algorithm = LbAlgorithm::ROUND_ROBIN;
        rr_counter_.store(0);
    }

    int num_backends = 4;
    for (int i = 0; i < num_backends; i++) {
        add_backend(i, "10.0.0." + std::to_string(i + 1), static_cast<uint16_t>(8080 + i));
    }
    result.backends_tested = num_backends;

    std::map<int, int> dist;
    for (int r = 0; r < result.requests; r++) {
        auto d = select_backend();
        if (d.selected_backend_id >= 0) {
            dist[d.selected_backend_id]++;
        }
    }
    result.distribution = dist;

    // Verify even distribution: each backend should get ~250 requests
    int expected_per = result.requests / num_backends;
    bool even = true;
    for (int i = 0; i < num_backends; i++) {
        if (std::abs(dist[i] - expected_per) > 1) {
            even = false;
            break;
        }
    }

    result.passed = even && (static_cast<int>(dist.size()) == num_backends);
    result.details = "Expected ~" + std::to_string(expected_per) + " per backend; got: ";
    for (auto& [id, cnt] : dist) {
        result.details += "B" + std::to_string(id) + "=" + std::to_string(cnt) + " ";
    }

    auto t2 = std::chrono::steady_clock::now();
    result.duration_ms = std::chrono::duration<double, std::milli>(t2 - t1).count();

    logger_.debug("LoadBalancer", "test_round_robin: " + std::string(result.passed ? "PASS" : "FAIL"));
    return result;
}

LbTestResult LoadBalancer::test_least_connections() {
    LbTestResult result;
    result.test_name = "Least Connections Selection";
    result.algorithm = LbAlgorithm::LEAST_CONNECTIONS;
    result.requests = 100;

    auto t1 = std::chrono::steady_clock::now();

    {
        std::lock_guard<std::mutex> lk(mutex_);
        config_.backends.clear();
        config_.algorithm = LbAlgorithm::LEAST_CONNECTIONS;
    }

    int num_backends = 3;
    for (int i = 0; i < num_backends; i++) {
        add_backend(i, "10.0.0." + std::to_string(i + 1), static_cast<uint16_t>(8080 + i));
    }
    result.backends_tested = num_backends;

    // Set different connection counts
    {
        std::lock_guard<std::mutex> lk(mutex_);
        config_.backends[0].active_connections = 10;
        config_.backends[1].active_connections = 5;
        config_.backends[2].active_connections = 20;
    }

    // First selection should go to backend 1 (fewest connections)
    auto d = select_backend();
    result.distribution[d.selected_backend_id]++;

    result.passed = (d.selected_backend_id == 1);
    result.details = "Backend with 5 connections selected: " +
                     std::to_string(d.selected_backend_id) +
                     " (expected 1)";

    // Now run more requests - they should favor the least loaded
    for (int r = 1; r < result.requests; r++) {
        // Reset connections periodically to keep test meaningful
        {
            std::lock_guard<std::mutex> lk(mutex_);
            for (auto& b : config_.backends) {
                b.active_connections = std::max(0, b.active_connections - 1);
            }
        }
        auto dec = select_backend();
        if (dec.selected_backend_id >= 0) {
            result.distribution[dec.selected_backend_id]++;
        }
    }

    auto t2 = std::chrono::steady_clock::now();
    result.duration_ms = std::chrono::duration<double, std::milli>(t2 - t1).count();

    logger_.debug("LoadBalancer", "test_least_connections: " + std::string(result.passed ? "PASS" : "FAIL"));
    return result;
}

LbTestResult LoadBalancer::test_weighted() {
    LbTestResult result;
    result.test_name = "Weighted Distribution";
    result.algorithm = LbAlgorithm::WEIGHTED;
    result.requests = 10000;

    auto t1 = std::chrono::steady_clock::now();

    {
        std::lock_guard<std::mutex> lk(mutex_);
        config_.backends.clear();
        config_.algorithm = LbAlgorithm::WEIGHTED;
    }

    // Weights: 1, 2, 3 => expected ratio ~1:2:3
    add_backend(0, "10.0.0.1", 8080, 1);
    add_backend(1, "10.0.0.2", 8081, 2);
    add_backend(2, "10.0.0.3", 8082, 3);
    result.backends_tested = 3;

    std::map<int, int> dist;
    for (int r = 0; r < result.requests; r++) {
        auto d = select_backend();
        if (d.selected_backend_id >= 0) {
            dist[d.selected_backend_id]++;
        }
    }
    result.distribution = dist;

    // Check proportionality with 15% tolerance
    double total = static_cast<double>(result.requests);
    double r0 = dist[0] / total;
    double r1 = dist[1] / total;
    double r2 = dist[2] / total;

    // Expected: 1/6 ~ 0.167, 2/6 ~ 0.333, 3/6 ~ 0.500
    bool proportional = (std::abs(r0 - 1.0/6.0) < 0.05) &&
                        (std::abs(r1 - 2.0/6.0) < 0.05) &&
                        (std::abs(r2 - 3.0/6.0) < 0.05);

    result.passed = proportional;
    std::ostringstream ss;
    ss << std::fixed << std::setprecision(1);
    ss << "Ratios: B0=" << (r0 * 100) << "% (expect ~16.7%), "
       << "B1=" << (r1 * 100) << "% (expect ~33.3%), "
       << "B2=" << (r2 * 100) << "% (expect ~50.0%)";
    result.details = ss.str();

    auto t2 = std::chrono::steady_clock::now();
    result.duration_ms = std::chrono::duration<double, std::milli>(t2 - t1).count();

    logger_.debug("LoadBalancer", "test_weighted: " + std::string(result.passed ? "PASS" : "FAIL"));
    return result;
}

LbTestResult LoadBalancer::test_random() {
    LbTestResult result;
    result.test_name = "Random Distribution";
    result.algorithm = LbAlgorithm::RANDOM;
    result.requests = 10000;

    auto t1 = std::chrono::steady_clock::now();

    {
        std::lock_guard<std::mutex> lk(mutex_);
        config_.backends.clear();
        config_.algorithm = LbAlgorithm::RANDOM;
    }

    int num_backends = 4;
    for (int i = 0; i < num_backends; i++) {
        add_backend(i, "10.0.0." + std::to_string(i + 1), static_cast<uint16_t>(8080 + i));
    }
    result.backends_tested = num_backends;

    std::map<int, int> dist;
    for (int r = 0; r < result.requests; r++) {
        auto d = select_backend();
        if (d.selected_backend_id >= 0) {
            dist[d.selected_backend_id]++;
        }
    }
    result.distribution = dist;

    // Each should get ~25% with 10% tolerance (statistical)
    int expected = result.requests / num_backends;
    int tolerance = result.requests / 10;
    bool balanced = true;
    for (int i = 0; i < num_backends; i++) {
        if (std::abs(dist[i] - expected) > tolerance) {
            balanced = false;
            break;
        }
    }

    // Also verify it's not perfectly uniform (that would mean it's not random)
    bool has_variation = false;
    for (int i = 1; i < num_backends; i++) {
        if (dist[i] != dist[0]) { has_variation = true; break; }
    }

    result.passed = balanced && has_variation;
    result.details = "Distribution: ";
    for (auto& [id, cnt] : dist) {
        result.details += "B" + std::to_string(id) + "=" + std::to_string(cnt) + " ";
    }
    result.details += "(expected ~" + std::to_string(expected) + " each, tol=" +
                      std::to_string(tolerance) + ")";

    auto t2 = std::chrono::steady_clock::now();
    result.duration_ms = std::chrono::duration<double, std::milli>(t2 - t1).count();

    logger_.debug("LoadBalancer", "test_random: " + std::string(result.passed ? "PASS" : "FAIL"));
    return result;
}

LbTestResult LoadBalancer::test_ip_hash() {
    LbTestResult result;
    result.test_name = "IP Hash Consistency";
    result.algorithm = LbAlgorithm::IP_HASH;
    result.requests = 200;

    auto t1 = std::chrono::steady_clock::now();

    {
        std::lock_guard<std::mutex> lk(mutex_);
        config_.backends.clear();
        config_.algorithm = LbAlgorithm::IP_HASH;
        config_.sticky_sessions = false;
    }

    int num_backends = 5;
    for (int i = 0; i < num_backends; i++) {
        add_backend(i, "10.0.0." + std::to_string(i + 1), static_cast<uint16_t>(8080 + i));
    }
    result.backends_tested = num_backends;

    // Test that same IP always maps to same backend
    std::vector<std::string> test_ips = {
        "192.168.1.10", "192.168.1.20", "10.0.0.50",
        "172.16.0.1", "192.168.100.200"
    };

    bool consistent = true;
    std::map<int, int> dist;
    for (auto& ip : test_ips) {
        int first_choice = -1;
        for (int r = 0; r < result.requests / (int)test_ips.size(); r++) {
            auto d = select_backend_with_hash(ip);
            if (r == 0) {
                first_choice = d.selected_backend_id;
            } else if (d.selected_backend_id != first_choice) {
                consistent = false;
            }
            dist[d.selected_backend_id]++;
        }
    }
    result.distribution = dist;

    // Verify different IPs map to different backends (at least some)
    bool spread = (dist.size() > 1);

    result.passed = consistent && spread;
    result.details = "Consistency: " + std::string(consistent ? "OK" : "FAIL") +
                     ", Spread across " + std::to_string(dist.size()) + " backends";

    auto t2 = std::chrono::steady_clock::now();
    result.duration_ms = std::chrono::duration<double, std::milli>(t2 - t1).count();

    logger_.debug("LoadBalancer", "test_ip_hash: " + std::string(result.passed ? "PASS" : "FAIL"));
    return result;
}

LbTestResult LoadBalancer::test_least_response() {
    LbTestResult result;
    result.test_name = "Least Response Time Selection";
    result.algorithm = LbAlgorithm::LEAST_RESPONSE_TIME;
    result.requests = 50;

    auto t1 = std::chrono::steady_clock::now();

    {
        std::lock_guard<std::mutex> lk(mutex_);
        config_.backends.clear();
        config_.algorithm = LbAlgorithm::LEAST_RESPONSE_TIME;
    }

    add_backend(0, "10.0.0.1", 8080);
    add_backend(1, "10.0.0.2", 8081);
    add_backend(2, "10.0.0.3", 8082);
    result.backends_tested = 3;

    // Set different response times
    {
        std::lock_guard<std::mutex> lk(mutex_);
        config_.backends[0].avg_response_ms = 50.0;
        config_.backends[1].avg_response_ms = 10.0;  // fastest
        config_.backends[2].avg_response_ms = 100.0;
    }

    // First selection should go to backend 1 (fastest)
    auto d = select_backend();
    result.distribution[d.selected_backend_id]++;

    result.passed = (d.selected_backend_id == 1);
    result.details = "Fastest backend (10ms avg) selected: " +
                     std::to_string(d.selected_backend_id) + " (expected 1)";

    // Continue selecting
    for (int r = 1; r < result.requests; r++) {
        auto dec = select_backend();
        if (dec.selected_backend_id >= 0) {
            result.distribution[dec.selected_backend_id]++;
        }
    }

    auto t2 = std::chrono::steady_clock::now();
    result.duration_ms = std::chrono::duration<double, std::milli>(t2 - t1).count();

    logger_.debug("LoadBalancer", "test_least_response: " + std::string(result.passed ? "PASS" : "FAIL"));
    return result;
}

LbTestResult LoadBalancer::test_failover() {
    LbTestResult result;
    result.test_name = "Failover Behavior";
    result.algorithm = LbAlgorithm::ROUND_ROBIN;
    result.requests = 100;

    auto t1 = std::chrono::steady_clock::now();

    {
        std::lock_guard<std::mutex> lk(mutex_);
        config_.backends.clear();
        config_.algorithm = LbAlgorithm::ROUND_ROBIN;
        rr_counter_.store(0);
    }

    add_backend(0, "10.0.0.1", 8080);
    add_backend(1, "10.0.0.2", 8081);
    add_backend(2, "10.0.0.3", 8082);
    result.backends_tested = 3;

    // Mark backend 1 as unhealthy
    mark_unhealthy(1);

    std::map<int, int> dist;
    for (int r = 0; r < result.requests; r++) {
        auto d = select_backend();
        if (d.selected_backend_id >= 0) {
            dist[d.selected_backend_id]++;
        }
    }
    result.distribution = dist;

    // Backend 1 should get zero requests
    bool no_unhealthy = (dist.find(1) == dist.end() || dist[1] == 0);
    bool others_served = (dist[0] > 0 && dist[2] > 0);

    result.passed = no_unhealthy && others_served;
    result.details = "Unhealthy B1 got " + std::to_string(dist[1]) +
                     " requests (expected 0); B0=" + std::to_string(dist[0]) +
                     " B2=" + std::to_string(dist[2]);

    auto t2 = std::chrono::steady_clock::now();
    result.duration_ms = std::chrono::duration<double, std::milli>(t2 - t1).count();

    logger_.debug("LoadBalancer", "test_failover: " + std::string(result.passed ? "PASS" : "FAIL"));
    return result;
}

LbTestResult LoadBalancer::test_health_check() {
    LbTestResult result;
    result.test_name = "Health Check Mechanism";
    result.algorithm = LbAlgorithm::ROUND_ROBIN;
    result.backends_tested = 2;
    result.requests = 0;

    auto t1 = std::chrono::steady_clock::now();

    {
        std::lock_guard<std::mutex> lk(mutex_);
        config_.backends.clear();
        config_.algorithm = LbAlgorithm::ROUND_ROBIN;
        config_.max_failures = 3;
    }

    // Add backends on unreachable addresses (health check will fail)
    add_backend(0, "192.0.2.1", 1);   // RFC 5737 TEST-NET, unreachable
    add_backend(1, "192.0.2.2", 1);

    // Simulate repeated failures
    {
        std::lock_guard<std::mutex> lk(mutex_);
        auto* b0 = find_backend(0);
        if (b0) {
            b0->health_check_failures = 2;
            b0->state = BackendState::HEALTHY;
        }
        auto* b1 = find_backend(1);
        if (b1) {
            b1->health_check_failures = 0;
            b1->state = BackendState::HEALTHY;
        }
    }

    // One more failure should mark b0 unhealthy (threshold = 3)
    {
        std::lock_guard<std::mutex> lk(mutex_);
        auto* b0 = find_backend(0);
        if (b0) {
            b0->health_check_failures = 3;
            b0->state = BackendState::UNHEALTHY;
        }
    }

    BackendState s0 = get_backend_state(0);
    bool b0_unhealthy = (s0 == BackendState::UNHEALTHY);

    // Manually recover
    mark_healthy(0);
    BackendState s0_after = get_backend_state(0);
    bool b0_recovered = (s0_after == BackendState::HEALTHY);

    result.passed = b0_unhealthy && b0_recovered;
    result.details = "After 3 failures: " + state_name(s0) +
                     "; after recovery: " + state_name(s0_after);

    auto t2 = std::chrono::steady_clock::now();
    result.duration_ms = std::chrono::duration<double, std::milli>(t2 - t1).count();

    logger_.debug("LoadBalancer", "test_health_check: " + std::string(result.passed ? "PASS" : "FAIL"));
    return result;
}

LbTestResult LoadBalancer::test_sticky_sessions() {
    LbTestResult result;
    result.test_name = "Sticky Sessions";
    result.algorithm = LbAlgorithm::IP_HASH;
    result.requests = 200;

    auto t1 = std::chrono::steady_clock::now();

    {
        std::lock_guard<std::mutex> lk(mutex_);
        config_.backends.clear();
        config_.algorithm = LbAlgorithm::IP_HASH;
        config_.sticky_sessions = true;
        sticky_map_.clear();
    }

    int num_backends = 4;
    for (int i = 0; i < num_backends; i++) {
        add_backend(i, "10.0.0." + std::to_string(i + 1), static_cast<uint16_t>(8080 + i));
    }
    result.backends_tested = num_backends;

    std::string client_ip = "192.168.1.42";

    // First request establishes sticky mapping
    auto first = select_backend_with_hash(client_ip);
    int sticky_target = first.selected_backend_id;

    // All subsequent requests from same IP should go to same backend
    bool all_sticky = true;
    std::map<int, int> dist;
    dist[sticky_target]++;

    for (int r = 1; r < result.requests; r++) {
        auto d = select_backend_with_hash(client_ip);
        dist[d.selected_backend_id]++;
        if (d.selected_backend_id != sticky_target) {
            all_sticky = false;
        }
    }
    result.distribution = dist;

    // Different IP should potentially go elsewhere
    auto other = select_backend_with_hash("10.99.99.99");
    bool different_ip_works = (other.selected_backend_id >= 0);

    result.passed = all_sticky && different_ip_works;
    result.details = "Client " + client_ip + " always routed to B" +
                     std::to_string(sticky_target) + ": " +
                     std::string(all_sticky ? "YES" : "NO") +
                     "; other clients served: " +
                     std::string(different_ip_works ? "YES" : "NO");

    // Clean up
    {
        std::lock_guard<std::mutex> lk(mutex_);
        config_.sticky_sessions = false;
        sticky_map_.clear();
    }

    auto t2 = std::chrono::steady_clock::now();
    result.duration_ms = std::chrono::duration<double, std::milli>(t2 - t1).count();

    logger_.debug("LoadBalancer", "test_sticky_sessions: " + std::string(result.passed ? "PASS" : "FAIL"));
    return result;
}

LbTestResult LoadBalancer::test_drain() {
    LbTestResult result;
    result.test_name = "Drain Mode";
    result.algorithm = LbAlgorithm::ROUND_ROBIN;
    result.requests = 100;

    auto t1 = std::chrono::steady_clock::now();

    {
        std::lock_guard<std::mutex> lk(mutex_);
        config_.backends.clear();
        config_.algorithm = LbAlgorithm::ROUND_ROBIN;
        rr_counter_.store(0);
    }

    add_backend(0, "10.0.0.1", 8080);
    add_backend(1, "10.0.0.2", 8081);
    add_backend(2, "10.0.0.3", 8082);
    result.backends_tested = 3;

    // Set backend 1 to draining
    {
        std::lock_guard<std::mutex> lk(mutex_);
        auto* b1 = find_backend(1);
        if (b1) b1->state = BackendState::DRAINING;
    }

    // Draining backends should not receive new connections
    std::map<int, int> dist;
    for (int r = 0; r < result.requests; r++) {
        auto d = select_backend();
        if (d.selected_backend_id >= 0) {
            dist[d.selected_backend_id]++;
        }
    }
    result.distribution = dist;

    bool no_drain = (dist.find(1) == dist.end() || dist[1] == 0);
    bool others_ok = (dist[0] > 0 && dist[2] > 0);

    result.passed = no_drain && others_ok;
    result.details = "Draining B1 got " + std::to_string(dist[1]) +
                     " new connections (expected 0); B0=" + std::to_string(dist[0]) +
                     " B2=" + std::to_string(dist[2]);

    auto t2 = std::chrono::steady_clock::now();
    result.duration_ms = std::chrono::duration<double, std::milli>(t2 - t1).count();

    logger_.debug("LoadBalancer", "test_drain: " + std::string(result.passed ? "PASS" : "FAIL"));
    return result;
}

// ===========================================================================
// Full Test Suite
// ===========================================================================

LbTestSuite LoadBalancer::run_full_suite() {
    LbTestSuite suite;
    suite.total = 0;
    suite.passed = 0;
    suite.failed = 0;

    auto start = std::chrono::steady_clock::now();
    logger_.info("LoadBalancer", "Starting load balancer test suite");

    auto run_test = [&](LbTestResult (LoadBalancer::*fn)()) {
        auto r = (this->*fn)();
        suite.results.push_back(r);
        suite.total++;
        if (r.passed) suite.passed++; else suite.failed++;
        logger_.debug("LoadBalancer", r.test_name + ": " + (r.passed ? "PASS" : "FAIL"));
    };

    run_test(&LoadBalancer::test_round_robin);
    run_test(&LoadBalancer::test_least_connections);
    run_test(&LoadBalancer::test_weighted);
    run_test(&LoadBalancer::test_random);
    run_test(&LoadBalancer::test_ip_hash);
    run_test(&LoadBalancer::test_least_response);
    run_test(&LoadBalancer::test_failover);
    run_test(&LoadBalancer::test_health_check);
    run_test(&LoadBalancer::test_sticky_sessions);
    run_test(&LoadBalancer::test_drain);

    // Additional edge-case tests
    // Test 11: Empty backends
    {
        LbTestResult r;
        r.test_name = "Empty Backend List";
        r.algorithm = LbAlgorithm::ROUND_ROBIN;
        r.backends_tested = 0;
        r.requests = 1;
        auto t1 = std::chrono::steady_clock::now();

        {
            std::lock_guard<std::mutex> lk(mutex_);
            config_.backends.clear();
        }

        auto d = select_backend();
        r.passed = (d.selected_backend_id == -1);
        r.details = "No backends: selected_id=" + std::to_string(d.selected_backend_id) +
                    " (expected -1)";

        auto t2 = std::chrono::steady_clock::now();
        r.duration_ms = std::chrono::duration<double, std::milli>(t2 - t1).count();
        suite.results.push_back(r);
        suite.total++;
        if (r.passed) suite.passed++; else suite.failed++;
    }

    // Test 12: Single backend
    {
        LbTestResult r;
        r.test_name = "Single Backend";
        r.algorithm = LbAlgorithm::ROUND_ROBIN;
        r.backends_tested = 1;
        r.requests = 50;
        auto t1 = std::chrono::steady_clock::now();

        {
            std::lock_guard<std::mutex> lk(mutex_);
            config_.backends.clear();
            config_.algorithm = LbAlgorithm::ROUND_ROBIN;
        }
        add_backend(0, "10.0.0.1", 8080);

        bool all_zero = true;
        for (int i = 0; i < r.requests; i++) {
            auto d = select_backend();
            if (d.selected_backend_id != 0) all_zero = false;
            r.distribution[d.selected_backend_id]++;
        }

        r.passed = all_zero;
        r.details = "All " + std::to_string(r.requests) + " requests to B0: " +
                    std::string(all_zero ? "YES" : "NO");

        auto t2 = std::chrono::steady_clock::now();
        r.duration_ms = std::chrono::duration<double, std::milli>(t2 - t1).count();
        suite.results.push_back(r);
        suite.total++;
        if (r.passed) suite.passed++; else suite.failed++;
    }

    // Test 13: All backends unhealthy
    {
        LbTestResult r;
        r.test_name = "All Backends Unhealthy";
        r.algorithm = LbAlgorithm::ROUND_ROBIN;
        r.backends_tested = 3;
        r.requests = 10;
        auto t1 = std::chrono::steady_clock::now();

        {
            std::lock_guard<std::mutex> lk(mutex_);
            config_.backends.clear();
            config_.algorithm = LbAlgorithm::ROUND_ROBIN;
        }
        add_backend(0, "10.0.0.1", 8080);
        add_backend(1, "10.0.0.2", 8081);
        add_backend(2, "10.0.0.3", 8082);
        mark_unhealthy(0);
        mark_unhealthy(1);
        mark_unhealthy(2);

        bool all_none = true;
        for (int i = 0; i < r.requests; i++) {
            auto d = select_backend();
            if (d.selected_backend_id != -1) all_none = false;
        }

        r.passed = all_none;
        r.details = "All unhealthy, no backend selected: " +
                    std::string(all_none ? "YES" : "NO");

        auto t2 = std::chrono::steady_clock::now();
        r.duration_ms = std::chrono::duration<double, std::milli>(t2 - t1).count();
        suite.results.push_back(r);
        suite.total++;
        if (r.passed) suite.passed++; else suite.failed++;
    }

    // Test 14: Backend add/remove dynamic
    {
        LbTestResult r;
        r.test_name = "Dynamic Backend Add/Remove";
        r.algorithm = LbAlgorithm::ROUND_ROBIN;
        r.backends_tested = 3;
        r.requests = 20;
        auto t1 = std::chrono::steady_clock::now();

        {
            std::lock_guard<std::mutex> lk(mutex_);
            config_.backends.clear();
            config_.algorithm = LbAlgorithm::ROUND_ROBIN;
            rr_counter_.store(0);
        }

        add_backend(0, "10.0.0.1", 8080);
        add_backend(1, "10.0.0.2", 8081);

        // Select with 2 backends
        auto d1 = select_backend();
        bool phase1 = (d1.selected_backend_id == 0 || d1.selected_backend_id == 1);

        // Add third backend
        add_backend(2, "10.0.0.3", 8082);

        // Should now distribute across 3
        std::map<int, int> dist;
        for (int i = 0; i < r.requests; i++) {
            auto d = select_backend();
            if (d.selected_backend_id >= 0) dist[d.selected_backend_id]++;
        }
        bool phase2 = (dist.size() == 3);

        // Remove backend 1
        remove_backend(1);
        dist.clear();
        for (int i = 0; i < r.requests; i++) {
            auto d = select_backend();
            if (d.selected_backend_id >= 0) dist[d.selected_backend_id]++;
        }
        bool phase3 = (dist.find(1) == dist.end());

        r.passed = phase1 && phase2 && phase3;
        r.details = "Phase1(2 backends): " + std::string(phase1 ? "OK" : "FAIL") +
                    ", Phase2(3 backends): " + std::string(phase2 ? "OK" : "FAIL") +
                    ", Phase3(removed B1): " + std::string(phase3 ? "OK" : "FAIL");
        r.distribution = dist;

        auto t2 = std::chrono::steady_clock::now();
        r.duration_ms = std::chrono::duration<double, std::milli>(t2 - t1).count();
        suite.results.push_back(r);
        suite.total++;
        if (r.passed) suite.passed++; else suite.failed++;
    }

    // Test 15: Decision timing
    {
        LbTestResult r;
        r.test_name = "Decision Timing Performance";
        r.algorithm = LbAlgorithm::ROUND_ROBIN;
        r.backends_tested = 10;
        r.requests = 1000;
        auto t1 = std::chrono::steady_clock::now();

        {
            std::lock_guard<std::mutex> lk(mutex_);
            config_.backends.clear();
            config_.algorithm = LbAlgorithm::ROUND_ROBIN;
            rr_counter_.store(0);
        }

        for (int i = 0; i < 10; i++) {
            add_backend(i, "10.0.0." + std::to_string(i + 1), static_cast<uint16_t>(8080 + i));
        }

        std::vector<int64_t> times;
        for (int i = 0; i < r.requests; i++) {
            auto d = select_backend();
            times.push_back(d.decision_time_ns);
            r.distribution[d.selected_backend_id]++;
        }

        double avg_ns = 0;
        if (!times.empty()) {
            avg_ns = std::accumulate(times.begin(), times.end(), 0LL) /
                     static_cast<double>(times.size());
        }

        // Selection should be sub-microsecond for in-memory operation
        r.passed = (avg_ns < 100000.0); // < 100us
        std::ostringstream ss;
        ss << std::fixed << std::setprecision(0);
        ss << "Avg decision time: " << avg_ns << " ns (" << (avg_ns / 1000.0) << " us)";
        r.details = ss.str();

        auto t2 = std::chrono::steady_clock::now();
        r.duration_ms = std::chrono::duration<double, std::milli>(t2 - t1).count();
        suite.results.push_back(r);
        suite.total++;
        if (r.passed) suite.passed++; else suite.failed++;
    }

    auto end = std::chrono::steady_clock::now();
    suite.duration_sec = std::chrono::duration<double>(end - start).count();

    logger_.info("LoadBalancer", "Suite complete: " + std::to_string(suite.passed) + " passed, "
                 + std::to_string(suite.failed) + " failed");
    return suite;
}

// ===========================================================================
// Report Formatting
// ===========================================================================

std::string LoadBalancer::format_report(const LbTestSuite& suite) {
    std::ostringstream ss;
    ss << "================================================================\n";
    ss << "  Load Balancer Test Report\n";
    ss << "================================================================\n\n";
    ss << std::fixed << std::setprecision(2);
    ss << "  Tests: " << suite.total << " total, "
       << suite.passed << " passed, " << suite.failed << " failed\n";
    ss << "  Duration: " << suite.duration_sec << " sec\n\n";

    for (auto& r : suite.results) {
        ss << "  " << (r.passed ? "PASS" : "FAIL") << "  " << r.test_name;
        ss << " [" << algorithm_name(r.algorithm) << "]";
        ss << " (" << r.duration_ms << " ms)\n";
        if (!r.details.empty()) {
            ss << "         " << r.details << "\n";
        }
        if (!r.distribution.empty()) {
            ss << "         Distribution: ";
            for (auto& [id, cnt] : r.distribution) {
                ss << "B" << id << "=" << cnt << " ";
            }
            ss << "\n";
        }
        ss << "\n";
    }

    ss << "================================================================\n";
    ss << "  RESULT: " << suite.passed << "/" << suite.total << " passed";
    if (suite.failed > 0) ss << " (" << suite.failed << " FAILED)";
    ss << "\n";
    ss << "================================================================\n";
    return ss.str();
}

} // namespace netswitch

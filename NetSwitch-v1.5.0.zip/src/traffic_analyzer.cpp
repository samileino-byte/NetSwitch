#include "traffic_analyzer.h"
#include <sstream>
#include <iomanip>
#include <cstring>
#include <numeric>
#include <iostream>

namespace netswitch {

// ===========================================================================
// Construction / Destruction
// ===========================================================================

TrafficAnalyzer::TrafficAnalyzer(WinsockEngine& engine, Logger& logger)
    : engine_(engine), logger_(logger) {
    stats_start_ = std::chrono::steady_clock::now();
}

TrafficAnalyzer::~TrafficAnalyzer() {}

// ===========================================================================
// Static name helpers
// ===========================================================================

std::string TrafficAnalyzer::action_name(FilterAction a) {
    switch (a) {
        case FilterAction::ALLOW:      return "ALLOW";
        case FilterAction::DENY:       return "DENY";
        case FilterAction::LOG:        return "LOG";
        case FilterAction::REDIRECT:   return "REDIRECT";
        case FilterAction::RATE_LIMIT: return "RATE_LIMIT";
    }
    return "UNKNOWN";
}

std::string TrafficAnalyzer::match_name(FilterMatch m) {
    switch (m) {
        case FilterMatch::SRC_IP:    return "SRC_IP";
        case FilterMatch::DST_IP:    return "DST_IP";
        case FilterMatch::SRC_PORT:  return "SRC_PORT";
        case FilterMatch::DST_PORT:  return "DST_PORT";
        case FilterMatch::PROTOCOL:  return "PROTOCOL";
        case FilterMatch::PAYLOAD:   return "PAYLOAD";
        case FilterMatch::HEADER:    return "HEADER";
        case FilterMatch::ANY:       return "ANY";
    }
    return "UNKNOWN";
}

std::string TrafficAnalyzer::direction_name(TrafficDirection d) {
    switch (d) {
        case TrafficDirection::INBOUND:  return "INBOUND";
        case TrafficDirection::OUTBOUND: return "OUTBOUND";
        case TrafficDirection::BOTH:     return "BOTH";
    }
    return "UNKNOWN";
}

std::string TrafficAnalyzer::protocol_filter_name(ProtocolFilter p) {
    switch (p) {
        case ProtocolFilter::TCP_ONLY:      return "TCP_ONLY";
        case ProtocolFilter::UDP_ONLY:      return "UDP_ONLY";
        case ProtocolFilter::ICMP_ONLY:     return "ICMP_ONLY";
        case ProtocolFilter::ALL_PROTOCOLS: return "ALL_PROTOCOLS";
    }
    return "UNKNOWN";
}

// ===========================================================================
// Rule Management
// ===========================================================================

void TrafficAnalyzer::add_rule(const FilterRule& rule) {
    std::lock_guard<std::mutex> lock(rules_mutex_);
    FilterRule r = rule;
    if (r.id == 0) {
        r.id = next_rule_id_++;
    } else if (r.id >= next_rule_id_) {
        next_rule_id_ = r.id + 1;
    }
    r.hit_count = 0;
    rules_.push_back(r);

    // Sort by priority (lower number = higher priority)
    std::sort(rules_.begin(), rules_.end(),
              [](const FilterRule& a, const FilterRule& b) { return a.priority < b.priority; });

    // Initialize token bucket for rate-limit rules
    if (r.action == FilterAction::RATE_LIMIT) {
        std::lock_guard<std::mutex> rl(rate_mutex_);
        TokenBucket tb = {};
        tb.tokens = 10.0;
        tb.max_tokens = 10.0;
        tb.refill_rate = 2.0; // 2 tokens/sec
        tb.last_refill = std::chrono::steady_clock::now();
        rate_limiters_[r.id] = tb;
    }

    logger_.debug("TrafficAnalyzer", "Rule added: [" + std::to_string(r.id) + "] " +
                  r.name + " priority=" + std::to_string(r.priority));
}

bool TrafficAnalyzer::remove_rule(uint32_t id) {
    std::lock_guard<std::mutex> lock(rules_mutex_);
    auto it = std::find_if(rules_.begin(), rules_.end(),
                           [id](const FilterRule& r) { return r.id == id; });
    if (it != rules_.end()) {
        rules_.erase(it);
        std::lock_guard<std::mutex> rl(rate_mutex_);
        rate_limiters_.erase(id);
        return true;
    }
    return false;
}

bool TrafficAnalyzer::enable_rule(uint32_t id) {
    std::lock_guard<std::mutex> lock(rules_mutex_);
    for (auto& r : rules_) {
        if (r.id == id) { r.enabled = true; return true; }
    }
    return false;
}

bool TrafficAnalyzer::disable_rule(uint32_t id) {
    std::lock_guard<std::mutex> lock(rules_mutex_);
    for (auto& r : rules_) {
        if (r.id == id) { r.enabled = false; return true; }
    }
    return false;
}

std::vector<FilterRule> TrafficAnalyzer::get_rules() const {
    std::lock_guard<std::mutex> lock(rules_mutex_);
    return rules_;
}

void TrafficAnalyzer::clear_rules() {
    std::lock_guard<std::mutex> lock(rules_mutex_);
    rules_.clear();
    std::lock_guard<std::mutex> rl(rate_mutex_);
    rate_limiters_.clear();
    next_rule_id_ = 1;
}

// ===========================================================================
// Stats
// ===========================================================================

TrafficStats TrafficAnalyzer::get_stats() const {
    std::lock_guard<std::mutex> lock(stats_mutex_);
    TrafficStats s = stats_;

    auto now = std::chrono::steady_clock::now();
    double elapsed = std::chrono::duration<double>(now - stats_start_).count();
    if (elapsed > 0.0) {
        s.packets_per_sec = static_cast<double>(s.total_packets) / elapsed;
        s.bytes_per_sec = static_cast<double>(s.total_bytes) / elapsed;
    }
    return s;
}

void TrafficAnalyzer::reset_stats() {
    std::lock_guard<std::mutex> lock(stats_mutex_);
    stats_ = {};
    stats_start_ = std::chrono::steady_clock::now();
}

// ===========================================================================
// Internal helpers: byte manipulation
// ===========================================================================

uint32_t TrafficAnalyzer::ip_to_u32(const std::string& ip) {
    uint32_t result = 0;
    uint32_t octet = 0;
    int shift = 24;
    for (char c : ip) {
        if (c == '.') {
            result |= (octet & 0xFF) << shift;
            shift -= 8;
            octet = 0;
        } else if (c >= '0' && c <= '9') {
            octet = octet * 10 + (c - '0');
        }
    }
    result |= (octet & 0xFF) << shift;
    return result;
}

void TrafficAnalyzer::write_u16_be(uint8_t* p, uint16_t val) {
    p[0] = (val >> 8) & 0xFF;
    p[1] = val & 0xFF;
}

void TrafficAnalyzer::write_u32_be(uint8_t* p, uint32_t val) {
    p[0] = (val >> 24) & 0xFF;
    p[1] = (val >> 16) & 0xFF;
    p[2] = (val >> 8) & 0xFF;
    p[3] = val & 0xFF;
}

// ===========================================================================
// Test packet builders
// ===========================================================================

// Build a minimal Ethernet + IPv4 + TCP packet
std::vector<uint8_t> TrafficAnalyzer::build_test_ipv4_tcp(
    const std::string& src_ip, const std::string& dst_ip,
    uint16_t src_port, uint16_t dst_port, const std::string& payload) {

    // Ethernet(14) + IPv4(20) + TCP(20) + payload
    int payload_len = static_cast<int>(payload.size());
    int total_len = 14 + 20 + 20 + payload_len;
    std::vector<uint8_t> pkt(total_len, 0);

    // Ethernet header
    std::memset(pkt.data(), 0xFF, 6);          // dst MAC broadcast
    std::memset(pkt.data() + 6, 0xAA, 6);     // src MAC
    write_u16_be(pkt.data() + 12, 0x0800);     // EtherType: IPv4

    // IPv4 header at offset 14
    uint8_t* ip = pkt.data() + 14;
    ip[0] = 0x45;                               // version=4, IHL=5
    ip[1] = 0x00;                               // DSCP/ECN
    write_u16_be(ip + 2, static_cast<uint16_t>(20 + 20 + payload_len)); // total length
    write_u16_be(ip + 4, 0x1234);               // identification
    write_u16_be(ip + 6, 0x4000);               // flags: DF
    ip[8] = 64;                                  // TTL
    ip[9] = 6;                                   // protocol: TCP
    write_u16_be(ip + 10, 0x0000);              // checksum (zeroed)
    write_u32_be(ip + 12, ip_to_u32(src_ip));   // src addr
    write_u32_be(ip + 16, ip_to_u32(dst_ip));   // dst addr

    // TCP header at offset 34
    uint8_t* tcp = pkt.data() + 34;
    write_u16_be(tcp, src_port);
    write_u16_be(tcp + 2, dst_port);
    write_u32_be(tcp + 4, 1000);                // seq number
    write_u32_be(tcp + 8, 0);                   // ack number
    tcp[12] = 0x50;                              // data offset = 5 (20 bytes)
    tcp[13] = 0x02;                              // flags: SYN
    write_u16_be(tcp + 14, 65535);              // window size
    write_u16_be(tcp + 16, 0x0000);             // checksum
    write_u16_be(tcp + 18, 0x0000);             // urgent pointer

    // Payload at offset 54
    if (payload_len > 0) {
        std::memcpy(pkt.data() + 54, payload.data(), payload_len);
    }

    return pkt;
}

std::vector<uint8_t> TrafficAnalyzer::build_test_ipv4_udp(
    const std::string& src_ip, const std::string& dst_ip,
    uint16_t src_port, uint16_t dst_port, const std::string& payload) {

    int payload_len = static_cast<int>(payload.size());
    int total_len = 14 + 20 + 8 + payload_len;
    std::vector<uint8_t> pkt(total_len, 0);

    // Ethernet header
    std::memset(pkt.data(), 0xFF, 6);
    std::memset(pkt.data() + 6, 0xBB, 6);
    write_u16_be(pkt.data() + 12, 0x0800);

    // IPv4 header at offset 14
    uint8_t* ip = pkt.data() + 14;
    ip[0] = 0x45;
    write_u16_be(ip + 2, static_cast<uint16_t>(20 + 8 + payload_len));
    write_u16_be(ip + 4, 0x5678);
    write_u16_be(ip + 6, 0x4000);
    ip[8] = 64;
    ip[9] = 17;                                  // protocol: UDP
    write_u32_be(ip + 12, ip_to_u32(src_ip));
    write_u32_be(ip + 16, ip_to_u32(dst_ip));

    // UDP header at offset 34
    uint8_t* udp = pkt.data() + 34;
    write_u16_be(udp, src_port);
    write_u16_be(udp + 2, dst_port);
    write_u16_be(udp + 4, static_cast<uint16_t>(8 + payload_len));
    write_u16_be(udp + 6, 0x0000);

    // Payload at offset 42
    if (payload_len > 0) {
        std::memcpy(pkt.data() + 42, payload.data(), payload_len);
    }

    return pkt;
}

std::vector<uint8_t> TrafficAnalyzer::build_test_ipv4_icmp(
    const std::string& src_ip, const std::string& dst_ip) {

    int total_len = 14 + 20 + 8;  // Eth + IPv4 + ICMP echo
    std::vector<uint8_t> pkt(total_len, 0);

    // Ethernet header
    std::memset(pkt.data(), 0xFF, 6);
    std::memset(pkt.data() + 6, 0xCC, 6);
    write_u16_be(pkt.data() + 12, 0x0800);

    // IPv4 header at offset 14
    uint8_t* ip = pkt.data() + 14;
    ip[0] = 0x45;
    write_u16_be(ip + 2, 28);       // total length: 20 + 8
    ip[8] = 64;
    ip[9] = 1;                        // protocol: ICMP
    write_u32_be(ip + 12, ip_to_u32(src_ip));
    write_u32_be(ip + 16, ip_to_u32(dst_ip));

    // ICMP header at offset 34
    uint8_t* icmp = pkt.data() + 34;
    icmp[0] = 8;                      // type: echo request
    icmp[1] = 0;                      // code
    write_u16_be(icmp + 2, 0x0000);  // checksum
    write_u16_be(icmp + 4, 0x0001);  // identifier
    write_u16_be(icmp + 6, 0x0001);  // sequence number

    return pkt;
}

// ===========================================================================
// Protocol identification from raw packet
// ===========================================================================

uint8_t TrafficAnalyzer::identify_protocol(const uint8_t* data, int len) {
    // Expect Ethernet(14) + IPv4; protocol at offset 14+9 = 23
    if (len < 34) return 0;
    uint16_t ethertype = (static_cast<uint16_t>(data[12]) << 8) | data[13];
    if (ethertype != 0x0800) return 0; // not IPv4
    return data[23]; // IP protocol field
}

TrafficDirection TrafficAnalyzer::identify_direction(const uint8_t* data, int len) {
    // Heuristic: if dst IP starts with 127.x or 10.x treat as inbound,
    // otherwise outbound. For test purposes we use a simple convention:
    // dst octet1 < 128 -> INBOUND, else OUTBOUND
    if (len < 34) return TrafficDirection::BOTH;
    uint8_t dst_first_octet = data[30]; // offset 14+16 = 30 in Eth+IPv4
    return (dst_first_octet < 128) ? TrafficDirection::INBOUND : TrafficDirection::OUTBOUND;
}

// ===========================================================================
// Pattern matching
// ===========================================================================

bool TrafficAnalyzer::match_pattern_in_payload(const uint8_t* data, int len, const std::string& pattern) {
    if (pattern.empty()) return true;
    if (len <= 0) return false;

    // Determine payload offset based on protocol
    if (len < 34) return false;
    uint8_t proto = identify_protocol(data, len);
    int payload_offset = 0;
    if (proto == 6) {
        // TCP: Eth(14) + IP(20) + TCP(20 min)
        if (len < 54) return false;
        int tcp_data_offset = ((data[46] >> 4) & 0x0F) * 4; // data offset field
        payload_offset = 34 + tcp_data_offset;
    } else if (proto == 17) {
        // UDP: Eth(14) + IP(20) + UDP(8)
        payload_offset = 42;
    } else {
        // Other: skip Eth+IP
        payload_offset = 34;
    }

    if (payload_offset >= len) return false;

    // Simple string search in the payload region
    std::string payload_str(reinterpret_cast<const char*>(data + payload_offset), len - payload_offset);
    return payload_str.find(pattern) != std::string::npos;
}

bool TrafficAnalyzer::match_ip_field(const uint8_t* data, int len, const std::string& pattern, bool src) {
    if (len < 34) return false;
    // src IP at offset 26-29, dst IP at offset 30-33 (Eth 14 + IPv4 offsets 12/16)
    int offset = src ? 26 : 30;
    uint32_t addr = (static_cast<uint32_t>(data[offset]) << 24) |
                    (static_cast<uint32_t>(data[offset + 1]) << 16) |
                    (static_cast<uint32_t>(data[offset + 2]) << 8) |
                    data[offset + 3];

    // Pattern can be a full IP or a prefix like "192.168."
    char buf[16];
    snprintf(buf, sizeof(buf), "%u.%u.%u.%u",
             (addr >> 24) & 0xFF, (addr >> 16) & 0xFF,
             (addr >> 8) & 0xFF, addr & 0xFF);
    std::string ip_str(buf);

    if (pattern == "*") return true;
    return ip_str.find(pattern) == 0 || ip_str == pattern;
}

bool TrafficAnalyzer::match_port_field(const uint8_t* data, int len, const std::string& pattern, bool src) {
    if (len < 38) return false;
    uint8_t proto = identify_protocol(data, len);
    if (proto != 6 && proto != 17) return false;

    // Port fields at Eth(14) + IP(20) + src_port(0-1) / dst_port(2-3)
    int offset = src ? 34 : 36;
    uint16_t port = (static_cast<uint16_t>(data[offset]) << 8) | data[offset + 1];

    if (pattern == "*") return true;

    // Support range "1000-2000" or single port "80"
    if (pattern.find('-') != std::string::npos) {
        size_t dash = pattern.find('-');
        uint16_t lo = static_cast<uint16_t>(std::stoi(pattern.substr(0, dash)));
        uint16_t hi = static_cast<uint16_t>(std::stoi(pattern.substr(dash + 1)));
        return port >= lo && port <= hi;
    }

    return port == static_cast<uint16_t>(std::stoi(pattern));
}

// ===========================================================================
// Rate limiting (token bucket)
// ===========================================================================

bool TrafficAnalyzer::check_rate_limit(uint32_t rule_id) {
    std::lock_guard<std::mutex> lock(rate_mutex_);
    auto it = rate_limiters_.find(rule_id);
    if (it == rate_limiters_.end()) return true; // no limiter -> allow

    TokenBucket& tb = it->second;
    auto now = std::chrono::steady_clock::now();
    double elapsed = std::chrono::duration<double>(now - tb.last_refill).count();
    tb.tokens = std::min(tb.max_tokens, tb.tokens + elapsed * tb.refill_rate);
    tb.last_refill = now;

    if (tb.tokens >= 1.0) {
        tb.tokens -= 1.0;
        return true;  // allowed
    }
    return false; // rate limited (deny)
}

// ===========================================================================
// Stats update
// ===========================================================================

void TrafficAnalyzer::update_stats(const uint8_t* data, int len, FilterAction action) {
    std::lock_guard<std::mutex> lock(stats_mutex_);
    stats_.total_packets++;
    stats_.total_bytes += len;

    uint8_t proto = identify_protocol(data, len);
    switch (proto) {
        case 6:  stats_.tcp_count++; break;
        case 17: stats_.udp_count++; break;
        case 1:  stats_.icmp_count++; break;
        default: break;
    }

    if (action == FilterAction::DENY || action == FilterAction::REDIRECT) {
        stats_.filtered_count++;
        stats_.denied_count++;
    } else if (action == FilterAction::ALLOW || action == FilterAction::LOG) {
        stats_.allowed_count++;
    } else if (action == FilterAction::RATE_LIMIT) {
        stats_.filtered_count++;
    }
}

// ===========================================================================
// Core analysis
// ===========================================================================

bool TrafficAnalyzer::match_rule(const uint8_t* data, int len, const FilterRule& rule) {
    if (!rule.enabled) return false;

    // Protocol filter check
    uint8_t proto = identify_protocol(data, len);
    switch (rule.protocol) {
        case ProtocolFilter::TCP_ONLY:
            if (proto != 6) return false;
            break;
        case ProtocolFilter::UDP_ONLY:
            if (proto != 17) return false;
            break;
        case ProtocolFilter::ICMP_ONLY:
            if (proto != 1) return false;
            break;
        case ProtocolFilter::ALL_PROTOCOLS:
            break;
    }

    // Direction filter check
    if (rule.direction != TrafficDirection::BOTH) {
        TrafficDirection dir = identify_direction(data, len);
        if (dir != rule.direction && dir != TrafficDirection::BOTH) return false;
    }

    // Match type check
    switch (rule.match_type) {
        case FilterMatch::SRC_IP:
            return match_ip_field(data, len, rule.pattern, true);
        case FilterMatch::DST_IP:
            return match_ip_field(data, len, rule.pattern, false);
        case FilterMatch::SRC_PORT:
            return match_port_field(data, len, rule.pattern, true);
        case FilterMatch::DST_PORT:
            return match_port_field(data, len, rule.pattern, false);
        case FilterMatch::PROTOCOL: {
            std::string proto_name;
            if (proto == 6) proto_name = "TCP";
            else if (proto == 17) proto_name = "UDP";
            else if (proto == 1) proto_name = "ICMP";
            else proto_name = std::to_string(proto);
            return proto_name == rule.pattern || rule.pattern == "*";
        }
        case FilterMatch::PAYLOAD:
            return match_pattern_in_payload(data, len, rule.pattern);
        case FilterMatch::HEADER:
            // Match anywhere in the first 54 bytes (headers)
            if (len < 14) return false;
            {
                int hdr_len = std::min(len, 54);
                std::string hdr_str(reinterpret_cast<const char*>(data), hdr_len);
                return hdr_str.find(rule.pattern) != std::string::npos || rule.pattern == "*";
            }
        case FilterMatch::ANY:
            // Match pattern anywhere in the entire packet
            if (rule.pattern == "*") return true;
            {
                std::string pkt_str(reinterpret_cast<const char*>(data), len);
                return pkt_str.find(rule.pattern) != std::string::npos;
            }
    }
    return false;
}

FilterAction TrafficAnalyzer::evaluate_rules(const uint8_t* data, int len) {
    std::lock_guard<std::mutex> lock(rules_mutex_);

    // Rules are sorted by priority. First matching enabled rule wins.
    for (auto& rule : rules_) {
        if (!rule.enabled) continue;

        if (match_rule(data, len, rule)) {
            rule.hit_count++;

            if (rule.action == FilterAction::RATE_LIMIT) {
                // If rate limit allows, treat as ALLOW; otherwise DENY
                if (check_rate_limit(rule.id)) {
                    return FilterAction::ALLOW;
                } else {
                    return FilterAction::DENY;
                }
            }
            return rule.action;
        }
    }

    // Default action: ALLOW (no rules matched)
    return FilterAction::ALLOW;
}

FilterAction TrafficAnalyzer::analyze_packet(const uint8_t* data, int len) {
    FilterAction action = evaluate_rules(data, len);
    update_stats(data, len, action);
    logger_.trace("TrafficAnalyzer", "Packet analyzed: " + action_name(action) +
                  " len=" + std::to_string(len));
    return action;
}

// ===========================================================================
// Test: rule matching
// ===========================================================================

FilterTestResult TrafficAnalyzer::test_rule_matching() {
    FilterTestResult r = {};
    r.test_name = "Basic rule matching";
    auto start = std::chrono::steady_clock::now();

    // Save current rules and clear
    auto saved = get_rules();
    clear_rules();

    // Add a rule that denies traffic from a specific source IP
    FilterRule deny_src = {};
    deny_src.name = "Deny 10.0.0.1";
    deny_src.match_type = FilterMatch::SRC_IP;
    deny_src.action = FilterAction::DENY;
    deny_src.direction = TrafficDirection::BOTH;
    deny_src.protocol = ProtocolFilter::ALL_PROTOCOLS;
    deny_src.pattern = "10.0.0.1";
    deny_src.priority = 1;
    deny_src.enabled = true;
    add_rule(deny_src);

    // Build test packets
    auto pkt_match = build_test_ipv4_tcp("10.0.0.1", "192.168.1.1", 5000, 80);
    auto pkt_nomatch = build_test_ipv4_tcp("10.0.0.2", "192.168.1.1", 5000, 80);

    FilterAction act1 = analyze_packet(pkt_match.data(), static_cast<int>(pkt_match.size()));
    FilterAction act2 = analyze_packet(pkt_nomatch.data(), static_cast<int>(pkt_nomatch.size()));

    r.rules_tested = 1;
    r.rules_matched = (act1 == FilterAction::DENY) ? 1 : 0;

    bool deny_correct = (act1 == FilterAction::DENY);
    bool allow_correct = (act2 == FilterAction::ALLOW);
    r.passed = deny_correct && allow_correct;
    r.details = "Deny matched=" + std::string(deny_correct ? "YES" : "NO") +
                ", Allow default=" + std::string(allow_correct ? "YES" : "NO");

    // Restore
    clear_rules();
    for (auto& s : saved) add_rule(s);

    auto end = std::chrono::steady_clock::now();
    r.latency_ms = std::chrono::duration<double, std::milli>(end - start).count();
    return r;
}

// ===========================================================================
// Test: rule priority
// ===========================================================================

FilterTestResult TrafficAnalyzer::test_rule_priority() {
    FilterTestResult r = {};
    r.test_name = "Rule priority ordering";
    auto start = std::chrono::steady_clock::now();

    auto saved = get_rules();
    clear_rules();

    // Low-priority rule: ALLOW all
    FilterRule allow_all = {};
    allow_all.name = "Allow all";
    allow_all.match_type = FilterMatch::ANY;
    allow_all.action = FilterAction::ALLOW;
    allow_all.direction = TrafficDirection::BOTH;
    allow_all.protocol = ProtocolFilter::ALL_PROTOCOLS;
    allow_all.pattern = "*";
    allow_all.priority = 100;
    allow_all.enabled = true;
    add_rule(allow_all);

    // High-priority rule: DENY specific port
    FilterRule deny_port = {};
    deny_port.name = "Deny port 80";
    deny_port.match_type = FilterMatch::DST_PORT;
    deny_port.action = FilterAction::DENY;
    deny_port.direction = TrafficDirection::BOTH;
    deny_port.protocol = ProtocolFilter::TCP_ONLY;
    deny_port.pattern = "80";
    deny_port.priority = 1;
    deny_port.enabled = true;
    add_rule(deny_port);

    auto pkt_80 = build_test_ipv4_tcp("10.0.0.1", "192.168.1.1", 5000, 80);
    auto pkt_443 = build_test_ipv4_tcp("10.0.0.1", "192.168.1.1", 5000, 443);

    FilterAction act1 = evaluate_rules(pkt_80.data(), static_cast<int>(pkt_80.size()));
    FilterAction act2 = evaluate_rules(pkt_443.data(), static_cast<int>(pkt_443.size()));

    r.rules_tested = 2;
    r.rules_matched = (act1 == FilterAction::DENY ? 1 : 0) + (act2 == FilterAction::ALLOW ? 1 : 0);
    r.passed = (act1 == FilterAction::DENY) && (act2 == FilterAction::ALLOW);
    r.details = "Port 80 -> " + action_name(act1) + " (expect DENY), Port 443 -> " +
                action_name(act2) + " (expect ALLOW)";

    clear_rules();
    for (auto& s : saved) add_rule(s);

    auto end = std::chrono::steady_clock::now();
    r.latency_ms = std::chrono::duration<double, std::milli>(end - start).count();
    return r;
}

// ===========================================================================
// Test: filter chain
// ===========================================================================

FilterTestResult TrafficAnalyzer::test_filter_chain() {
    FilterTestResult r = {};
    r.test_name = "Filter chain evaluation";
    auto start = std::chrono::steady_clock::now();

    auto saved = get_rules();
    clear_rules();

    // Chain: deny specific src, log specific dst, allow-all fallback
    FilterRule r1 = {};
    r1.name = "Deny attacker";
    r1.match_type = FilterMatch::SRC_IP;
    r1.action = FilterAction::DENY;
    r1.direction = TrafficDirection::BOTH;
    r1.protocol = ProtocolFilter::ALL_PROTOCOLS;
    r1.pattern = "192.168.100.50";
    r1.priority = 1;
    r1.enabled = true;
    add_rule(r1);

    FilterRule r2 = {};
    r2.name = "Log server traffic";
    r2.match_type = FilterMatch::DST_IP;
    r2.action = FilterAction::LOG;
    r2.direction = TrafficDirection::BOTH;
    r2.protocol = ProtocolFilter::ALL_PROTOCOLS;
    r2.pattern = "10.0.0.100";
    r2.priority = 50;
    r2.enabled = true;
    add_rule(r2);

    FilterRule r3 = {};
    r3.name = "Allow rest";
    r3.match_type = FilterMatch::ANY;
    r3.action = FilterAction::ALLOW;
    r3.direction = TrafficDirection::BOTH;
    r3.protocol = ProtocolFilter::ALL_PROTOCOLS;
    r3.pattern = "*";
    r3.priority = 999;
    r3.enabled = true;
    add_rule(r3);

    auto pkt_deny = build_test_ipv4_tcp("192.168.100.50", "10.0.0.100", 5000, 80);
    auto pkt_log = build_test_ipv4_tcp("10.0.0.1", "10.0.0.100", 5000, 80);
    auto pkt_allow = build_test_ipv4_tcp("10.0.0.1", "10.0.0.200", 5000, 80);

    FilterAction a1 = evaluate_rules(pkt_deny.data(), static_cast<int>(pkt_deny.size()));
    FilterAction a2 = evaluate_rules(pkt_log.data(), static_cast<int>(pkt_log.size()));
    FilterAction a3 = evaluate_rules(pkt_allow.data(), static_cast<int>(pkt_allow.size()));

    r.rules_tested = 3;
    r.rules_matched = 3;
    bool c1 = (a1 == FilterAction::DENY);
    bool c2 = (a2 == FilterAction::LOG);
    bool c3 = (a3 == FilterAction::ALLOW);
    r.passed = c1 && c2 && c3;
    r.details = "Attacker->" + action_name(a1) + " Server->" + action_name(a2) +
                " Other->" + action_name(a3);

    clear_rules();
    for (auto& s : saved) add_rule(s);

    auto end = std::chrono::steady_clock::now();
    r.latency_ms = std::chrono::duration<double, std::milli>(end - start).count();
    return r;
}

// ===========================================================================
// Test: rate limiting
// ===========================================================================

FilterTestResult TrafficAnalyzer::test_rate_limiting() {
    FilterTestResult r = {};
    r.test_name = "Rate limiting (token bucket)";
    auto start = std::chrono::steady_clock::now();

    auto saved = get_rules();
    clear_rules();

    FilterRule rl = {};
    rl.name = "Rate limit all TCP";
    rl.match_type = FilterMatch::ANY;
    rl.action = FilterAction::RATE_LIMIT;
    rl.direction = TrafficDirection::BOTH;
    rl.protocol = ProtocolFilter::TCP_ONLY;
    rl.pattern = "*";
    rl.priority = 1;
    rl.enabled = true;
    add_rule(rl);

    // Override the bucket to have only 3 tokens for predictable testing
    {
        std::lock_guard<std::mutex> lock(rate_mutex_);
        auto it = rate_limiters_.begin();
        if (it != rate_limiters_.end()) {
            it->second.tokens = 3.0;
            it->second.max_tokens = 3.0;
            it->second.refill_rate = 0.0; // no refill during test
        }
    }

    auto pkt = build_test_ipv4_tcp("10.0.0.1", "10.0.0.2", 5000, 80);

    int allowed = 0, denied = 0;
    for (int i = 0; i < 6; i++) {
        FilterAction a = analyze_packet(pkt.data(), static_cast<int>(pkt.size()));
        if (a == FilterAction::ALLOW) allowed++;
        else if (a == FilterAction::DENY) denied++;
    }

    r.rules_tested = 1;
    r.rules_matched = 1;
    // First 3 should be allowed, remaining 3 denied
    r.passed = (allowed == 3 && denied == 3);
    r.details = "6 packets: " + std::to_string(allowed) + " allowed, " +
                std::to_string(denied) + " denied (expect 3/3)";

    clear_rules();
    for (auto& s : saved) add_rule(s);

    auto end = std::chrono::steady_clock::now();
    r.latency_ms = std::chrono::duration<double, std::milli>(end - start).count();
    return r;
}

// ===========================================================================
// Test: pattern matching
// ===========================================================================

FilterTestResult TrafficAnalyzer::test_pattern_matching() {
    FilterTestResult r = {};
    r.test_name = "Payload pattern matching";
    auto start = std::chrono::steady_clock::now();

    auto saved = get_rules();
    clear_rules();

    FilterRule rule = {};
    rule.name = "Block malware signature";
    rule.match_type = FilterMatch::PAYLOAD;
    rule.action = FilterAction::DENY;
    rule.direction = TrafficDirection::BOTH;
    rule.protocol = ProtocolFilter::TCP_ONLY;
    rule.pattern = "MALWARE_SIG";
    rule.priority = 1;
    rule.enabled = true;
    add_rule(rule);

    auto pkt_mal = build_test_ipv4_tcp("10.0.0.1", "10.0.0.2", 5000, 80, "GET /page HTTP/1.1\r\nMALWARE_SIG");
    auto pkt_clean = build_test_ipv4_tcp("10.0.0.1", "10.0.0.2", 5000, 80, "GET /page HTTP/1.1\r\nClean data");

    FilterAction a1 = analyze_packet(pkt_mal.data(), static_cast<int>(pkt_mal.size()));
    FilterAction a2 = analyze_packet(pkt_clean.data(), static_cast<int>(pkt_clean.size()));

    r.rules_tested = 1;
    r.rules_matched = (a1 == FilterAction::DENY) ? 1 : 0;
    r.passed = (a1 == FilterAction::DENY) && (a2 == FilterAction::ALLOW);
    r.details = "Malware pkt->" + action_name(a1) + " Clean pkt->" + action_name(a2);

    clear_rules();
    for (auto& s : saved) add_rule(s);

    auto end = std::chrono::steady_clock::now();
    r.latency_ms = std::chrono::duration<double, std::milli>(end - start).count();
    return r;
}

// ===========================================================================
// Test: protocol filtering
// ===========================================================================

FilterTestResult TrafficAnalyzer::test_protocol_filtering() {
    FilterTestResult r = {};
    r.test_name = "Protocol-based filtering";
    auto start = std::chrono::steady_clock::now();

    auto saved = get_rules();
    clear_rules();

    // Deny all UDP
    FilterRule deny_udp = {};
    deny_udp.name = "Deny UDP";
    deny_udp.match_type = FilterMatch::ANY;
    deny_udp.action = FilterAction::DENY;
    deny_udp.direction = TrafficDirection::BOTH;
    deny_udp.protocol = ProtocolFilter::UDP_ONLY;
    deny_udp.pattern = "*";
    deny_udp.priority = 1;
    deny_udp.enabled = true;
    add_rule(deny_udp);

    auto pkt_tcp = build_test_ipv4_tcp("10.0.0.1", "10.0.0.2", 5000, 80);
    auto pkt_udp = build_test_ipv4_udp("10.0.0.1", "10.0.0.2", 5000, 53);
    auto pkt_icmp = build_test_ipv4_icmp("10.0.0.1", "10.0.0.2");

    FilterAction a_tcp = analyze_packet(pkt_tcp.data(), static_cast<int>(pkt_tcp.size()));
    FilterAction a_udp = analyze_packet(pkt_udp.data(), static_cast<int>(pkt_udp.size()));
    FilterAction a_icmp = analyze_packet(pkt_icmp.data(), static_cast<int>(pkt_icmp.size()));

    r.rules_tested = 1;
    r.rules_matched = (a_udp == FilterAction::DENY) ? 1 : 0;
    r.passed = (a_tcp == FilterAction::ALLOW) && (a_udp == FilterAction::DENY) &&
               (a_icmp == FilterAction::ALLOW);
    r.details = "TCP->" + action_name(a_tcp) + " UDP->" + action_name(a_udp) +
                " ICMP->" + action_name(a_icmp);

    clear_rules();
    for (auto& s : saved) add_rule(s);

    auto end = std::chrono::steady_clock::now();
    r.latency_ms = std::chrono::duration<double, std::milli>(end - start).count();
    return r;
}

// ===========================================================================
// Test: direction filtering
// ===========================================================================

FilterTestResult TrafficAnalyzer::test_direction_filtering() {
    FilterTestResult r = {};
    r.test_name = "Direction-based filtering";
    auto start = std::chrono::steady_clock::now();

    auto saved = get_rules();
    clear_rules();

    // Deny inbound only (dst IP < 128.x.x.x in our heuristic)
    FilterRule deny_in = {};
    deny_in.name = "Deny inbound to 10.x";
    deny_in.match_type = FilterMatch::DST_IP;
    deny_in.action = FilterAction::DENY;
    deny_in.direction = TrafficDirection::INBOUND;
    deny_in.protocol = ProtocolFilter::ALL_PROTOCOLS;
    deny_in.pattern = "10.0.0.";
    deny_in.priority = 1;
    deny_in.enabled = true;
    add_rule(deny_in);

    // Inbound packet: dst=10.0.0.5 (first octet < 128 -> INBOUND)
    auto pkt_in = build_test_ipv4_tcp("200.0.0.1", "10.0.0.5", 5000, 80);
    // Outbound packet: dst=200.0.0.1 (first octet >= 128 -> OUTBOUND)
    auto pkt_out = build_test_ipv4_tcp("10.0.0.5", "200.0.0.1", 80, 5000);

    FilterAction a_in = analyze_packet(pkt_in.data(), static_cast<int>(pkt_in.size()));
    FilterAction a_out = analyze_packet(pkt_out.data(), static_cast<int>(pkt_out.size()));

    r.rules_tested = 1;
    r.rules_matched = (a_in == FilterAction::DENY) ? 1 : 0;
    r.passed = (a_in == FilterAction::DENY) && (a_out == FilterAction::ALLOW);
    r.details = "Inbound->" + action_name(a_in) + " Outbound->" + action_name(a_out);

    clear_rules();
    for (auto& s : saved) add_rule(s);

    auto end = std::chrono::steady_clock::now();
    r.latency_ms = std::chrono::duration<double, std::milli>(end - start).count();
    return r;
}

// ===========================================================================
// Test: rule persistence
// ===========================================================================

FilterTestResult TrafficAnalyzer::test_rule_persistence() {
    FilterTestResult r = {};
    r.test_name = "Rule persistence across operations";
    auto start = std::chrono::steady_clock::now();

    auto saved = get_rules();
    clear_rules();

    // Add 5 rules
    for (int i = 0; i < 5; i++) {
        FilterRule rule = {};
        rule.name = "Persist rule " + std::to_string(i);
        rule.match_type = FilterMatch::DST_PORT;
        rule.action = FilterAction::DENY;
        rule.direction = TrafficDirection::BOTH;
        rule.protocol = ProtocolFilter::ALL_PROTOCOLS;
        rule.pattern = std::to_string(8000 + i);
        rule.priority = 10 + i;
        rule.enabled = true;
        add_rule(rule);
    }

    bool has_5 = (get_rules().size() == 5);

    // Remove one rule (the second one, id should be 2 given reset)
    auto rules = get_rules();
    bool removed = false;
    if (rules.size() >= 2) {
        removed = remove_rule(rules[1].id);
    }
    bool has_4 = (get_rules().size() == 4);

    // Add another
    FilterRule extra = {};
    extra.name = "Extra rule";
    extra.match_type = FilterMatch::SRC_PORT;
    extra.action = FilterAction::LOG;
    extra.direction = TrafficDirection::BOTH;
    extra.protocol = ProtocolFilter::ALL_PROTOCOLS;
    extra.pattern = "9999";
    extra.priority = 5;
    extra.enabled = true;
    add_rule(extra);
    bool has_5_again = (get_rules().size() == 5);

    r.rules_tested = 5;
    r.rules_matched = 5;
    r.passed = has_5 && removed && has_4 && has_5_again;
    r.details = "Add5=" + std::string(has_5 ? "OK" : "FAIL") +
                " Remove=" + std::string(removed ? "OK" : "FAIL") +
                " Has4=" + std::string(has_4 ? "OK" : "FAIL") +
                " AddBack=" + std::string(has_5_again ? "OK" : "FAIL");

    clear_rules();
    for (auto& s : saved) add_rule(s);

    auto end = std::chrono::steady_clock::now();
    r.latency_ms = std::chrono::duration<double, std::milli>(end - start).count();
    return r;
}

// ===========================================================================
// Test: stats accuracy
// ===========================================================================

FilterTestResult TrafficAnalyzer::test_stats_accuracy() {
    FilterTestResult r = {};
    r.test_name = "Statistics accuracy";
    auto start = std::chrono::steady_clock::now();

    auto saved = get_rules();
    clear_rules();
    reset_stats();

    // Add a deny rule for UDP
    FilterRule deny_udp = {};
    deny_udp.name = "Deny UDP for stats";
    deny_udp.match_type = FilterMatch::ANY;
    deny_udp.action = FilterAction::DENY;
    deny_udp.direction = TrafficDirection::BOTH;
    deny_udp.protocol = ProtocolFilter::UDP_ONLY;
    deny_udp.pattern = "*";
    deny_udp.priority = 1;
    deny_udp.enabled = true;
    add_rule(deny_udp);

    // Send 3 TCP packets (allowed) and 2 UDP packets (denied) and 1 ICMP (allowed)
    auto tcp1 = build_test_ipv4_tcp("10.0.0.1", "10.0.0.2", 5000, 80);
    auto tcp2 = build_test_ipv4_tcp("10.0.0.1", "10.0.0.2", 5001, 80);
    auto tcp3 = build_test_ipv4_tcp("10.0.0.1", "10.0.0.2", 5002, 80);
    auto udp1 = build_test_ipv4_udp("10.0.0.1", "10.0.0.2", 5000, 53);
    auto udp2 = build_test_ipv4_udp("10.0.0.1", "10.0.0.2", 5001, 53);
    auto icmp1 = build_test_ipv4_icmp("10.0.0.1", "10.0.0.2");

    analyze_packet(tcp1.data(), static_cast<int>(tcp1.size()));
    analyze_packet(tcp2.data(), static_cast<int>(tcp2.size()));
    analyze_packet(tcp3.data(), static_cast<int>(tcp3.size()));
    analyze_packet(udp1.data(), static_cast<int>(udp1.size()));
    analyze_packet(udp2.data(), static_cast<int>(udp2.size()));
    analyze_packet(icmp1.data(), static_cast<int>(icmp1.size()));

    auto stats = get_stats();

    bool total_ok = (stats.total_packets == 6);
    bool tcp_ok = (stats.tcp_count == 3);
    bool udp_ok = (stats.udp_count == 2);
    bool icmp_ok = (stats.icmp_count == 1);
    bool allowed_ok = (stats.allowed_count == 4); // 3 TCP + 1 ICMP
    bool denied_ok = (stats.denied_count == 2);   // 2 UDP

    r.rules_tested = 1;
    r.rules_matched = 1;
    r.passed = total_ok && tcp_ok && udp_ok && icmp_ok && allowed_ok && denied_ok;
    r.details = "total=" + std::to_string(stats.total_packets) +
                " tcp=" + std::to_string(stats.tcp_count) +
                " udp=" + std::to_string(stats.udp_count) +
                " icmp=" + std::to_string(stats.icmp_count) +
                " allowed=" + std::to_string(stats.allowed_count) +
                " denied=" + std::to_string(stats.denied_count);

    clear_rules();
    for (auto& s : saved) add_rule(s);

    auto end = std::chrono::steady_clock::now();
    r.latency_ms = std::chrono::duration<double, std::milli>(end - start).count();
    return r;
}

// ===========================================================================
// Test: concurrent rules
// ===========================================================================

FilterTestResult TrafficAnalyzer::test_concurrent_rules() {
    FilterTestResult r = {};
    r.test_name = "Concurrent rule evaluation";
    auto start = std::chrono::steady_clock::now();

    auto saved = get_rules();
    clear_rules();

    // Add 20 rules with varied priorities
    for (int i = 0; i < 20; i++) {
        FilterRule rule = {};
        rule.name = "Concurrent rule " + std::to_string(i);
        rule.match_type = FilterMatch::DST_PORT;
        rule.action = (i % 2 == 0) ? FilterAction::DENY : FilterAction::ALLOW;
        rule.direction = TrafficDirection::BOTH;
        rule.protocol = ProtocolFilter::TCP_ONLY;
        rule.pattern = std::to_string(8000 + i);
        rule.priority = 100 - i; // reverse priority so rule 19 has highest
        rule.enabled = true;
        add_rule(rule);
    }

    // Run multiple evaluations from threads
    std::atomic<int> success_count{0};
    std::vector<std::thread> threads;
    for (int t = 0; t < 4; t++) {
        threads.emplace_back([this, &success_count, t]() {
            for (int i = 0; i < 25; i++) {
                uint16_t port = 8000 + (i % 20);
                auto pkt = build_test_ipv4_tcp("10.0.0.1", "10.0.0.2", 5000, port);
                FilterAction a = evaluate_rules(pkt.data(), static_cast<int>(pkt.size()));
                // The rule for this port should match
                // Even ports -> DENY, odd ports -> ALLOW
                int rule_idx = port - 8000;
                FilterAction expected = (rule_idx % 2 == 0) ? FilterAction::DENY : FilterAction::ALLOW;
                if (a == expected) success_count++;
            }
        });
    }

    for (auto& th : threads) th.join();

    r.rules_tested = 20;
    r.rules_matched = success_count.load();
    r.passed = (success_count.load() == 100); // 4 threads x 25 iterations
    r.details = std::to_string(success_count.load()) + "/100 concurrent evaluations correct";

    clear_rules();
    for (auto& s : saved) add_rule(s);

    auto end = std::chrono::steady_clock::now();
    r.latency_ms = std::chrono::duration<double, std::milli>(end - start).count();
    return r;
}

// ===========================================================================
// Test: empty ruleset
// ===========================================================================

FilterTestResult TrafficAnalyzer::test_empty_ruleset() {
    FilterTestResult r = {};
    r.test_name = "Empty ruleset default behavior";
    auto start = std::chrono::steady_clock::now();

    auto saved = get_rules();
    clear_rules();

    auto pkt = build_test_ipv4_tcp("10.0.0.1", "10.0.0.2", 5000, 80);
    FilterAction act = evaluate_rules(pkt.data(), static_cast<int>(pkt.size()));

    r.rules_tested = 0;
    r.rules_matched = 0;
    r.passed = (act == FilterAction::ALLOW); // default should be ALLOW
    r.details = "Empty ruleset -> " + action_name(act) + " (expect ALLOW)";

    clear_rules();
    for (auto& s : saved) add_rule(s);

    auto end = std::chrono::steady_clock::now();
    r.latency_ms = std::chrono::duration<double, std::milli>(end - start).count();
    return r;
}

// ===========================================================================
// Test: wildcard matching
// ===========================================================================

FilterTestResult TrafficAnalyzer::test_wildcard_matching() {
    FilterTestResult r = {};
    r.test_name = "Wildcard pattern matching";
    auto start = std::chrono::steady_clock::now();

    auto saved = get_rules();
    clear_rules();

    // Wildcard IP prefix match: deny anything from 192.168.
    FilterRule deny_subnet = {};
    deny_subnet.name = "Deny 192.168.x.x subnet";
    deny_subnet.match_type = FilterMatch::SRC_IP;
    deny_subnet.action = FilterAction::DENY;
    deny_subnet.direction = TrafficDirection::BOTH;
    deny_subnet.protocol = ProtocolFilter::ALL_PROTOCOLS;
    deny_subnet.pattern = "192.168.";
    deny_subnet.priority = 1;
    deny_subnet.enabled = true;
    add_rule(deny_subnet);

    // Port range match
    FilterRule deny_range = {};
    deny_range.name = "Deny port range 9000-9100";
    deny_range.match_type = FilterMatch::DST_PORT;
    deny_range.action = FilterAction::DENY;
    deny_range.direction = TrafficDirection::BOTH;
    deny_range.protocol = ProtocolFilter::TCP_ONLY;
    deny_range.pattern = "9000-9100";
    deny_range.priority = 2;
    deny_range.enabled = true;
    add_rule(deny_range);

    auto pkt_subnet_match = build_test_ipv4_tcp("192.168.1.50", "10.0.0.1", 5000, 80);
    auto pkt_subnet_miss = build_test_ipv4_tcp("10.0.0.50", "10.0.0.1", 5000, 80);
    auto pkt_range_match = build_test_ipv4_tcp("10.0.0.1", "10.0.0.2", 5000, 9050);
    auto pkt_range_miss = build_test_ipv4_tcp("10.0.0.1", "10.0.0.2", 5000, 8999);

    FilterAction a1 = evaluate_rules(pkt_subnet_match.data(), static_cast<int>(pkt_subnet_match.size()));
    FilterAction a2 = evaluate_rules(pkt_subnet_miss.data(), static_cast<int>(pkt_subnet_miss.size()));
    FilterAction a3 = evaluate_rules(pkt_range_match.data(), static_cast<int>(pkt_range_match.size()));
    FilterAction a4 = evaluate_rules(pkt_range_miss.data(), static_cast<int>(pkt_range_miss.size()));

    r.rules_tested = 2;
    r.rules_matched = ((a1 == FilterAction::DENY) ? 1 : 0) + ((a3 == FilterAction::DENY) ? 1 : 0);
    r.passed = (a1 == FilterAction::DENY) && (a2 == FilterAction::ALLOW) &&
               (a3 == FilterAction::DENY) && (a4 == FilterAction::ALLOW);
    r.details = "Subnet hit->" + action_name(a1) + " miss->" + action_name(a2) +
                " Range hit->" + action_name(a3) + " miss->" + action_name(a4);

    clear_rules();
    for (auto& s : saved) add_rule(s);

    auto end = std::chrono::steady_clock::now();
    r.latency_ms = std::chrono::duration<double, std::milli>(end - start).count();
    return r;
}

// ===========================================================================
// Test: rule enable/disable
// ===========================================================================

FilterTestResult TrafficAnalyzer::test_rule_enable_disable() {
    FilterTestResult r = {};
    r.test_name = "Rule enable/disable toggle";
    auto start = std::chrono::steady_clock::now();

    auto saved = get_rules();
    clear_rules();

    FilterRule rule = {};
    rule.name = "Toggleable deny";
    rule.match_type = FilterMatch::DST_PORT;
    rule.action = FilterAction::DENY;
    rule.direction = TrafficDirection::BOTH;
    rule.protocol = ProtocolFilter::TCP_ONLY;
    rule.pattern = "80";
    rule.priority = 1;
    rule.enabled = true;
    add_rule(rule);

    auto rules = get_rules();
    uint32_t rid = rules.empty() ? 0 : rules[0].id;

    auto pkt = build_test_ipv4_tcp("10.0.0.1", "10.0.0.2", 5000, 80);

    // Should be DENY when enabled
    FilterAction a1 = evaluate_rules(pkt.data(), static_cast<int>(pkt.size()));

    // Disable rule
    disable_rule(rid);
    FilterAction a2 = evaluate_rules(pkt.data(), static_cast<int>(pkt.size()));

    // Re-enable rule
    enable_rule(rid);
    FilterAction a3 = evaluate_rules(pkt.data(), static_cast<int>(pkt.size()));

    r.rules_tested = 1;
    r.rules_matched = 1;
    r.passed = (a1 == FilterAction::DENY) && (a2 == FilterAction::ALLOW) &&
               (a3 == FilterAction::DENY);
    r.details = "Enabled->" + action_name(a1) + " Disabled->" + action_name(a2) +
                " Re-enabled->" + action_name(a3);

    clear_rules();
    for (auto& s : saved) add_rule(s);

    auto end = std::chrono::steady_clock::now();
    r.latency_ms = std::chrono::duration<double, std::milli>(end - start).count();
    return r;
}

// ===========================================================================
// Test: hit count tracking
// ===========================================================================

FilterTestResult TrafficAnalyzer::test_hit_count_tracking() {
    FilterTestResult r = {};
    r.test_name = "Hit count tracking";
    auto start = std::chrono::steady_clock::now();

    auto saved = get_rules();
    clear_rules();

    FilterRule rule = {};
    rule.name = "Count hits";
    rule.match_type = FilterMatch::DST_PORT;
    rule.action = FilterAction::LOG;
    rule.direction = TrafficDirection::BOTH;
    rule.protocol = ProtocolFilter::TCP_ONLY;
    rule.pattern = "80";
    rule.priority = 1;
    rule.enabled = true;
    add_rule(rule);

    auto pkt_match = build_test_ipv4_tcp("10.0.0.1", "10.0.0.2", 5000, 80);
    auto pkt_miss = build_test_ipv4_tcp("10.0.0.1", "10.0.0.2", 5000, 443);

    // 5 matching packets, 3 non-matching
    for (int i = 0; i < 5; i++) evaluate_rules(pkt_match.data(), static_cast<int>(pkt_match.size()));
    for (int i = 0; i < 3; i++) evaluate_rules(pkt_miss.data(), static_cast<int>(pkt_miss.size()));

    auto rules = get_rules();
    uint64_t hits = rules.empty() ? 0 : rules[0].hit_count;

    r.rules_tested = 1;
    r.rules_matched = static_cast<int>(hits);
    r.passed = (hits == 5);
    r.details = "Hit count=" + std::to_string(hits) + " (expected 5)";

    clear_rules();
    for (auto& s : saved) add_rule(s);

    auto end = std::chrono::steady_clock::now();
    r.latency_ms = std::chrono::duration<double, std::milli>(end - start).count();
    return r;
}

// ===========================================================================
// Test: large ruleset performance
// ===========================================================================

FilterTestResult TrafficAnalyzer::test_large_ruleset_performance() {
    FilterTestResult r = {};
    r.test_name = "Large ruleset performance (100 rules)";
    auto start = std::chrono::steady_clock::now();

    auto saved = get_rules();
    clear_rules();

    // Add 100 rules targeting different ports
    for (int i = 0; i < 100; i++) {
        FilterRule rule = {};
        rule.name = "Perf rule " + std::to_string(i);
        rule.match_type = FilterMatch::DST_PORT;
        rule.action = FilterAction::DENY;
        rule.direction = TrafficDirection::BOTH;
        rule.protocol = ProtocolFilter::TCP_ONLY;
        rule.pattern = std::to_string(10000 + i);
        rule.priority = i + 1;
        rule.enabled = true;
        add_rule(rule);
    }

    // Evaluate 1000 packets: measure throughput
    auto eval_start = std::chrono::steady_clock::now();
    int matched = 0;
    for (int i = 0; i < 1000; i++) {
        uint16_t port = 10000 + (i % 100);
        auto pkt = build_test_ipv4_tcp("10.0.0.1", "10.0.0.2", 5000, port);
        FilterAction a = evaluate_rules(pkt.data(), static_cast<int>(pkt.size()));
        if (a == FilterAction::DENY) matched++;
    }
    auto eval_end = std::chrono::steady_clock::now();
    double eval_ms = std::chrono::duration<double, std::milli>(eval_end - eval_start).count();

    r.rules_tested = 100;
    r.rules_matched = matched;
    // All 1000 should match a deny rule
    r.passed = (matched == 1000) && (eval_ms < 5000.0); // under 5 seconds
    r.details = std::to_string(matched) + "/1000 matched, " +
                std::to_string(eval_ms) + "ms total (" +
                std::to_string(eval_ms / 1000.0) + "ms/pkt avg)";

    clear_rules();
    for (auto& s : saved) add_rule(s);

    auto end = std::chrono::steady_clock::now();
    r.latency_ms = std::chrono::duration<double, std::milli>(end - start).count();
    return r;
}

// ===========================================================================
// Full suite
// ===========================================================================

TrafficAnalyzerSuite TrafficAnalyzer::run_full_suite() {
    TrafficAnalyzerSuite suite = {};
    auto start = std::chrono::steady_clock::now();

    logger_.info("TrafficAnalyzer", "Starting traffic analyzer test suite");

    reset_stats();

    suite.results.push_back(test_rule_matching());
    suite.results.push_back(test_rule_priority());
    suite.results.push_back(test_filter_chain());
    suite.results.push_back(test_rate_limiting());
    suite.results.push_back(test_pattern_matching());
    suite.results.push_back(test_protocol_filtering());
    suite.results.push_back(test_direction_filtering());
    suite.results.push_back(test_rule_persistence());
    suite.results.push_back(test_stats_accuracy());
    suite.results.push_back(test_concurrent_rules());
    suite.results.push_back(test_empty_ruleset());
    suite.results.push_back(test_wildcard_matching());
    suite.results.push_back(test_rule_enable_disable());
    suite.results.push_back(test_hit_count_tracking());
    suite.results.push_back(test_large_ruleset_performance());

    suite.total = static_cast<int>(suite.results.size());
    suite.passed = 0;
    suite.failed = 0;
    for (auto& r : suite.results) {
        if (r.passed) suite.passed++;
        else suite.failed++;
    }

    suite.stats = get_stats();

    auto end = std::chrono::steady_clock::now();
    suite.duration_sec = std::chrono::duration<double>(end - start).count();

    logger_.info("TrafficAnalyzer", "Suite complete: " + std::to_string(suite.passed) + "/" +
                 std::to_string(suite.total) + " passed in " +
                 std::to_string(suite.duration_sec) + "s");

    return suite;
}

// ===========================================================================
// Report formatting
// ===========================================================================

std::string TrafficAnalyzer::format_report(const TrafficAnalyzerSuite& suite) {
    std::ostringstream os;
    os << "=== Traffic Analyzer Test Suite ===" << std::endl;
    os << "Total: " << suite.total << "  Passed: " << suite.passed
       << "  Failed: " << suite.failed << std::endl;
    os << "Duration: " << std::fixed << std::setprecision(3) << suite.duration_sec << "s" << std::endl;
    os << std::endl;

    for (auto& r : suite.results) {
        os << (r.passed ? "[PASS]" : "[FAIL]") << " " << r.test_name
           << " (" << std::fixed << std::setprecision(2) << r.latency_ms << "ms)"
           << std::endl;
        os << "       Rules tested: " << r.rules_tested
           << "  Matched: " << r.rules_matched << std::endl;
        if (!r.details.empty()) {
            os << "       " << r.details << std::endl;
        }
    }

    os << std::endl;
    os << "--- Traffic Stats ---" << std::endl;
    os << "Total packets: " << suite.stats.total_packets << std::endl;
    os << "Total bytes:   " << suite.stats.total_bytes << std::endl;
    os << "TCP: " << suite.stats.tcp_count
       << "  UDP: " << suite.stats.udp_count
       << "  ICMP: " << suite.stats.icmp_count << std::endl;
    os << "Allowed: " << suite.stats.allowed_count
       << "  Denied: " << suite.stats.denied_count
       << "  Filtered: " << suite.stats.filtered_count << std::endl;
    os << "Packets/sec: " << std::fixed << std::setprecision(1) << suite.stats.packets_per_sec
       << "  Bytes/sec: " << suite.stats.bytes_per_sec << std::endl;

    return os.str();
}

} // namespace netswitch
